package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.client;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.*;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.*;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.mapper.ZytrustMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

/**
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@ExtendWith(MockitoExtension.class)
class ZytrustAdapterTest {

    @Mock
    private WebClient webClient;
    @Mock
    private ZytrustMapper mapper;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    private WebClient.RequestBodySpec bodySpec;
    @Mock
    @SuppressWarnings("rawtypes")
    private WebClient.RequestHeadersSpec headersSpec;
    @Mock
    private WebClient.ResponseSpec responseSpec;
    @InjectMocks
    private ZytrustAdapter zytrustAdapter;

    //Application
    Application application;
    ApplicationStatusResponse<ApplicationSolidResult> applicationSolidResult;

    ApplicationAttachment applicationAttachment;

    ApplicationSignature applicationSignature;
    ApplicationStatusResponse<List<ApplicationSignResult>> listApplicationStatusResponse;

    //Zytrust
    ZytrustApplicationRequest zytrustApplicationRequest;
    ZytrustStatusResponse<ZytrustSolidResponse> zytrustStatusResponseSolid;

    ZytrustApplicationAttachment zytrustApplicationAttachment;
    ZytrustStatusResponse<String> zytrustStatusResponseString;

    ZytrustApplicationSignature zytrustApplicationSignature;
    ZytrustStatusResponse<List<ZytrustSignResponse>> zytrustStatusResponseListSign;

    @BeforeEach
    void setUp() {
        application = new Application();
        applicationSolidResult = getMockApplicationSolidResult();

        applicationAttachment = new ApplicationAttachment();

        applicationSignature = new ApplicationSignature();
        listApplicationStatusResponse = new ApplicationStatusResponse<>();

        zytrustApplicationRequest = new ZytrustApplicationRequest();
        zytrustStatusResponseSolid = getMockZytrustSolidResponse();

        zytrustApplicationAttachment = new ZytrustApplicationAttachment();
        zytrustStatusResponseString = getMockZytrustAttachResponse();

        zytrustApplicationSignature = new ZytrustApplicationSignature();
        zytrustStatusResponseListSign = getMockZytrustResponse();
    }

    @Test
    void createRequest() {
        //given
        when(mapper.toZytrustApplicationRequest(application)).thenReturn(zytrustApplicationRequest);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(bodySpec);
        when(bodySpec.bodyValue(zytrustApplicationRequest)).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        //when
        when(responseSpec.bodyToMono(any(ParameterizedTypeReference.class)))
                .thenReturn(Mono.just(zytrustStatusResponseSolid));

        when(mapper.toSolidResultApplicationStatusResponse(zytrustStatusResponseSolid))
                .thenReturn(applicationSolidResult);

        ApplicationStatusResponse<ApplicationSolidResult> result = zytrustAdapter.createRequest(application);

        //then
        assertNotNull(result);
        assertEquals(result.getMessage(), applicationSolidResult.getMessage());
    }

    @Test
    void createRequest_Error(){
        //given
        when(mapper.toZytrustApplicationRequest(application)).thenReturn(zytrustApplicationRequest);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(bodySpec);
        when(bodySpec.bodyValue(zytrustApplicationRequest)).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        //when
        doReturn(Mono.error(new RuntimeException("error service")))
                .when(responseSpec)
                .bodyToMono(any(ParameterizedTypeReference.class));

        doReturn(applicationSolidResult)
                .when(mapper)
                .toSolidResultApplicationStatusResponse(any(ZytrustStatusResponse.class));

        ApplicationStatusResponse<ApplicationSolidResult> result = zytrustAdapter.createRequest(application);
        //then
        assertNotNull(result);
        assertEquals(result.getMessage(), applicationSolidResult.getMessage());
    }

    @Test
    void attachDocument() {
        when(mapper.toZytrustApplicationAttachment(applicationAttachment))
                .thenReturn(zytrustApplicationAttachment);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(bodySpec);
        when(bodySpec.bodyValue(zytrustApplicationAttachment)).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);

        when(responseSpec.bodyToMono(any(ParameterizedTypeReference.class)))
                .thenReturn(Mono.just(zytrustStatusResponseString));

        when(mapper.toApplicationAttachResultApplicationStatusResponse(zytrustStatusResponseString))
                .thenReturn(applicationSolidResult);

        ApplicationStatusResponse<ApplicationSolidResult> result =
                zytrustAdapter.attachDocument(applicationAttachment);

        //then
        assertNotNull(result);
        assertEquals(result.getMessage(),applicationSolidResult.getMessage());
    }

    @Test
    void attachDocument_Error(){
        when(mapper.toZytrustApplicationAttachment(applicationAttachment))
                .thenReturn(zytrustApplicationAttachment);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(bodySpec);
        when(bodySpec.bodyValue(zytrustApplicationAttachment)).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);

        doReturn(Mono.error(new RuntimeException("Error service")))
                .when(responseSpec)
                .bodyToMono(any(ParameterizedTypeReference.class));

        doReturn(applicationSolidResult)
                .when(mapper)
                .toApplicationAttachResultApplicationStatusResponse(any(ZytrustStatusResponse.class));

        ApplicationStatusResponse<ApplicationSolidResult> result = zytrustAdapter
                .attachDocument(applicationAttachment);
        //then
        assertNotNull(result);
        assertEquals(result.getMessage(), applicationSolidResult.getMessage());
    }

    @Test
    void signtureDocument() {
        when(mapper.toZytrustApplicationSignature(applicationSignature))
                .thenReturn(zytrustApplicationSignature);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(bodySpec);

        when(bodySpec.bodyValue(zytrustApplicationSignature)).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);

        when(responseSpec.bodyToMono(
                ArgumentMatchers.<ParameterizedTypeReference<ZytrustStatusResponse<List<ZytrustSignResponse>>>>any()
        )).thenReturn(Mono.just(zytrustStatusResponseListSign));

        when(mapper.toApplicationSignResultApplicationStatusResponse(zytrustStatusResponseListSign))
                .thenReturn(listApplicationStatusResponse);

        ApplicationStatusResponse<List<ApplicationSignResult>> result =
                zytrustAdapter.signtureDocument(applicationSignature);

        //then
        assertNotNull(result);
        assertEquals(result.getMessage(), listApplicationStatusResponse.getMessage());
    }

    @Test
    void signtureDocument_Error(){
        when(mapper.toZytrustApplicationSignature(applicationSignature))
                .thenReturn(zytrustApplicationSignature);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(bodySpec);

        when(bodySpec.bodyValue(zytrustApplicationSignature)).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);

        doReturn(Mono.error(new RuntimeException("Error service")))
                .when(responseSpec)
                .bodyToMono(any(ParameterizedTypeReference.class));

        doReturn(listApplicationStatusResponse)
                .when(mapper)
                .toApplicationSignResultApplicationStatusResponse(any(ZytrustStatusResponse.class));

        ApplicationStatusResponse<List<ApplicationSignResult>> result = zytrustAdapter
                .signtureDocument(applicationSignature);
        //then
        assertNotNull(result);
        assertEquals(result.getMessage(), listApplicationStatusResponse.getMessage());
    }

    private ZytrustStatusResponse<String> getMockZytrustAttachResponse() {
        return ZytrustStatusResponse.<String>builder()
                .error("Attach")
                .code(8000)
                .message("Todas las operaciones se efectuaron correctamente")
                .build();
    }


    private ApplicationStatusResponse<ApplicationSolidResult> getMockApplicationSolidResult() {
        return ApplicationStatusResponse.<ApplicationSolidResult>builder()
                .error("OK")
                .code(8000)
                .message("Todas las operaciones se efectuaron correctamente")
                .data(ApplicationSolidResult.builder()
                        .solid("123456")
                        .build())
                .build();

    }

    private ZytrustStatusResponse<ZytrustSolidResponse> getMockZytrustSolidResponse() {
        return ZytrustStatusResponse.<ZytrustSolidResponse>builder()
                .error("OK")
                .code(8000)
                .message("Todas las operaciones se efectuaron correctamente")
                .data(ZytrustSolidResponse.builder()
                        .solid("123456")
                        .build())
                .build();
    }

    private ZytrustStatusResponse<List<ZytrustSignResponse>> getMockZytrustResponse() {
        return ZytrustStatusResponse.<List<ZytrustSignResponse>>builder()
                .error("Signed")
                .code(8000)
                .message("Todas las operaciones se efectuaron correctamente")
                .data(List.of(ZytrustSignResponse.builder()
                        .documentId("001")
                        .documentName("prueba.pdf")
                        .txnId("001")
                        .document("asdf6a8s7df6a8s7df68as7df6a87sdf6...")
                        .build()))
                .build();
    }
}