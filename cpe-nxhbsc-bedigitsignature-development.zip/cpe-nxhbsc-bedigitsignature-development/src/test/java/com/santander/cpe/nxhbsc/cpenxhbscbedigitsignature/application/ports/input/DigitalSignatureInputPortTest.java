package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.ports.input;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.ports.output.ZytrustServiceOutPutPort;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

/**
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@ExtendWith(MockitoExtension.class)
class DigitalSignatureInputPortTest {

    @Mock
    private ZytrustServiceOutPutPort port;

    @InjectMocks
    private DigitalSignatureInputPort digitalSignatureInputPort;

    Application application;
    ApplicationStatusResponse<ApplicationSolidResult> applicationSolidResult;

    ApplicationAttachment applicationAttachment;
    ApplicationStatusResponse<ApplicationSolidResult> applicationAttachResult;

    ApplicationSignature applicationSignature;
    ApplicationStatusResponse<List<ApplicationSignResult>> applicationSignatureResult;

    @BeforeEach
    void setUp(){
        application = new Application();
        applicationSolidResult = new ApplicationStatusResponse<>();

        applicationAttachment = new ApplicationAttachment();
        applicationAttachResult = new ApplicationStatusResponse<>();

        applicationSignature = new ApplicationSignature();
        applicationSignatureResult= new ApplicationStatusResponse<>();
    }

    @Test
    void createRequest() {
        when(port.createRequest(application)).thenReturn(applicationSolidResult);

        ApplicationStatusResponse<ApplicationSolidResult> response =
                digitalSignatureInputPort.createRequest(application);

        assertNotNull(response);
        assertEquals(applicationSolidResult, response);
    }

    @Test
    void attachDocument() {
        when(port.attachDocument(applicationAttachment)).thenReturn(applicationAttachResult);

        ApplicationStatusResponse<ApplicationSolidResult> response=
                digitalSignatureInputPort.attachDocument(applicationAttachment);

        assertNotNull(response);
        assertEquals(applicationAttachResult, response);
    }

    @Test
    void signtureDocument() {
        when(port.signtureDocument(applicationSignature)).thenReturn(applicationSignatureResult);

        ApplicationStatusResponse<List<ApplicationSignResult>> response =
                digitalSignatureInputPort.signtureDocument(applicationSignature);

        assertNotNull(response);
        assertEquals(applicationSignatureResult, response);
    }
}