package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer;
import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.SecurityFilterChain;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

/**
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@ExtendWith(MockitoExtension.class)
class SecurityConfigTest {

    @Mock
    private HttpSecurity httpSecurity;

    @Mock
    private AuthorizeHttpRequestsConfigurer.AuthorizationManagerRequestMatcherRegistry authRegistry;

    @Mock
    private AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizedUrl authorizedUrl;

    @Mock
    private HeadersConfigurer<HttpSecurity> headersConfigurer;

    @Mock
    private HeadersConfigurer.ContentSecurityPolicyConfig contentSecurityPolicyConfig;

    @Mock
    private CsrfConfigurer<HttpSecurity> csrfConfigurer;

    @InjectMocks
    private SecurityConfig securityConfig;

    @Test
    void filterChain() throws Exception{
        when(httpSecurity.securityMatcher(anyString())).thenReturn(httpSecurity);

        when(httpSecurity.authorizeHttpRequests(any())).thenAnswer(invocationOnMock -> {
            Customizer<AuthorizeHttpRequestsConfigurer
                    .AuthorizationManagerRequestMatcherRegistry> customizer =
                    invocationOnMock.getArgument(0);
            customizer.customize(authRegistry);
            return httpSecurity;
        });

        when(authRegistry.requestMatchers(any(HttpMethod.class), anyString()))
                .thenReturn(authorizedUrl);
        when(authorizedUrl.permitAll()).thenReturn(authRegistry);
        when(authRegistry.anyRequest()).thenReturn(authorizedUrl);

        when(httpSecurity.csrf(any())).thenAnswer(invocation -> {
            Customizer<CsrfConfigurer<HttpSecurity>> customizer =
                    invocation.getArgument(0);
            customizer.customize(csrfConfigurer);
            return httpSecurity;
        });
        when(csrfConfigurer.disable()).thenReturn(httpSecurity);

        when(httpSecurity.headers(any())).thenAnswer(invocation -> {
            Customizer<HeadersConfigurer<HttpSecurity>> customizer =
                    invocation.getArgument(0);
            customizer.customize(headersConfigurer);
            return httpSecurity;
        });

        when(headersConfigurer.contentSecurityPolicy(any(Customizer.class))).thenAnswer(invocation -> {
            Customizer<HeadersConfigurer.ContentSecurityPolicyConfig> customizer =
                    invocation.getArgument(0);
            customizer.customize(contentSecurityPolicyConfig);
            return headersConfigurer;
        });

        when(httpSecurity.build()).thenReturn(mock(DefaultSecurityFilterChain.class));

        SecurityFilterChain result = securityConfig.filterChain(httpSecurity);

        assertNotNull(result);
        verify(authRegistry, times(3)).requestMatchers(any(HttpMethod.class), anyString());
        verify(authRegistry).anyRequest();
        verify(csrfConfigurer).disable();
    }
}