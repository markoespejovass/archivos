package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.usecases.DigitalSignatureUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.*;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.mapper.DigitalSignatureMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

/**
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@ExtendWith(MockitoExtension.class)
class DigitalSignatureApiDelegateImplTest {

    @Mock
    private DigitalSignatureUseCase useCase;

    @Mock
    private DigitalSignatureMapper mapper;

    @InjectMocks
    private DigitalSignatureApiDelegateImpl signatureApiDelegate;

    //Controller
    ApplicationRequest applicationRequest;
    ApplicationResponse applicationResponse;

    ApplicationAttachRequest applicationAttachRequest;
    ApplicationResponse applicationAttachResponse;

    ApplicationSignatureRequest applicationSignatureRequest;
    ApplicationSignatureResponse applicationSignatureResponse;

    //Application
    Application application;
    ApplicationStatusResponse<ApplicationSolidResult> applicationSolidResult;

    ApplicationAttachment applicationAttachment;
    ApplicationStatusResponse<ApplicationSolidResult> applicationAttachResult;

    ApplicationSignature applicationSignature;
    ApplicationStatusResponse<List<ApplicationSignResult>> applicationSignatureResult;


    @BeforeEach
    void setUp(){

        applicationRequest = new ApplicationRequest();
        applicationResponse = new ApplicationResponse();

        applicationAttachRequest = new ApplicationAttachRequest();
        applicationAttachResponse = new ApplicationResponse();

        applicationSignatureRequest = new ApplicationSignatureRequest();
        applicationSignatureResponse = new ApplicationSignatureResponse();


        application = new Application();
        applicationSolidResult = new ApplicationStatusResponse<>();

        applicationAttachment = new ApplicationAttachment();
        applicationAttachResult = new ApplicationStatusResponse<>();

        applicationSignature = new ApplicationSignature();
        applicationSignatureResult= new ApplicationStatusResponse<>();
    }

    @Test
    void create() {
        when(mapper.toApplication(applicationRequest)).thenReturn(application);
        when(useCase.createRequest(application)).thenReturn(applicationSolidResult);
        when(mapper.toApplicationResponse(applicationSolidResult)).thenReturn(applicationResponse);

        ResponseEntity<ApplicationResponse> result = signatureApiDelegate.create(applicationRequest);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
    }

    @Test
    void attach() {
        when(mapper.toApplicationAttachment(applicationAttachRequest)).thenReturn(applicationAttachment);
        when(useCase.attachDocument(applicationAttachment)).thenReturn(applicationAttachResult);
        when(mapper.toApplicationResponseAttach(applicationAttachResult)).thenReturn(applicationAttachResponse);

        ResponseEntity<ApplicationResponse> result = signatureApiDelegate.attach(applicationAttachRequest);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
    }

    @Test
    void sign() {
        when(mapper.toApplicationSignature(applicationSignatureRequest)).thenReturn(applicationSignature);
        when(useCase.signtureDocument(applicationSignature)).thenReturn(applicationSignatureResult);
        when(mapper.toApplicationResponseSign(applicationSignatureResult)).thenReturn(applicationSignatureResponse);

        ResponseEntity<ApplicationSignatureResponse> result = signatureApiDelegate.sign(applicationSignatureRequest);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
    }
}