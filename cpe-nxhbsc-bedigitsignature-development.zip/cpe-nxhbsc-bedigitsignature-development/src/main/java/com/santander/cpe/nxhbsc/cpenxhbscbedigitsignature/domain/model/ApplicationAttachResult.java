package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Application Attach Result class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationAttachResult {
private String result;
}
