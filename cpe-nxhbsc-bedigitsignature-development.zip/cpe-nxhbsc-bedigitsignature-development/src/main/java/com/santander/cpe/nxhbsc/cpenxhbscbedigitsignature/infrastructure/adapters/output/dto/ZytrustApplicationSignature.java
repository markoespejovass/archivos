package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Zytryst Application Signature Class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ZytrustApplicationSignature {
    private String signature;
}
