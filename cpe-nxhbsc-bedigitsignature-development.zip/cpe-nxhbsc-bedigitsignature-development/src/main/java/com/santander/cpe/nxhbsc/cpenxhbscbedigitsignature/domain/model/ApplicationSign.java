package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;


/**
 * The Application Sign class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationSign {
    private BigDecimal posX;

    private BigDecimal posY;

    private BigDecimal width;

    private BigDecimal height;

    private BigDecimal pageNumber;

    private String image;

    private String selfie;
}
