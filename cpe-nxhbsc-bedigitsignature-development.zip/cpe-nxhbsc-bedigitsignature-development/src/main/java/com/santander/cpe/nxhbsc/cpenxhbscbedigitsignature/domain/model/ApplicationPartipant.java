package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Application Participant class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationPartipant {
    private String documentType;

    private String documentNumber;

    private String firstNames;

    private String lastName;

    private String secondLastName;

    private String email;

    private String countryCode;

    private String mobileNumber;
}
