package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.mapper;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.Application;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachment;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignature;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSolidResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationStatusResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationAttachRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationSignatureRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationSignatureResponse;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * The Digital Signature Mapper.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Mapper(componentModel = "spring")
public interface DigitalSignatureMapper {

    /**
     * Convert to application
     *
     * @param applicationRequest the application Request.
     * @return A {@link Application}
     */
    Application toApplication (ApplicationRequest applicationRequest);

    /**
     * Convert to Application Attachment.
     *
     * @param applicationAttachRequest the application Attach Request.
     * @return A {@link ApplicationAttachment}
     */
    ApplicationAttachment toApplicationAttachment (
            ApplicationAttachRequest applicationAttachRequest);

    /**
     * Convert to Application Signature.
     *
     * @param applicationSignatureRequest the application signature request.
     *
     * @return A {@link ApplicationSignature}
     */
    ApplicationSignature toApplicationSignature (
            ApplicationSignatureRequest applicationSignatureRequest);

    /**
     * Convert to application Response
     *
     * @param response the response.
     * @return A {@link ApplicationResponse}
     */
    ApplicationResponse toApplicationResponse (
            ApplicationStatusResponse<ApplicationSolidResult> response);

    /**
     * Convert to Application Responser Attach.
     *
     * @param response the response.
     * @return A {@link ApplicationResponse}
     */
    ApplicationResponse toApplicationResponseAttach (
            ApplicationStatusResponse<ApplicationSolidResult> response);

    /**
     * Convert To Application Response Sign
     *
     * @param response the response.
     * @return A {@link ApplicationSignatureResponse}
     */
    ApplicationSignatureResponse toApplicationResponseSign (
            ApplicationStatusResponse<List<ApplicationSignResult>> response);
}
