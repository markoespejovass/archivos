package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.constants;

import lombok.experimental.UtilityClass;

/**
 * The constant Class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@UtilityClass
public final class Constant {

    /**
     * The POST ZYTRUST CREAR
     */
    public static final String POST_ZYTRUST_CREAR = "/api/solicitud/crear";
    /**
     * The POST ZYTRUST PROCESAR
     */
    public static final String POST_ZYTRUST_PROCESAR = "/api/solicitud/procesar";
    /**
     * The Response OK
     */
    public static final String RESPONSE_OK = "OK";
    /**
     * The Response Attach
     */
    public static final String RESPONSE_ATTACH = "Attach";
    /**
     *  THe Response signed
     */
    public static final String RESPONSE_SIGNED = "Signed";
    /**
     * The Response message
     */
    public static final String RESPONSE_MESSAGE = "Todas las operaciones se efectuaron correctamente";
    /**
     *  the Response signed document id
     */
    public static final String RESPONSE_SIGNED_DOCUMENT_ID = "001";
    /**
     * The Response SIgned document name
     */
    public static final String RESPONSE_SIGNED_DOCUMENT_NAME = "prueba.pdf";
    /**
     * The Response Signed Txn Id
     */
    public static final String RESPONSE_SIGNED_TXN_ID = "001";
    /**
     * The Response Signed document.
     */
    public static final String RESPONSE_SIGNED_DOCUMENT = "asdf6a8s7df6a8s7df68as7df6a87sdf6...";
    /**
     * The Response Code
     */
    public static final Integer RESPONSE_CODE = 8000;


}
