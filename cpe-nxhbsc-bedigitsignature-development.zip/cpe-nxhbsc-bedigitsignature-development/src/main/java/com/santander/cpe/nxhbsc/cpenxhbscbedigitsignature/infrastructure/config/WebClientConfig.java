package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

/**
 * The Web Client Config class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Configuration
@RequiredArgsConstructor
public class WebClientConfig {

  private final ApiProperties apiProperties;

  /**
   * the web client.
   *
   * @return A {@link WebClient} containing the webclient token.
   * @throws SSLException the ssl exception.
   */
  @Bean
  public WebClient webClient() throws SSLException {
    return WebClient.builder()
            .baseUrl(apiProperties.getBaseUrl())
            .clientConnector(new ReactorClientHttpConnector(createSharedHttpClient()))
            .build();
  }

  private HttpClient createSharedHttpClient() throws SSLException {
    var sslContext = SslContextBuilder.forClient()
            .trustManager(InsecureTrustManagerFactory.INSTANCE)
            .build();

    return HttpClient.create()
            .secure(t -> t.sslContext(sslContext).handlerConfigurator((SslHandler sslHandler) -> {}))
            .wiretap(true)
            .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, apiProperties.getTimeout())
            .responseTimeout(Duration.ofMillis(apiProperties.getTimeout()))
            .doOnConnected(conn -> conn
                    .addHandlerLast(new ReadTimeoutHandler(apiProperties.getTimeout(), TimeUnit.MILLISECONDS))
                    .addHandlerLast(new WriteTimeoutHandler(apiProperties.getTimeout(), TimeUnit.MILLISECONDS)));
  }
}
