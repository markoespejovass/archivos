package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.mapper;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.Application;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachment;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignature;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSolidResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationStatusResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustApplicationAttachment;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustApplicationRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustApplicationSignature;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustSignResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustSolidResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustStatusResponse;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

/**
 * The Zytrust Mapper.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Mapper(componentModel = "spring")
public interface ZytrustMapper {

    /**
     * Convert to Zytrust Application Request.
     *
     * @param application the application.
     * @return A {@link ZytrustApplicationRequest}
     */
    ZytrustApplicationRequest toZytrustApplicationRequest(Application application);

    /**
     * Convert To Zytrust Application Attachment
     *
     * @param applicationAttachment the application attachment.
     * @return A {@link ZytrustApplicationAttachment}
     */
    ZytrustApplicationAttachment toZytrustApplicationAttachment(
            ApplicationAttachment applicationAttachment);

    /**
     * Convert to Zytrust Application Signature.
     *
     * @param applicationSignature the application Signature.
     * @return A {@link ZytrustApplicationSignature}
     */
    ZytrustApplicationSignature toZytrustApplicationSignature(
            ApplicationSignature applicationSignature);

    /**
     * Convert to Solid Result Application Status Response
     * @param response the response.
     * @return A {@link ApplicationStatusResponse<ApplicationSolidResult>}
     */
    ApplicationStatusResponse<ApplicationSolidResult> toSolidResultApplicationStatusResponse(
            ZytrustStatusResponse<ZytrustSolidResponse> response);

    /**
     * Convert to Application Attach Result Application Status Response.
     *
     * @param zytrustStatusResponse the Zytryst Status Response.
     * @return A {@link ApplicationStatusResponse<ApplicationSolidResult>}
     */
    @Mapping(target = "data", ignore = true)
    ApplicationStatusResponse<ApplicationSolidResult> toApplicationAttachResultApplicationStatusResponse(
            ZytrustStatusResponse<String> zytrustStatusResponse);

    /**
     * Convert to Application Sign Result Application Status Response.
     *
     * @param zytrustSignResponseZytrustStatusResponse the Zytrust Sign Response Zytrust Status Response.
     * @return A {@link ApplicationStatusResponse<List<ApplicationSignResult>>}
     */
    ApplicationStatusResponse<List<ApplicationSignResult>> toApplicationSignResultApplicationStatusResponse(
            ZytrustStatusResponse<List<ZytrustSignResponse>> zytrustSignResponseZytrustStatusResponse);

    /**
     * Set default data
     *
     * @param defaultData the default data.
     */
    @AfterMapping
    default void setDefaultData(@MappingTarget ApplicationStatusResponse<ApplicationSolidResult> defaultData){
        defaultData.setData(
                ApplicationSolidResult.builder().solid("Attached").build()
        );
    }
}
