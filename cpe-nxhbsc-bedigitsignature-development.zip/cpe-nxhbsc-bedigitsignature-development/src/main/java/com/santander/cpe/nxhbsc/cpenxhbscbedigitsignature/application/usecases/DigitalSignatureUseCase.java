package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.usecases;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.Application;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachment;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignature;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSolidResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationStatusResponse;

import java.util.List;

/**
 * The digital signature use case inteface.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
public interface DigitalSignatureUseCase {

    /**
     * Create new request
     *
     * @param application the application.
     * @return A {@link ApplicationStatusResponse} the result
     */
    ApplicationStatusResponse<ApplicationSolidResult> createRequest(Application application);

    /**
     * Attach document.
     *
     * @param applicationAttachment the application request attrachment
     * @return A {@link ApplicationStatusResponse} the result
     */
    ApplicationStatusResponse<ApplicationSolidResult> attachDocument(ApplicationAttachment applicationAttachment);

    /**
     * Sign a document.
     *
     * @param applicationSignature the application signature request.
     * @return A {@link ApplicationStatusResponse} the result
     */
    ApplicationStatusResponse<List<ApplicationSignResult>> signtureDocument(ApplicationSignature applicationSignature);
}
