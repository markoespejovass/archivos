package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Application Status Response Class.
 *
 * @param <T> The generic type contain in body response.
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationStatusResponse <T>{
    private String error;
    @JsonProperty(value = "codigo")
    private Integer code;
    @JsonProperty(value = "mensaje")
    private String message;
    private T data;
}
