package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * The Api properties Class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "api.zytrust")
public class ApiProperties {
  private String baseUrl;
  private String secretKey;
  private String userName;
  private String password;
  private Integer timeout;
}
