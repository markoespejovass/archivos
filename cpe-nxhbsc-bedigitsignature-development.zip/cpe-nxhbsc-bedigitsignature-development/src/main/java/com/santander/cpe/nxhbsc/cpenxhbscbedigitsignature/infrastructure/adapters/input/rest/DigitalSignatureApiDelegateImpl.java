package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.usecases.DigitalSignatureUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.mapper.DigitalSignatureMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationAttachRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationSignatureRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.input.rest.data.ApplicationSignatureResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * The Digital signature api delegate impl class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DigitalSignatureApiDelegateImpl implements SignatureApiDelegate {

    private final DigitalSignatureUseCase useCase;
    private final DigitalSignatureMapper mapper;

    /**
     * Create request.
     *
     * @param applicationRequest Data structure containing the request. (required)
     * @return A {@link ResponseEntity<ApplicationResponse>} the response.
     */
    @Override
    public ResponseEntity<ApplicationResponse> create(ApplicationRequest applicationRequest) {
        var response = useCase.createRequest(mapper.toApplication(applicationRequest));
        return ResponseEntity.ok(mapper.toApplicationResponse(response));
    }

    /**
     * Attach document.
     *
     * @param applicationAttachRequest Data structure containing the request
     *                                 for attach document. (required)
     * @return A {@link ResponseEntity<ApplicationResponse>} the response.
     */
    @Override
    public ResponseEntity<ApplicationResponse> attach(ApplicationAttachRequest applicationAttachRequest) {
        var response = useCase.attachDocument(mapper.toApplicationAttachment(applicationAttachRequest));
        return ResponseEntity.ok(mapper.toApplicationResponseAttach(response));
    }

    /**
     * Sign document attached
     *
     * @param applicationSignatureRequest Data structure containing the signature for sign the document. (required)
     * @return A {@link ResponseEntity<ApplicationSignatureResponse>} the response.
     */
    @Override
    public ResponseEntity<ApplicationSignatureResponse> sign(ApplicationSignatureRequest applicationSignatureRequest) {
        var response = useCase.signtureDocument(mapper.toApplicationSignature(applicationSignatureRequest));
        return ResponseEntity.ok(mapper.toApplicationResponseSign(response));
    }

}
