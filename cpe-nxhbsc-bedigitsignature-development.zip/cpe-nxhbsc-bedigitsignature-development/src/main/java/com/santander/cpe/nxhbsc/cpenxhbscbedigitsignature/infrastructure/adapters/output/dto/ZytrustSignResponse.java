package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Zytrust Sign Response Class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ZytrustSignResponse {
    @JsonProperty(value = "idDocumento")
    private String documentId;
    @JsonProperty(value = "nombreDocumento")
    private String documentName;
    private String txnId;
    @JsonProperty(value = "documento")
    private String document;
}
