package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.ports.input;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.ports.output.ZytrustServiceOutPutPort;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.usecases.DigitalSignatureUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.Application;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachment;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignature;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSolidResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationStatusResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * The Digital signature input port.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@RequiredArgsConstructor
public class DigitalSignatureInputPort implements DigitalSignatureUseCase {

    private final ZytrustServiceOutPutPort zytrustServiceOutPutPort;

    /**
     * Create new request
     *
     * @param application the application.
     * @return A {@link ApplicationAttachResult} the result
     */
    @Override
    public ApplicationStatusResponse<ApplicationSolidResult> createRequest(Application application) {
        return zytrustServiceOutPutPort.createRequest(application);
    }

    /**
     * Attach document.
     *
     * @param applicationAttachment the application request attrachment
     * @return A {@link ApplicationAttachResult} the result
     */
    @Override
    public ApplicationStatusResponse<ApplicationSolidResult> attachDocument(
            ApplicationAttachment applicationAttachment) {
        return zytrustServiceOutPutPort.attachDocument(applicationAttachment);
    }

    /**
     * Sign a document.
     *
     * @param applicationSignature the application signature request.
     * @return A {@link ApplicationAttachResult} the result
     */
    @Override
    public ApplicationStatusResponse<List<ApplicationSignResult>> signtureDocument(
            ApplicationSignature applicationSignature) {
        return zytrustServiceOutPutPort.signtureDocument(applicationSignature);
    }
}
