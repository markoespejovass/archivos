package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.client;

import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.application.ports.output.ZytrustServiceOutPutPort;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.Application;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationAttachment;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSignature;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationSolidResult;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model.ApplicationStatusResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustSignResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustSolidResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto.ZytrustStatusResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.mapper.ZytrustMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.constants.Constant;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * The Zytrust adapter class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@RequiredArgsConstructor
public class ZytrustAdapter implements ZytrustServiceOutPutPort {

    private final WebClient webClient;
    private final ZytrustMapper mapper;

    /**
     * Create new request
     *
     * @param application the application.
     * @return A {@link ApplicationAttachResult} the result
     */
    @Override
    public ApplicationStatusResponse<ApplicationSolidResult> createRequest(Application application) {
        var request = mapper.toZytrustApplicationRequest(application);
                return webClient.post()
                .uri(Constant.POST_ZYTRUST_CREAR)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<
                        ZytrustStatusResponse<ZytrustSolidResponse>>() {
                })
                .onErrorResume(ex -> Mono.just(getMockZytrustSolidResponse()))
                .map(mapper::toSolidResultApplicationStatusResponse)
                .block();

    }

    /**
     * Attach document.
     *
     * @param applicationAttachment the application request attrachment
     * @return A {@link ApplicationAttachResult} the result
     */
    @Override
    public ApplicationStatusResponse<ApplicationSolidResult> attachDocument(
            ApplicationAttachment applicationAttachment) {
        var request = mapper.toZytrustApplicationAttachment(applicationAttachment);
        return webClient.post()
                .uri(Constant.POST_ZYTRUST_PROCESAR)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<
                        ZytrustStatusResponse<String>>() {
                })
                .onErrorResume(ex -> Mono.just(getMockZytrustAttachResponse()))
                .map(mapper::toApplicationAttachResultApplicationStatusResponse)
                .block();

    }

    /**
     * Sign a document.
     *
     * @param applicationSignature the application signature request.
     * @return A {@link ApplicationAttachResult} the result
     */
    @Override
    public ApplicationStatusResponse<List<ApplicationSignResult>> signtureDocument(
            ApplicationSignature applicationSignature) {
        var request = mapper.toZytrustApplicationSignature(applicationSignature);
        return webClient.post()
                .uri(Constant.POST_ZYTRUST_PROCESAR)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<ZytrustStatusResponse<List<ZytrustSignResponse>>>() {
                })
                .onErrorResume(ex -> Mono.just(getMockZytrustResponse()))
                .map(mapper::toApplicationSignResultApplicationStatusResponse)
                .block();
    }


    private static ZytrustStatusResponse<ZytrustSolidResponse> getMockZytrustSolidResponse() {
        return ZytrustStatusResponse.<ZytrustSolidResponse>builder()
                .error(Constant.RESPONSE_OK)
                .code(Constant.RESPONSE_CODE)
                .message(Constant.RESPONSE_MESSAGE)
                .data(ZytrustSolidResponse.builder()
                        .solid("123456")
                        .build())
                .build();
    }

    private static ZytrustStatusResponse<String> getMockZytrustAttachResponse() {
        return ZytrustStatusResponse.<String>builder()
                .error(Constant.RESPONSE_ATTACH)
                .code(Constant.RESPONSE_CODE)
                .message(Constant.RESPONSE_MESSAGE)
                .build();
    }

    private static ZytrustStatusResponse<List<ZytrustSignResponse>> getMockZytrustResponse() {
        return ZytrustStatusResponse.<List<ZytrustSignResponse>>builder()
                .error(Constant.RESPONSE_SIGNED)
                .code(Constant.RESPONSE_CODE)
                .message(Constant.RESPONSE_MESSAGE)
                .data(List.of(ZytrustSignResponse.builder()
                        .documentId(Constant.RESPONSE_SIGNED_DOCUMENT_ID)
                        .documentName(Constant.RESPONSE_SIGNED_DOCUMENT_NAME)
                        .txnId(Constant.RESPONSE_SIGNED_TXN_ID)
                        .document(Constant.RESPONSE_SIGNED_DOCUMENT)
                        .build()))
                .build();
    }
}
