package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.infrastructure.adapters.output.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Zytrust Solid Response Class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ZytrustSolidResponse {
    private String solid;
}
