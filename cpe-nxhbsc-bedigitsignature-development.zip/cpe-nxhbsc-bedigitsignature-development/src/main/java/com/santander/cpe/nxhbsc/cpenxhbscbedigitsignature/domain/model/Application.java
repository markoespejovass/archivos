package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * The Application class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Application {
    private String contractNumber;
    private String businessUnit;
    private List<ApplicationParticipant> participants;
}
