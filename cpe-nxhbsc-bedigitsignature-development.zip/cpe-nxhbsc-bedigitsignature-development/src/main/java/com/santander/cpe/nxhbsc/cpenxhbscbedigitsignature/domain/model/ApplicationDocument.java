package com.santander.cpe.nxhbsc.cpenxhbscbedigitsignature.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * The Application Document Class.
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApplicationDocument {
    private String documentId;

    private String documentName;

    private String documentContent;

    private Boolean addFile;

    private List<ApplicationAttachParticipant> participants;
}
