package com.example.demo.infra.exception;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.example.demo.infra.TestController;
import com.example.demo.infrastructure.exception.GlobalExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(controllers = TestController.class)
@Import(GlobalExceptionHandler.class)
class GlobalExceptionHandlerTest {

  @Autowired private MockMvc mockMvc;
  /*
   @Test
   void shouldReturn404WhenResourceNotFound() throws Exception {

     mockMvc
         .perform(get("/test/not-found"))
         .andExpect(status().isNotFound())
         .andExpect(jsonPath("$.code").value("404"))
         .andExpect(jsonPath("$.name").value("RESOURCE_NOT_FOUND"));
   }

  */
}
