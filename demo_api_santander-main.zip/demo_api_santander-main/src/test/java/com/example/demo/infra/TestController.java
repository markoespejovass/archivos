package com.example.demo.infra;

import com.example.demo.domain.exception.DomainException;
import com.example.demo.domain.exception.ErrorCode;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

  @GetMapping("/test/not-found")
  public String test() {
    throw new DomainException(ErrorCode.RESOURCE_NOT_FOUND);
  }
}
