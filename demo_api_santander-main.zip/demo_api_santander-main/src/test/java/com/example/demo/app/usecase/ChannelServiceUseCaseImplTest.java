package com.example.demo.app.usecase;

import com.example.demo.application.port.in.ChannelServiceUseCase;
import com.example.demo.application.port.out.ChannelServiceRepositoryPort;
import com.example.demo.domain.model.chanelService.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

public class ChannelServiceUseCaseImplTest {

  @MockBean private ChannelServiceRepositoryPort channelServiceRepositoryPort;
  @Autowired private ChannelServiceUseCase channelServiceUseCase;
  /*
   @Test
   void testGetServices() {
     Service service = new Service();
     service.setServiceId("10001");
     ServicesListRequest request = new ServicesListRequest();
     request.setServices(List.of(GetServicesData.builder().service(service).build()));
     request.setLinks(new Links());

     ServicesListResponse expectResponse = new ServicesListResponse();
     expectResponse.setServices(List.of(GetServicesData.builder().service(service).build()));
     expectResponse.setLinks(new Links());

     Mockito.when(channelServiceRepositoryPort.getListServices(any()))
         .thenReturn(Mono.just(expectResponse));

     Mono<ServicesListResponse> response = channelServiceUseCase.getServices(request);
     Assertions.assertEquals(
         "10001", response.block().getServices().get(0).getService().getServiceId(), "Are equals");
   }

  */
}
