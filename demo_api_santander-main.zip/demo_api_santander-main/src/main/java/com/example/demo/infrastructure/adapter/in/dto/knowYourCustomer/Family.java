package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Family {

  private String productFamilyId;
  private String name;
}
