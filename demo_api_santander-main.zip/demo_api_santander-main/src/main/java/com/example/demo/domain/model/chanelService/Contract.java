package com.example.demo.domain.model.chanelService;

import lombok.Data;

@Data
public class Contract {

  private String contractId;
}
