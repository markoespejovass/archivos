package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.chanelService.ServicesListRequest;
import com.example.demo.domain.model.chanelService.ServicesListResponse;
import com.example.demo.infrastructure.adapter.in.dto.chanelService.ServicesListRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.chanelService.ServicesListResponseDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ChannelServiceMapper {

  ServicesListRequest ServicesListRequestDtoToServicesListRequest(
      ServicesListRequestDTO contractRequestDTO);

  ServicesListResponseDTO ServicesListResponseToServicesListResponseDTO(
      ServicesListResponse generateContractIdentifiersResponse);
}
