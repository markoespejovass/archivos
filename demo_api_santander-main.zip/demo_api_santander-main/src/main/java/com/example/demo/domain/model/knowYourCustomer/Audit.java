package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Audit {

  private String lastUpdateDate;
  private String lastUpdateProcess;
  private String expirationDate;
  private String completionDate;
  private String submissionDate;
}
