package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class WrapperPostUpdateDocumentVersionRequestDTO {

  private Version version;

  private String documentId;

  private String mimeType;

  private String name;

  private String typeCode;

  private String folderReference;

  private String aclReference;

  private List<Owner> owners;

  private List<DocumentProperty> documentProperties;

  private Map<String, Object> customMetadata;
}
