package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Envelope")
public class GetTrackingForUserResponseDTO {

    @XmlElement(name = "Body")
    private BodyResponse body;
}
