package com.example.demo.infrastructure.config.error;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;

@Component
public class WebClientNetworkErrorFilter {

  private final WebClientNetworkErrorMapper mapper;

  public WebClientNetworkErrorFilter(WebClientNetworkErrorMapper mapper) {
    this.mapper = mapper;
  }

  public ExchangeFilterFunction networkErrorFilter() {
    return (request, next) -> next.exchange(request).onErrorMap(mapper::map);
  }
}
