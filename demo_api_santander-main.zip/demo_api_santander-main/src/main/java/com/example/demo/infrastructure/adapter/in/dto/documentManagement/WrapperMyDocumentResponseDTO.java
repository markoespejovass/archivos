package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class WrapperMyDocumentResponseDTO {

  private String documentId;

  private String versionCode;
}
