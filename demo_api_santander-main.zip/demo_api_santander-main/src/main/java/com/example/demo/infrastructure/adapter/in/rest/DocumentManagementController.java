package com.example.demo.infrastructure.adapter.in.rest;

import com.example.demo.application.port.in.DocumentManagementUseCase;
import com.example.demo.infrastructure.adapter.in.dto.contracts.ContractResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement.*;
import com.example.demo.infrastructure.adapter.in.dto.documentManagement.*;
import com.example.demo.infrastructure.adapter.in.mapper.DocumentManagementMapper;
import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/documentManagement")
@Tag(name = "Document Management", description = "API para la gestión de Document.")
public class DocumentManagementController {

  private final DocumentManagementUseCase documentManagementUseCase;
  private final DocumentManagementMapper mapper;

  public DocumentManagementController(
      DocumentManagementUseCase documentManagementUseCase, DocumentManagementMapper mapper) {
    this.documentManagementUseCase = documentManagementUseCase;
    this.mapper = mapper;
  }

  @PostMapping("/download_document")
  @Operation(
          summary = "Descarga un documento especifico.",
          description = "Descarga un documento especifico",
          method = "POST",
          parameters = {
          @Parameter(
                  name = "origin-vertical",
                  description = "Cabecera de negocio correspondiente al document",
                  example = "Customers",
                  in = ParameterIn.HEADER)
  })
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "200",
                          description = "OK",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = WrapperGetDocumentsResponseDTO.class))),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<WrapperGetDocumentsResponseDTO> postDownloadDocument(
      @RequestBody WrapperGetDocumentsRequestDTO criteria) {
    return documentManagementUseCase
        .postDownloadDocument(
            mapper.WrapperGetDocumentsRequestDtoToWrapperGetDocumentsRequest(criteria))
        .map(mapper::WrapperGetDocumentsResponseToWrapperGetDocumentsResponseDTO);
  }

  @PostMapping("/search_documents")
  @Operation(
          summary = "Busca un listado de documentos.",
          description = "Busca un listado de documentos",
          method = "POST",
          parameters = {
                  @Parameter(
                          name = "origin-vertical",
                          description = "Cabecera de negocio correspondiente al document",
                          example = "Customers",
                          in = ParameterIn.HEADER)
          })
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "200",
                          description = "OK",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = WrapperPostSearchDocumentsResponseDTO.class))),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<WrapperPostSearchDocumentsResponseDTO> postSearchDocuments(
      @RequestBody WrapperPostSearchDocumentsRequestDTO criteria) {
    return documentManagementUseCase
        .postSearchDocuments(
            mapper.WrapperPostSearchDocumentsRequestDtoToWrapperPostSearchDocumentsRequest(
                criteria))
        .map(mapper::WrapperPostSearchDocumentsResponseToWrapperPostSearchDocumentsResponseDTO);
  }

  @PatchMapping("/update_document")
  @Operation(
          summary = "Actualiza un documento.",
          description = "Actualiza la versión de un documento específico almacenado en el servicio de gestión de documentos",
          method = "POST",
          parameters = {
                  @Parameter(
                          name = "origin-vertical",
                          description = "Cabecera de negocio correspondiente al document",
                          example = "Customers",
                          in = ParameterIn.HEADER)
          })
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "201",
                          description = "Created",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = WrapperPostDocumentsResponseDTO.class))),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<WrapperPostDocumentsResponseDTO> postUpdateDocument(
      @RequestBody WrapperPostUpdateDocumentVersionRequestDTO criteria) {
    return documentManagementUseCase
        .postUpdateDocument(
            mapper
                .WrapperPostUpdateDocumentVersionRequestDtoToWrapperPostUpdateDocumentVersionRequest(
                    criteria))
        .map(mapper::WrapperPostDocumentsResponseToWrapperPostDocumentsResponseDTO);
  }

  @PatchMapping("/upload_document")
  @Operation(
          summary = "Envia metadatos de un documento.",
          description = "Envía los metadatos de un documento para ser subido al servicio de gestión de documentos.",
          method = "POST",
          parameters = {
                  @Parameter(
                          name = "origin-vertical",
                          description = "Cabecera de negocio correspondiente al document",
                          example = "Customers",
                          in = ParameterIn.HEADER)
          })
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "201",
                          description = "Created",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = WrapperPostDocumentsRequestDTO.class))),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<WrapperPostDocumentsResponseDTO> postUploadDocument(
      @RequestBody WrapperPostDocumentsRequestDTO criteria) {
    return documentManagementUseCase
        .postUploadDocument(
            mapper.WrapperPostDocumentsRequestDtoToWrapperPostDocumentsRequest(criteria))
        .map(mapper::WrapperPostDocumentsResponseToWrapperPostDocumentsResponseDTO);
  }
}
