package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

import java.util.List;

@Data
public class RESULT {

    @XmlElement(name = "SUCCESS")
    private Boolean sUCCESS;

    @XmlElement(name = "Mailing")
    private List<Mailing> mailing;
}
