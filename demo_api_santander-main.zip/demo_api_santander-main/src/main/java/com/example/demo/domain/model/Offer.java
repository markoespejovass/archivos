package com.example.demo.domain.model;

import java.math.BigDecimal;

public record Offer(
        Integer ciaSegId,
        String ciaSeg,
        Integer productoId,
        String producto,
        Integer planId,
        String plan,
        Integer monedaId,
        String moneda,
        BigDecimal primaNeta,
        BigDecimal derechos,
        BigDecimal impuestos,
        BigDecimal primaTotal,
        Integer frecuenciaPagoId,
        String frecuenciaPago,
        Integer tipoVigenciaId,
        String tipoVigencia,
        String tasa
) {
}
