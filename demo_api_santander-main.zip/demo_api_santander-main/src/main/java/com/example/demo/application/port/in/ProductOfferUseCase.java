package com.example.demo.domain.port.in;

import com.example.demo.domain.model.ProductOffer;
import com.example.demo.domain.model.ProductOfferCriteria;
import reactor.core.publisher.Mono;

public interface ProductOfferUseCase {

  Mono<ProductOffer> getProductOffers(ProductOfferCriteria criteria);
}
