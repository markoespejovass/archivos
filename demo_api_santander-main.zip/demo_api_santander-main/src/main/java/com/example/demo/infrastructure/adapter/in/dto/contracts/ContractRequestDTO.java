package com.example.demo.infrastructure.adapter.in.dto.contracts;

import com.example.demo.domain.model.contracts.Center;
import com.example.demo.domain.model.contracts.ContractIdentification;
import com.example.demo.domain.model.contracts.Product;
import lombok.Data;

@Data
public class ContractRequestDTO {

  private Product product;
  private Center center;
  private Boolean hasOnlyNationalIdentification;
  private ContractIdentification contractIdentification;
}
