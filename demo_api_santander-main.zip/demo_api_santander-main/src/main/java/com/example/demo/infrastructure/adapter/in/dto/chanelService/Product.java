package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import lombok.Data;

@Data
public class Product {

  private Contract contract;

  private ChannelAccessAgreementInformation channelAccessAgreementInformation;
}
