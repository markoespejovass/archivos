package com.example.demo.domain.model;

import java.time.LocalDate;

public record InsuredHolder(Integer tipoDocId,
                            String nroDoc,
                            String nombres,
                            String fecNac) {
}
