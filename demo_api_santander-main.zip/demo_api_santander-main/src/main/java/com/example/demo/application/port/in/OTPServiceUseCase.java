package com.example.demo.application.port.in;

import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailResponse;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserResponse;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportRequest;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportResponse;
import com.example.demo.domain.model.otp.saveMailing.SaveMailRequest;
import com.example.demo.domain.model.otp.saveMailing.SaveMailResponse;
import com.example.demo.domain.model.otp.sendMailing.RequestOTP;
import com.example.demo.domain.model.otp.sendMailing.ResponseOTP;
import reactor.core.publisher.Mono;

public interface OTPServiceUseCase {

    Mono<ResponseOTP> sendMailing(Mono<RequestOTP> criteria);
    Mono<GetReportResponse> getReportIdByDate(Mono<GetReportRequest> criteria);
    Mono<GetTrackingForUserResponse> getAggregateTrackingForUser(Mono<GetTrackingForUserRequest> criteria);
    Mono<GetTrackingForMailResponse> getAggregateTrackingForMailing(Mono<GetTrackingForMailRequest> criteria);
    Mono<SaveMailResponse> saveMailing(Mono<SaveMailRequest> criteria);
}
