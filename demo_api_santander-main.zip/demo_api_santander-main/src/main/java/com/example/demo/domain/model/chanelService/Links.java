package com.example.demo.domain.model.chanelService;

import lombok.Data;

@Data
public class Links {

  private Link _first;
  private Link _prev;
  private Link _next;
}
