package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.documentManagement.*;
import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperGetDocumentsRequest;
import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperGetDocumentsResponse;
import com.example.demo.domain.model.documentManagement.postSearchDocuments.WrapperPostSearchDocumentsRequest;
import com.example.demo.domain.model.documentManagement.postSearchDocuments.WrapperPostSearchDocumentsResponse;
import com.example.demo.domain.model.documentManagement.postUpdateDocument.WrapperPostUpdateDocumentVersionRequest;
import com.example.demo.infrastructure.adapter.in.dto.documentManagement.*;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DocumentManagementMapper {

  WrapperGetDocumentsRequest WrapperGetDocumentsRequestDtoToWrapperGetDocumentsRequest(
      WrapperGetDocumentsRequestDTO wrapperGetDocumentsRequestDTO);

  WrapperGetDocumentsResponseDTO WrapperGetDocumentsResponseToWrapperGetDocumentsResponseDTO(
      WrapperGetDocumentsResponse wrapperGetDocumentsResponse);

  WrapperPostSearchDocumentsRequest
      WrapperPostSearchDocumentsRequestDtoToWrapperPostSearchDocumentsRequest(
          WrapperPostSearchDocumentsRequestDTO wrapperPostSearchDocumentsRequestDTO);

  WrapperPostSearchDocumentsResponseDTO
      WrapperPostSearchDocumentsResponseToWrapperPostSearchDocumentsResponseDTO(
          WrapperPostSearchDocumentsResponse wrapperPostSearchDocumentsResponse);

  WrapperPostUpdateDocumentVersionRequest
      WrapperPostUpdateDocumentVersionRequestDtoToWrapperPostUpdateDocumentVersionRequest(
          WrapperPostUpdateDocumentVersionRequestDTO wrapperPostUpdateDocumentVersionRequestDTO);

  WrapperPostDocumentsResponseDTO WrapperPostDocumentsResponseToWrapperPostDocumentsResponseDTO(
      WrapperPostDocumentsResponse wrapperPostDocumentsResponse);

  WrapperPostDocumentsRequest WrapperPostDocumentsRequestDtoToWrapperPostDocumentsRequest(
      WrapperPostDocumentsRequestDTO wrapperPostDocumentsRequestDTO);
}
