package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class RequiredDocuments {

  private String documentLabel;
  private Document document;
}
