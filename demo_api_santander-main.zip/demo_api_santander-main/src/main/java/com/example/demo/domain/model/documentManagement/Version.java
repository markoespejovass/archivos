package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class Version {

  private String label;
}
