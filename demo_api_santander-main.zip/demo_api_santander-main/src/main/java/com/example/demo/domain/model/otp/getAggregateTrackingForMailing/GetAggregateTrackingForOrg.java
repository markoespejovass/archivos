package com.example.demo.domain.model.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class GetAggregateTrackingForOrg {

    @XmlElement(name = "PRIVATE")
    private String pRIVATE;

    @XmlElement(name = "SENT")
    private String sENT;

    @XmlElement(name = "DATE_START")
    private String dATESTART;

    @XmlElement(name = "DATE_END")
    private String dATEEND;

}
