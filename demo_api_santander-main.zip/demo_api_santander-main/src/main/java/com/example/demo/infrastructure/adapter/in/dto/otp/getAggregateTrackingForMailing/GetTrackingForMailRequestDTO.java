package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Envelope")
public class GetTrackingForMailRequestDTO {

    @XmlElement(name = "Body")
    private BodyRequest body;

}
