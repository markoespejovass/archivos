package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class WrapperPostDocumentsRequest {

  private WrapperMyDocumentRequest document;
  private App caller_information;
}
