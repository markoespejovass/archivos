package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Product {

  private String productCode;
  private String productDescription;
  private Family family;
}
