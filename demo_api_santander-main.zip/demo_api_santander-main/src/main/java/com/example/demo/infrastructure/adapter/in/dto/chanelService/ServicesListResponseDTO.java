package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import java.util.List;
import lombok.Data;

@Data
public class ServicesListResponseDTO {

  private List<GetServicesData> services;
  private Links links;
}
