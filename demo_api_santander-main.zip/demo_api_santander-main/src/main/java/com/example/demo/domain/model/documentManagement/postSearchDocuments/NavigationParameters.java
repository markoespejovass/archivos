package com.example.demo.domain.model.documentManagement.postSearchDocuments;

import lombok.Data;

@Data
public class NavigationParameters {

  private String _limit;

  private String _offset;
}
