package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class WrapperGetDocumentsResponseDTO {

  private LinkReference access_information;
}
