package com.example.demo.domain.model.knowYourCustomer;

import com.example.demo.domain.model.dataConsentManagement.ValidityPeriod;
import java.util.List;
import lombok.Data;

@Data
public class Score {

  private String code;
  private String value;
  private ValidityPeriod validityPeriod;
  private List<Reason> reasons;
}
