package com.example.demo.domain.model.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class Mailing {
    @XmlElement(name = "ReportId")
    private Integer reportId;

    @XmlElement(name = "SentTS")
    private String sentTS;
}
