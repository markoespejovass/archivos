package com.example.demo.domain.model.documentManagement.postDownloadDocument;

import com.example.demo.domain.model.documentManagement.LinkReference;
import lombok.Data;

@Data
public class WrapperGetDocumentsResponse {

  private LinkReference access_information;
}
