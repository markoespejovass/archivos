package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import com.example.demo.infrastructure.adapter.in.dto.operationControl.Link;
import lombok.Data;

@Data
public class Links {

  private Link _first;
  private Link _prev;
  private Link _next;
  private Link _last;
}
