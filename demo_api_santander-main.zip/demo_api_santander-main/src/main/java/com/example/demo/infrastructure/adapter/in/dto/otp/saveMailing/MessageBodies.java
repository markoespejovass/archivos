package com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class MessageBodies {

    @XmlElement(name = "HTMLBody")
    private String hTMLBody;

    @XmlElement(name = "AOLBody")
    private String aOLBody;
}
