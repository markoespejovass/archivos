package com.example.demo.application.port.in;

import com.example.demo.domain.model.contracts.GenerateContractIdentifiersData;
import com.example.demo.domain.model.contracts.GenerateContractIdentifiersResponse;
import reactor.core.publisher.Mono;

public interface ContractsUseCase {

  Mono<GenerateContractIdentifiersResponse> postContractId(
      GenerateContractIdentifiersData criteria);
}
