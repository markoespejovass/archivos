package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import lombok.Data;

@Data
public class ChannelAccessAgreementInformation {

  private Boolean operativityIndicator;
}
