package com.example.demo.domain.model.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.*;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetReportResponse {

    @XmlElement(name = "Body")
    private BodyResponse body;
}
