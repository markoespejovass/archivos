package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class WrapperPostKycResolutionResponse {

  private String kycResolutionId;

  private String localReference;

  private Risk risk;

  private Requirements requirements;
}
