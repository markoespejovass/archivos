package com.example.demo.domain.model.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class BodyRequest {

    @XmlElement(name = "GetSentMailingsForUser")
    private GetSentMailingsForUser getSentMailingsForUser;
}
