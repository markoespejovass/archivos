package com.example.demo.application.usecase;

import com.example.demo.application.port.in.OperationControlsUseCase;
import com.example.demo.application.port.out.OperationControlRepositoryPort;
import com.example.demo.domain.model.operationControl.WrapperGetOperabilityStatusRequest;
import com.example.demo.domain.model.operationControl.WrapperGetOperabilityStatusResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class OperationControlUseCaseImpl implements OperationControlsUseCase {

  private final OperationControlRepositoryPort operationControlRepositoryPort;

  @Override
  public Mono<WrapperGetOperabilityStatusResponse> getOperationControl(
      WrapperGetOperabilityStatusRequest criteria) {
    return operationControlRepositoryPort.getOperationControl(criteria);
  }
}
