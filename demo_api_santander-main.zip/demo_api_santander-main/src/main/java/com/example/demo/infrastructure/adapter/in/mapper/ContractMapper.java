package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.contracts.GenerateContractIdentifiersData;
import com.example.demo.domain.model.contracts.GenerateContractIdentifiersResponse;
import com.example.demo.infrastructure.adapter.in.dto.contracts.ContractRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.contracts.ContractResponseDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ContractMapper {

  GenerateContractIdentifiersData ContractRequestDtoToGenerateContractIdentifiersData(
      ContractRequestDTO contractRequestDTO);

  ContractResponseDTO GenerateContractIdentifiersResponseToContractResponseDTO(
      GenerateContractIdentifiersResponse generateContractIdentifiersResponse);
}
