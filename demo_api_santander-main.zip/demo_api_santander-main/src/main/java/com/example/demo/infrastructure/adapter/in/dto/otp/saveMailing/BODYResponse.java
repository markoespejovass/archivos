package com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class BODYResponse {

    @XmlElement(name = "RESULT")
    private RESULT rESULT;

}
