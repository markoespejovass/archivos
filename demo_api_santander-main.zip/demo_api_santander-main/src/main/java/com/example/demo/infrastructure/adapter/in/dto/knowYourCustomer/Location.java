package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Location {
  private String code;
  private String name;
}
