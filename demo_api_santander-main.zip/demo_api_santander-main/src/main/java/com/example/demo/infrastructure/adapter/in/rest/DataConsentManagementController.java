package com.example.demo.infrastructure.adapter.in.rest;

import com.example.demo.application.port.in.DataConsentManagementUseCase;
import com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement.*;
import com.example.demo.infrastructure.adapter.in.dto.documentManagement.WrapperGetDocumentsResponseDTO;
import com.example.demo.infrastructure.adapter.in.mapper.DataConsentManagementMapper;
import java.util.List;
import java.util.Map;

import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/dataConsent")
@Tag(name = "Data Consent", description = "API para la gestión de Data Consent.")
public class DataConsentManagementController {

  private final DataConsentManagementUseCase dataConsentManagementUseCase;
  private final DataConsentManagementMapper mapper;

  public DataConsentManagementController(
      DataConsentManagementUseCase dataConsentManagementUseCase,
      DataConsentManagementMapper mapper) {
    this.dataConsentManagementUseCase = dataConsentManagementUseCase;
    this.mapper = mapper;
  }

  @PostMapping("/{partyId}")
  @Operation(
          summary = "Crea acuerdo de consentimiento.",
          description = "Crea un acuerdo de consentimiento para una parte específica. Si el acuerdo de consentimiento que se va a crear es un acuerdo principal, todos sus acuerdos subordinados también se crean automáticamente.",
          method = "POST")
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "200",
                          description = "OK",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = WrapperPostConsentResponseBodyDTO.class))),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<List<WrapperPostConsentResponseBodyDTO>> postDataConsent(
      @RequestBody WrapperPostConsentRequestBodyDTO criteria, @PathVariable String partyId) {
    return dataConsentManagementUseCase
        .postConsent(
            mapper.WrapperPostConsentRequestBodyDtoToWrapperPostConsentRequestBody(criteria),
            partyId)
        .map(mapper::WrapperPostConsentResponseBodyToWrapperPostConsentResponseBodyDTO)
        .map(List::of);
  }

  @GetMapping("/{partyId}")
  @Operation(
          summary = "Devuelve listado de acuerdos de consetimiento.",
          description = "Recupera una lista de acuerdos de consentimiento para un party específica.",
          method = "POST")
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "200",
                          description = "OK",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = WrapperGetConsentsOutputDTO.class))),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<WrapperGetConsentsOutputDTO> getDataConsent(
          @RequestParam String legitimate_code,
  @RequestParam String treatment_code,
  @RequestParam String purpose_code,
  @RequestParam String status_code,
  @RequestParam String bank_id,
  @RequestParam String offset,
  @RequestParam String limit, @PathVariable String partyId) {
    
    return dataConsentManagementUseCase
        .getConsent(
            mapper.WrapperGetConsentsRequestDtoToWrapperGetConsentsRequest(
                new WrapperGetConsentsRequestDTO(legitimate_code,treatment_code,purpose_code,status_code,bank_id,offset,limit)),
            partyId)
        .map(mapper::WrapperGetConsentsOutputToWrapperGetConsentsOutputDTO);
  }

  @PatchMapping("/{partyId}/{consentId}")
  @Operation(
          summary = "Actualiza un acuerdo de consentimiento.",
          description = "Actualiza los detalles de un acuerdo de consentimiento específico para una parte.",
          method = "POST")
  @ApiResponses(
          value = {
                  @ApiResponse(
                          responseCode = "204",
                          description = "No content"),
                  @ApiResponse(
                          responseCode = "400",
                          description = "Solicitud inválida",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class))),
                  @ApiResponse(
                          responseCode = "401",
                          description = "No autorizado",
                          content =
                          @Content(
                                  mediaType = "application/json",
                                  schema = @Schema(implementation = ApiError.class)))
          })
  public Mono<Void> patchDataConsent(
      @RequestBody WrapperPatchConsentRequestBodyDTO criteria,
      @PathVariable String partyId,
      @PathVariable String consentId) {
    return dataConsentManagementUseCase.patchConsent(
        mapper.WrapperPatchConsentRequestBodyDtoToWrapperPatchConsentRequestBody(criteria),
        partyId,
        consentId);
  }
}
