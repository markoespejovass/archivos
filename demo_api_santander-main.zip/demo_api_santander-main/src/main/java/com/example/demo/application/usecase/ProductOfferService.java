package com.example.demo.application.usecase;

import com.example.demo.application.port.out.ProductOfferRepositoryPort;
import com.example.demo.domain.model.ProductOffer;
import com.example.demo.domain.model.ProductOfferCriteria;
import com.example.demo.domain.port.in.ProductOfferUseCase;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class ProductOfferService implements ProductOfferUseCase {

  private final ProductOfferRepositoryPort productOfferRepositoryPort;

  public ProductOfferService(ProductOfferRepositoryPort productOfferRepositoryPort) {
    this.productOfferRepositoryPort = productOfferRepositoryPort;
  }

  @Override
  public Mono<ProductOffer> getProductOffers(ProductOfferCriteria criteria) {

    return productOfferRepositoryPort.findProductOffer(criteria);
  }
}
