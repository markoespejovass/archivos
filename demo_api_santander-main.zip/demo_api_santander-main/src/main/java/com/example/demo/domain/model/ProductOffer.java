package com.example.demo.domain.model;

import java.util.List;

public record ProductOffer(
        String codResponse,
        String txtResponse,
        List<Object> details,
        String codOferta,
        List<Offer> ofertas) {
}
