package com.example.demo.domain.model.chanelService;

import lombok.Data;

@Data
public class Product {

  private Contract contract;

  private ChannelAccessAgreementInformation channelAccessAgreementInformation;
}
