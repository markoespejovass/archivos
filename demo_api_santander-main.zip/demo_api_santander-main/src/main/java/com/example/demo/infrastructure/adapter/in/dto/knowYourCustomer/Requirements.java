package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Requirements {

  private String requirementId;
  private String rule;
  private String purposeDescription;
  private Party party;
  private RequiredDocuments requiredDocuments;
}
