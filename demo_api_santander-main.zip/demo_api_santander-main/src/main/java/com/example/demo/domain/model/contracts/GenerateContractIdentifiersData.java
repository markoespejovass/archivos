package com.example.demo.domain.model.contracts;

import lombok.Data;

@Data
public class GenerateContractIdentifiersData {

  private Product product;
  private Center center;
  private Boolean hasOnlyNationalIdentification;
  private ContractIdentification contractIdentification;
}
