package com.example.demo.application.usecase;

import com.example.demo.application.port.in.DocumentManagementUseCase;
import com.example.demo.application.port.out.DocumentManagementRepositoryPort;
import com.example.demo.domain.model.documentManagement.*;
import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperGetDocumentsRequest;
import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperGetDocumentsResponse;
import com.example.demo.domain.model.documentManagement.postSearchDocuments.WrapperPostSearchDocumentsRequest;
import com.example.demo.domain.model.documentManagement.postSearchDocuments.WrapperPostSearchDocumentsResponse;
import com.example.demo.domain.model.documentManagement.postUpdateDocument.WrapperPostUpdateDocumentVersionRequest;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class DocumentManagementUseCaseImpl implements DocumentManagementUseCase {

  private final DocumentManagementRepositoryPort documentManagementRepositoryPort;

  @Override
  public Mono<WrapperGetDocumentsResponse> postDownloadDocument(
      WrapperGetDocumentsRequest criteria) {
    return documentManagementRepositoryPort.downloadDocument(criteria);
  }

  @Override
  public Mono<WrapperPostSearchDocumentsResponse> postSearchDocuments(
      WrapperPostSearchDocumentsRequest criteria) {
    return documentManagementRepositoryPort.searchDocuments(criteria);
  }

  @Override
  public Mono<WrapperPostDocumentsResponse> postUpdateDocument(
      WrapperPostUpdateDocumentVersionRequest criteria) {
    return documentManagementRepositoryPort.updateDocument(criteria);
  }

  @Override
  public Mono<WrapperPostDocumentsResponse> postUploadDocument(
      WrapperPostDocumentsRequest criteria) {
    return documentManagementRepositoryPort.uploadDocument(criteria);
  }
}
