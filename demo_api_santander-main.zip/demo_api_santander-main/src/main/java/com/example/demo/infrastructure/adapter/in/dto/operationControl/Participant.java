package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import lombok.Data;

@Data
public class Participant {

  private String participationTypeCode;
  private String signatureTypeCode;
}
