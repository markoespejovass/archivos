package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import lombok.Data;

@Data
public class WrapperContractListItem {

  private String contractId;

  private Participant participant;

  private Product product;

  private Boolean isOperable;
}
