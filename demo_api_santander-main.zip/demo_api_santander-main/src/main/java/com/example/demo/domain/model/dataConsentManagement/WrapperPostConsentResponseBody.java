package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class WrapperPostConsentResponseBody {

  String consentId;
}
