package com.example.demo.domain.model.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class Mailing {

    @XmlElement(name = "MailingId")
    private Integer mailingId;

    @XmlElement(name = "ReportId")
    private Integer reportId;

    @XmlElement(name = "MailingName")
    private String mailingName;

    @XmlElement(name = "SentDateTime")
    private String sentDateTime;

    @XmlElement(name = "NumSent")
    private Integer numSent;

    @XmlElement(name = "NumSeeds")
    private Integer numSeeds;

    @XmlElement(name = "NumSuppressed")
    private Integer numSuppressed;

    @XmlElement(name = "NumBounceHard")
    private Integer numBounceHard;

    @XmlElement(name = "NumBounceSoft")
    private Integer numBounceSoft;

    @XmlElement(name = "NumUniqueOpen")
    private Integer numUniqueOpen;

    @XmlElement(name = "NumGrossOpen")
    private Integer numGrossOpen;

    @XmlElement(name = "NumUniqueClick")
    private Integer numUniqueClick;

    @XmlElement(name = "NumGrossClick")
    private Integer numGrossClick;

    @XmlElement(name = "NumUniqueAttach")
    private Integer numUniqueAttach;

    @XmlElement(name = "NumGrossAttach")
    private Integer numGrossAttach;

    @XmlElement(name = "NumUniqueClickstreams")
    private Integer numUniqueClickstreams;

    @XmlElement(name = "NumGrossClickstreams")
    private Integer numGrossClickstreams;

    @XmlElement(name = "NumUniqueMedia")
    private Integer numUniqueMedia;

    @XmlElement(name = "NumGrossMedia")
    private Integer numGrossMedia;

    @XmlElement(name = "NumGrossAbuse")
    private Integer numGrossAbuse;

    @XmlElement(name = "NumGrossChangeAddress")
    private Integer numGrossChangeAddress;

    @XmlElement(name = "NumGrossMailBlock")
    private Integer numGrossMailBlock;

    @XmlElement(name = "NumGrossMailRestriction")
    private Integer numGrossMailRestriction;

    @XmlElement(name = "NumGrossOther")
    private Integer numGrossOther;

    @XmlElement(name = "NumConversions")
    private Integer numConversions;

    @XmlElement(name = "NumConversionAmount")
    private Integer numConversionAmount;

    @XmlElement(name = "NumBounceHardFwd")
    private Integer numBounceHardFwd;

    @XmlElement(name = "NumBounceSoftFwd")
    private Integer numBounceSoftFwd;

    @XmlElement(name = "NumConversionAmountFwd")
    private Integer numConversionAmountFwd;

    @XmlElement(name = "NumAttachOpenFwd")
    private Integer numAttachOpenFwd;

    @XmlElement(name = "NumClickFwd")
    private Integer numClickFwd;

    @XmlElement(name = "NumUniqueForwardFwd")
    private Integer numUniqueForwardFwd;

    @XmlElement(name = "NumGrossForwardFwd")
    private Integer numGrossForwardFwd;

    @XmlElement(name = "NumUniqueConversionsFwd")
    private Integer numUniqueConversionsFwd;

    @XmlElement(name = "NumGrossConversionsFwd")
    private Integer numGrossConversionsFwd;

    @XmlElement(name = "NumUniqueClickstreamFwd")
    private Integer numUniqueClickstreamFwd;

    @XmlElement(name = "NumGrossClickstreamFwd")
    private Integer numGrossClickstreamFwd;

    @XmlElement(name = "NumUniqueClickFwd")
    private Integer numUniqueClickFwd;

    @XmlElement(name = "NumGrossClickFwd")
    private Integer numGrossClickFwd;

    @XmlElement(name = "NumUniqueAttachOpenFwd")
    private Integer numUniqueAttachOpenFwd;

    @XmlElement(name = "NumGrossAttachOpenFwd")
    private Integer numGrossAttachOpenFwd;

    @XmlElement(name = "NumUniqueMediaFwd")
    private Integer numUniqueMediaFwd;

    @XmlElement(name = "NumGrossMediaFwd")
    private Integer numGrossMediaFwd;

    @XmlElement(name = "NumUniqueOpenFwd")
    private Integer numUniqueOpenFwd;

    @XmlElement(name = "NumGrossOpenFwd")
    private Integer numGrossOpenFwd;

    @XmlElement(name = "NumAbuseFwd")
    private Integer numAbuseFwd;

    @XmlElement(name = "NumChangeAddressFwd")
    private Integer numChangeAddressFwd;

    @XmlElement(name = "NumMailRestrictionFwd")
    private Integer numMailRestrictionFwd;

    @XmlElement(name = "NumMailBlockFwd")
    private Integer numMailBlockFwd;

    @XmlElement(name = "NumOtherFwd")
    private Integer numOtherFwd;

    @XmlElement(name = "NumSuppressedFwd")
    private Integer numSuppressedFwd;

    @XmlElement(name = "NumUnsubscribes")
    private Integer numUnsubscribes;
}
