package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import java.util.List;
import lombok.Data;

@Data
public class WrapperGetOperabilityStatusResponseDTO {

  private List<WrapperContractListItem> contracts;

  private List<WrapperCardListItem> cards;

  private Links _links;
}
