package com.example.demo.application.usecase;

import com.example.demo.application.port.in.ContractsUseCase;
import com.example.demo.application.port.out.ContractsRepositoryPort;
import com.example.demo.domain.model.contracts.GenerateContractIdentifiersData;
import com.example.demo.domain.model.contracts.GenerateContractIdentifiersResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class ContractUseCaseImpl implements ContractsUseCase {

  private final ContractsRepositoryPort contractsRepositoryPort;

  @Override
  public Mono<GenerateContractIdentifiersResponse> postContractId(
      GenerateContractIdentifiersData criteria) {
    return contractsRepositoryPort.createContractId(criteria);
  }
}
