package com.example.demo.domain.model.dataConsentManagement;

import java.util.List;
import lombok.Data;

@Data
public class WrapperGetConsentsOutput {
  private List<Consents> consents;

  private Links _links;
}
