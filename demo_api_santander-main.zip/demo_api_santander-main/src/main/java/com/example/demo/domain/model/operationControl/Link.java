package com.example.demo.domain.model.operationControl;

import lombok.Data;

@Data
public class Link {

  private String href;
}
