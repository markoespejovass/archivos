package com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class RESULT {

    @XmlElement(name = "SUCCESS")
    private Boolean sUCCESS;

    @XmlElement(name = "MailingID")
    private Integer mailingID;
}
