package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.dataConsentManagement.*;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailResponse;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserResponse;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportRequest;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportResponse;
import com.example.demo.domain.model.otp.saveMailing.SaveMailRequest;
import com.example.demo.domain.model.otp.saveMailing.SaveMailResponse;
import com.example.demo.domain.model.otp.sendMailing.RequestOTP;
import com.example.demo.domain.model.otp.sendMailing.ResponseOTP;
import com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement.*;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing.GetTrackingForMailRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing.GetTrackingForMailResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser.GetTrackingForUserRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser.GetTrackingForUserResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate.GetReportRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate.GetReportResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing.SaveMailRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing.SaveMailResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing.RequestOTPDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing.ResponseOTPDTO;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OTPServiceMapper {

    RequestOTP RequestOTPDtoToRequestOTP(
          RequestOTPDTO requestOTP);

    ResponseOTPDTO ResponseOTPToResponseOTPDTO(
          ResponseOTP responseOTP);


    SaveMailRequest SaveMailRequestDtoToSaveMailRequest(
            SaveMailRequestDTO saveMailRequestDTO);

    SaveMailResponseDTO SaveMailResponseToSaveMailResponseDTO(
          SaveMailResponse saveMailResponse);


    GetReportRequest GetReportRequestDtoToGetReportRequest(
            GetReportRequestDTO getReportRequestDTO);

    GetReportResponseDTO GetReportResponseToGetReportResponseDTO(
            GetReportResponse getReportResponse);


    GetTrackingForUserRequest GetTrackingForUserRequestDtoToGetTrackingForUserRequest(
            GetTrackingForUserRequestDTO getTrackingForUserRequestDTO);

    GetTrackingForUserResponseDTO GetTrackingForUserResponseToGetTrackingForUserResponseDTO(
            GetTrackingForUserResponse saveMailResponse);


    GetTrackingForMailRequest GetTrackingForMailRequestDtoToGetTrackingForMailRequest(
            GetTrackingForMailRequestDTO getReportRequestDTO);

    GetTrackingForMailResponseDTO GetTrackingForMailResponseToGetTrackingForMailResponseDTO(
            GetTrackingForMailResponse getReportResponse);
}
