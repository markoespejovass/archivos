package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import lombok.Data;

@Data
public class Link {

  private String href;
}
