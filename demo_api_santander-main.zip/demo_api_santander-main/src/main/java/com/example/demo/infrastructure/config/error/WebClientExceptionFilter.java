package com.example.demo.infrastructure.config.error;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import reactor.core.publisher.Mono;

@Component
public class WebClientExceptionFilter {

  private final WebClientErrorMapper errorMapper;

  public WebClientExceptionFilter(WebClientErrorMapper errorMapper) {
    this.errorMapper = errorMapper;
  }

  public ExchangeFilterFunction errorHandlingFilter() {
    return ExchangeFilterFunction.ofResponseProcessor(
        response -> {
          if (response.statusCode().isError()) {
            return response
                .bodyToMono(String.class)
                .flatMap(body -> Mono.error(errorMapper.map((HttpStatus) response.statusCode())));
          }

          return Mono.just(response);
        });
  }
}
