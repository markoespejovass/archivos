package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class Mailing {

    @XmlElement(name = "MailingId")
    private Integer mailingId;

    @XmlElement(name = "ReportId")
    private Integer reportId;

    @XmlElement(name = "ScheduledTS")
    private String scheduledTS;

    @XmlElement(name = "MailingName")
    private String mailingName;

    @XmlElement(name = "ListName")
    private String listName;

    @XmlElement(name = "ListId")
    private Integer listId;

    @XmlElement(name = "UserName")
    private String userName;

    @XmlElement(name = "SentTS")
    private String sentTS;

    @XmlElement(name = "NumSent")
    private Integer numSent;

    @XmlElement(name = "Subject")
    private String subject;

    @XmlElement(name = "Visibility")
    private String visibility;
}
