package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Location {
  private String code;
  private String name;
}
