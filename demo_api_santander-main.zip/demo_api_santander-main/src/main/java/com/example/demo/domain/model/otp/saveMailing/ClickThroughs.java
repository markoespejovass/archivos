package com.example.demo.domain.model.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

import java.util.List;

@Data
public class ClickThroughs {

    @XmlElement(name = "ClickThrough")
    private List<ClickThrough> clickThrough;
}
