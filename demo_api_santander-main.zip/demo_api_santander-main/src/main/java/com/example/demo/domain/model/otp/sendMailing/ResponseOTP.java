package com.example.demo.domain.model.otp.sendMailing;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import jakarta.xml.bind.annotation.*;
import lombok.Builder;
import lombok.Data;

@JacksonXmlRootElement(localName = "XTMAILING_RESPONSE")
@Data
@Builder
public class ResponseOTP {

    @JacksonXmlProperty(localName = "CAMPAIGN_ID")
    private Integer cAMPAIGNID;

    @JacksonXmlProperty(localName = "TRANSACTION_ID")
    private String tRANSACTIONID;

    @JacksonXmlProperty(localName = "RECIPIENTS_RECEIVED")
    private Integer rECIPIENTSRECEIVED;

    @JacksonXmlProperty(localName = "EMAILS_SENT")
    private Integer eMAILSSENT;

    @JacksonXmlProperty(localName = "NUMBER_ERRORS")
    private Integer nUMBERERRORS;

    @JacksonXmlProperty(localName = "STATUS")
    private Integer sTATUS;

    @JacksonXmlProperty(localName = "ERROR_CODE")
    private Integer eRRORCODE;

    @JacksonXmlProperty(localName = "ERROR_STRING")
    private String eRRORSTRING;

    @JacksonXmlProperty(localName = "RECIPIENT_DETAIL")
    private RECIPIENTDETAIL rECIPIENTDETAIL;
}
