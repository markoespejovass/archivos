package com.example.demo.domain.model.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class ClickThrough {

    @XmlElement(name = "ClickThroughName")
    private String clickThroughName;

    @XmlElement(name = "ClickThroughType")
    private Integer clickThroughType;

    @XmlElement(name = "ClickThroughURL")
    private String clickThroughURL;
}
