package com.example.demo.domain.model.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class BodyRequest {

    @XmlElement(name = "GetReportIdByDate")
    private GetReportIdByDate getReportIdByDate;
}
