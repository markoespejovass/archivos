package com.example.demo.application.usecase;

import com.example.demo.application.port.in.DataConsentManagementUseCase;
import com.example.demo.application.port.out.DataConsentManagementRepositoryPort;
import com.example.demo.domain.model.dataConsentManagement.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class DataConsentManagementUseCaseImpl implements DataConsentManagementUseCase {

  private final DataConsentManagementRepositoryPort dataConsentManagementRepositoryPort;

  @Override
  public Mono<WrapperGetConsentsOutput> getConsent(
      WrapperGetConsentsRequest criteria, String partyId) {
    return dataConsentManagementRepositoryPort.getConsent(criteria, partyId);
  }

  @Override
  public Mono<WrapperPostConsentResponseBody> postConsent(
      WrapperPostConsentRequestBody criteria, String partyId) {
    return dataConsentManagementRepositoryPort.createConsent(criteria, partyId);
  }

  @Override
  public Mono<Void> patchConsent(
      WrapperPatchConsentRequestBody criteria, String partyId, String consentId) {
    return dataConsentManagementRepositoryPort.updateConsent(criteria, partyId, consentId);
  }
}
