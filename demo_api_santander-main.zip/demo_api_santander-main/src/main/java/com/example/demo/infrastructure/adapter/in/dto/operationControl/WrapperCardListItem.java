package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import lombok.Data;

@Data
public class WrapperCardListItem {

  private String cardId;
  private Cardholder cardholder;
  private Boolean isOperable;
}
