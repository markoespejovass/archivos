package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class AnalysisResult {
  private Boolean isVerified;
}
