package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class GetSentMailingsForUser {

    @XmlElement(name = "PRIVATE")
    private String pRIVATE;

    @XmlElement(name = "SENT")
    private String sENT;

    @XmlElement(name = "DATE_START")
    private String dATESTART;

    @XmlElement(name = "DATE_END")
    private String dATEEND;

    @XmlElement(name = "OPTIONALUSER")
    private String oPTIONALUSER;
}
