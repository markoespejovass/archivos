package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class WrapperPostConsentRequestBody {
  private StatusInfo statusInfo;

  private ValidityPeriod validityPeriod;

  private Bank bank;

  private String legitimateCode;

  private String treatmentCode;

  private String purposeCode;
}
