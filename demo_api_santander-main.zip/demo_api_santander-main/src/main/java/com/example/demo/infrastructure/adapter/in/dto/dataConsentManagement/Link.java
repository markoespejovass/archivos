package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import lombok.Data;

@Data
public class Link {

  private String href;
}
