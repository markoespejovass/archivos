package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class PreferenceChannel {
  private String code;
  private String description;
}
