package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class KnowYourCustomerNonResidents {

  private String relationshipReason;
  private Boolean isInitialDeposit;
  private String initialTransactionTypeDescription;
  private Amount amount;
  private OriginBank originBank;
  private Location location;
}
