package com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "XTMAILING_RESPONSE")
@Data
public class ResponseOTPDTO {

    @XmlElement(name = "CAMPAIGN_ID")
    private Integer cAMPAIGNID;

    @XmlElement(name = "TRANSACTION_ID")
    private String tRANSACTIONID;

    @XmlElement(name = "RECIPIENTS_RECEIVED")
    private Integer rECIPIENTSRECEIVED;

    @XmlElement(name = "EMAILS_SENT")
    private Integer eMAILSSENT;

    @XmlElement(name = "NUMBER_ERRORS")
    private Integer nUMBERERRORS;

    @XmlElement(name = "STATUS")
    private Integer sTATUS;

    @XmlElement(name = "ERROR_CODE")
    private Integer eRRORCODE;

    @XmlElement(name = "ERROR_STRING")
    private String eRRORSTRING;

    @XmlElement(name = "RECIPIENT_DETAIL")
    private RECIPIENTDETAIL rECIPIENTDETAIL;
}
