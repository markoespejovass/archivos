package com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class SaveMailing {

    @XmlElement(name = "Header")
    private HeaderOTP header;

    @XmlElement(name = "MessageBodies")
    private MessageBodies messageBodies;

    @XmlElement(name = "ClickThroughs")
    private ClickThroughs clickThroughs;

    @XmlElement(name = "ForwardToFriend")
    private ForwardToFriend forwardToFriend;
}
