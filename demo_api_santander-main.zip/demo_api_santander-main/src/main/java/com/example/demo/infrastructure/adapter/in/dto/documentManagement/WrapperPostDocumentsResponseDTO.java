package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class WrapperPostDocumentsResponseDTO {

  private WrapperMyDocumentResponseDTO document;

  private LinkReference access_information;
}
