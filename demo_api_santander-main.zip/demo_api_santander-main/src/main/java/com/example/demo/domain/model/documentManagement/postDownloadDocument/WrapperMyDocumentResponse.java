package com.example.demo.domain.model.documentManagement.postDownloadDocument;

import lombok.Data;

@Data
public class WrapperMyDocumentResponse {

  private String documentId;

  private String versionCode;
}
