package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import java.util.List;
import lombok.Data;

@Data
public class WrapperPostSearchDocumentsResponseDTO {

  private List<Document> documents;

  private Links links;

  private ResultsCount resultsCount;
}
