package com.example.demo.domain.model.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.*;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetTrackingForUserRequest {

    @XmlElement(name = "Body")
    private BodyRequest body;

}
