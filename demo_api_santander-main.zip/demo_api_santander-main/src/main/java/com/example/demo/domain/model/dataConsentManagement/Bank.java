package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class Bank {

  private String bankId;
}
