package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class DocumentProperty {

  private String key;

  private String value;
}
