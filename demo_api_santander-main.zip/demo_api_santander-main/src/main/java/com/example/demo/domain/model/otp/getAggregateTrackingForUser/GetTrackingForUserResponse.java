package com.example.demo.domain.model.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Envelope")
public class GetTrackingForUserResponse {

    @XmlElement(name = "Body")
    private BodyResponse body;
}
