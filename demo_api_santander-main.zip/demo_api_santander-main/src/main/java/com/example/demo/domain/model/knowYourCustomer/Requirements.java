package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Requirements {

  private String requirementId;
  private String rule;
  private String purposeDescription;
  private Party party;
  private RequiredDocuments requiredDocuments;
}
