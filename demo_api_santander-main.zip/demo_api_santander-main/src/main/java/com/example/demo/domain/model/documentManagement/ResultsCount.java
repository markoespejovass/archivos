package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class ResultsCount {

  private String resultCount;
  private String limitCount;
}
