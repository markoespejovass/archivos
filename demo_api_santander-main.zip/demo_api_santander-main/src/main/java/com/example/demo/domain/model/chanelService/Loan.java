package com.example.demo.domain.model.chanelService;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class Loan extends Product {

  private String loanId;
}
