package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class SearchProperties {

  private String keyOperator;

  private String keyId;

  private String keyValue;

  private String keyType;

  private String keyValueFrom;

  private String keyValueTo;
}
