package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ServicesListRequestDTO {
  private String serviceId;
  private String contractId;
  private String expand;
}
