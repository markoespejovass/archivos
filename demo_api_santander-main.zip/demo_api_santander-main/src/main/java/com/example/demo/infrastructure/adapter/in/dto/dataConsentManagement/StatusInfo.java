package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import lombok.Data;

@Data
public class StatusInfo {
  private String statusCode;
  private String statusDescription;
}
