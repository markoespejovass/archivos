package com.example.demo.application.usecase;

import com.example.demo.application.port.in.ChannelServiceUseCase;
import com.example.demo.application.port.out.ChannelServiceRepositoryPort;
import com.example.demo.domain.model.chanelService.ServicesListRequest;
import com.example.demo.domain.model.chanelService.ServicesListResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class ChannelServiceUseCaseImpl implements ChannelServiceUseCase {

  private final ChannelServiceRepositoryPort channelServiceRepositoryPort;

  @Override
  public Mono<ServicesListResponse> getServices(ServicesListRequest criteria) {
    return channelServiceRepositoryPort.getListServices(criteria);
  }
}
