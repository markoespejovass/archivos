package com.example.demo.application.port.in;

import com.example.demo.domain.model.chanelService.ServicesListRequest;
import com.example.demo.domain.model.chanelService.ServicesListResponse;
import reactor.core.publisher.Mono;

public interface ChannelServiceUseCase {

  Mono<ServicesListResponse> getServices(ServicesListRequest criteria);
}
