package com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

import java.io.Serializable;

@XmlRootElement(name = "XTMAILING")
@Data
public class RequestOTPDTO implements Serializable {


    @XmlElement(name = "CAMPAIGN_ID")
    private Integer cAMPAIGNID;

    @XmlElement(name = "TRANSACTION_ID")
    private String tRANSACTIONID;

    @XmlElement(name = "SHOW_ALL_SEND_DETAIL")
    private Boolean sHOWALLSENDDETAIL;

    @XmlElement(name = "SEND_AS_BATCH")
    private Boolean sENDASBATCH;

    @XmlElement(name = "NO_RETRY_ON_FAILURE")
    private Boolean nORETRYONFAILURE;

    @XmlElement(name = "SAVE_COLUMNS")
    private SAVECOLUMNS sAVECOLUMNS;

    @XmlElement(name = "RECIPIENT")
    private Recipient rECIPIENT;
}
