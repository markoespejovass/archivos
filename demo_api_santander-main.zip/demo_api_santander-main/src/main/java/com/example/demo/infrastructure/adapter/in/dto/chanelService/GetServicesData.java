package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import lombok.Data;

@Data
public class GetServicesData {

  private Service service;
  private AllContracts allContracts;
}
