package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Risk {

  private String lastReviewEventReference;
  private String dueDiligenceTypeCode;
  private String dueDiligenceTypeDescription;
  private Score score;
}
