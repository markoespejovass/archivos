package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class StatusInfo {
  private String statusCode;
  private String statusDescription;
}
