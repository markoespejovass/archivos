package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class OriginBank {
  private String bankId;
  private String bankName;
}
