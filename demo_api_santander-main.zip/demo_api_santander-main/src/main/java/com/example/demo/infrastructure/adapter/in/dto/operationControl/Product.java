package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import lombok.Data;

@Data
public class Product {

  private String productCode;
}
