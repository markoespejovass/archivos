package com.example.demo.domain.model.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetReportRequest {

    @XmlElement(name = "Body")
    private BodyRequest body;
}
