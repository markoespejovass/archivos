package com.example.demo.domain.model.knowYourCustomer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Amount {
  private Double amount;
  private String currency;
}
