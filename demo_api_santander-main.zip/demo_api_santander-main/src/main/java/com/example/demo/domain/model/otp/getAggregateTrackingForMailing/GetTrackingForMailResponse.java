package com.example.demo.domain.model.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.*;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetTrackingForMailResponse {

    @XmlElement(name = "Body")
    private BodyResponse body;
}
