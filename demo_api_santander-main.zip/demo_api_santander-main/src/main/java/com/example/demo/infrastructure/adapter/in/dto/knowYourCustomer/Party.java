package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Party {

  private String documentNumber;
  private String documentTypeCode;
  private String documentTypeDescription;
  private Country country;
}
