package com.example.demo.infrastructure.exception;

import com.example.demo.domain.exception.ErrorCode;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApiError {
  private String code;
  private String name;
  private String description;
  private String level;

  public static ApiError from(ErrorCode errorCode) {

    return new ApiError(
        errorCode.getCode(),
        errorCode.getName(),
        errorCode.getDescription(),
        errorCode.getLevel().name());
  }
}
