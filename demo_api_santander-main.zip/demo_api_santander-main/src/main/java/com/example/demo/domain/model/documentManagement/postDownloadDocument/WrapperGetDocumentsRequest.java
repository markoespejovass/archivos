package com.example.demo.domain.model.documentManagement.postDownloadDocument;

import lombok.Data;

@Data
public class WrapperGetDocumentsRequest {

  private WrapperMyDocumentResponse document;
}
