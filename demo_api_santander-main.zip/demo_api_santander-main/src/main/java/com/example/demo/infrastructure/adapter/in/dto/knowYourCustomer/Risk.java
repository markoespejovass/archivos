package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Risk {

  private String lastReviewEventReference;
  private String dueDiligenceTypeCode;
  private String dueDiligenceTypeDescription;
  private Score score;
}
