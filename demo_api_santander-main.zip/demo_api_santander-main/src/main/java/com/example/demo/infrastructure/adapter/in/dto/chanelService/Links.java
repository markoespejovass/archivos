package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import lombok.Data;

@Data
public class Links {

  private Link _first;
  private Link _prev;
  private Link _next;
}
