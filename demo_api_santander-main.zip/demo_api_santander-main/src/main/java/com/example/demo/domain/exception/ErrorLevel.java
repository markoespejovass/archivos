package com.example.demo.domain.exception;

public enum ErrorLevel {
  VALIDATION,
  BUSINESS,
  TECHNICAL
}
