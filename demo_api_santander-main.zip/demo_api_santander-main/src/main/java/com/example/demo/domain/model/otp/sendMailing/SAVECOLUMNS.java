package com.example.demo.domain.model.otp.sendMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

import java.util.List;

@Data
public class SAVECOLUMNS {

    @XmlElement(name = "COLUMN_NAME")
    private List<String> cOLUMNNAME;
}
