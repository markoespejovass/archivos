package com.example.demo.domain.model.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class TopDomain {

    @XmlElement(name = "MailingId")
    private Integer mailingId;

    @XmlElement(name = "ReportId")
    private Integer reportId;

    @XmlElement(name = "Domain")
    private String domain;

    @XmlElement(name = "Sent")
    private Integer sent;

    @XmlElement(name = "Bounce")
    private Integer bounce;

    @XmlElement(name = "Open")
    private Integer open;

    @XmlElement(name = "Click")
    private Integer click;

    @XmlElement(name = "Unsubscribe")
    private Integer unsubscribe;

    @XmlElement(name = "Conversion")
    private Integer conversion;

    @XmlElement(name = "Conversion_amount")
    private Integer conversionAmount;

    @XmlElement(name = "Reply_abuse")
    private Integer replyAbuse;

    @XmlElement(name = "Reply_mail_block")
    private Integer replyMailBlock;

    @XmlElement(name = "Reply_mail_restriction")
    private Integer replyMailRestriction;
}
