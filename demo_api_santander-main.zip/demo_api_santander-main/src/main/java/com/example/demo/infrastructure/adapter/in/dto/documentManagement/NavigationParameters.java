package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class NavigationParameters {

  private String _limit;

  private String _offset;
}
