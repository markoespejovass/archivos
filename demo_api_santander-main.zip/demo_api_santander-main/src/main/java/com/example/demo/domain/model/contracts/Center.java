package com.example.demo.domain.model.contracts;

import lombok.Data;

@Data
public class Center {

  private String centerId;
}
