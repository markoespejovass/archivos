package com.example.demo.domain.model.documentManagement.postSearchDocuments;

import com.example.demo.domain.model.documentManagement.Document;
import com.example.demo.domain.model.documentManagement.Links;
import com.example.demo.domain.model.documentManagement.ResultsCount;
import java.util.List;
import lombok.Data;

@Data
public class WrapperPostSearchDocumentsResponse {

  private List<Document> documents;

  private Links links;

  private ResultsCount resultsCount;
}
