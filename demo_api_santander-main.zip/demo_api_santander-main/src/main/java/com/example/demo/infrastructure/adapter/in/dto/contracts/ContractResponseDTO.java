package com.example.demo.infrastructure.adapter.in.dto.contracts;

import lombok.Data;

@Data
public class ContractResponseDTO {

  private String nationalIdentification;
  private String internalIdentification;
}
