package com.example.demo.domain.model.operationControl;

import lombok.Data;

@Data
public class WrapperContractListItem {

  private String contractId;

  private Participant participant;

  private Product product;

  private Boolean isOperable;
}
