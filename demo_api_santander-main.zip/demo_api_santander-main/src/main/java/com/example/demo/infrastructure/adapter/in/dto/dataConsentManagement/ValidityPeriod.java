package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import lombok.Data;

@Data
public class ValidityPeriod {
  private String startDate;
  private String endDate;
}
