package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Document {

  private String documentTypeCode;
  private String documentTypeDescription;
}
