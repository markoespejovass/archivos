package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Reason {

  private String code;
  private String value;
  private String typeDescription;
}
