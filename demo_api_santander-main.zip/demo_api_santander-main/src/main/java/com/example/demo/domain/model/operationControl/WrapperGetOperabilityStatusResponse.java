package com.example.demo.domain.model.operationControl;

import java.util.List;
import lombok.Data;

@Data
public class WrapperGetOperabilityStatusResponse {

  private List<WrapperContractListItem> contracts;

  private List<WrapperCardListItem> cards;

  private Links _links;
}
