package com.example.demo.domain.model.contracts;

import lombok.Data;

@Data
public class Subproduct {
  private String subproductId;
}
