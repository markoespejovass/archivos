package com.example.demo.domain.model.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.*;

@XmlRootElement(name = "Envelope")
public class GetTrackingForMailRequest {

    @XmlElement(name = "Body")
    private BodyRequest body;

}
