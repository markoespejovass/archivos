package com.example.demo.domain.model.knowYourCustomer;

import java.util.List;
import lombok.Data;

@Data
public class WrapperPostKycResolutionRequest {

  private Party party;

  private Customer customer;

  private List<Product> products;

  private Employee employee;

  private Bank bank;

  private PreferenceChannel preferenceChannel;

  private KnowYourCustomerQuestionnaires knowYourCustomerQuestionnaires;

  private KnowYourCustomerNonResidents knowYourCustomerNonResidents;

  private List<Object> countriesOfRevenue;

  private Boolean isInRestrictedCountries;

  private Boolean hasPoliticallyExposedPerson;

  private String declarationComments;

  private Boolean screeningConfirmedFlag;

  private String screeningNegativeInformationReference;

  private Boolean isPendingNationality;

  private Boolean thirdPartyIndicator;

  private PurposeOfRelationshipAndSourceOfFunds purposeOfRelationshipAndSourceOfFunds;

  private List<Object> customerLinks;

  private String localReference;

  private String originSystem;

  private AuditChannel audit;

  private AntiMoneyLaundering antiMoneyLaundering;

  private AnalysisResult analysisResult;

  private List<Object> unfavourableBackgroundReferences;

  private Boolean publicOfficeIndicator;
}
