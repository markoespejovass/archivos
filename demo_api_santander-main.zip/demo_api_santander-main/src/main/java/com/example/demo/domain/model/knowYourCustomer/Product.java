package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Product {

  private String productCode;
  private String productDescription;
  private Family family;
}
