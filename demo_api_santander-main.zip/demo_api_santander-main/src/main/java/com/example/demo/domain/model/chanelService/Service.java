package com.example.demo.domain.model.chanelService;

import lombok.Data;

@Data
public class Service {

  private String serviceId;
  private String name;
  private String type;
  private Boolean isRelatedToContract;
}
