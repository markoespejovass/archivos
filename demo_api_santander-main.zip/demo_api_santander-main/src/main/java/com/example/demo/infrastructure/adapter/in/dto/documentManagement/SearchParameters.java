package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import java.util.List;
import lombok.Data;

@Data
public class SearchParameters {

  private String discriminator;

  private List<SearchProperties> searchProperties;

  private String sortOrder;

  private String sortBy;
}
