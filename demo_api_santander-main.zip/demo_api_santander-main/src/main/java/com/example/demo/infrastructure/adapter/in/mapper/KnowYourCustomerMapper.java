package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.knowYourCustomer.*;
import com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.WrapperPostKycResolutionRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.WrapperPostKycResolutionResponseDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface KnowYourCustomerMapper {

  Amount amountDtoToAmountRequest(
      com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.Amount amountDto);

  OriginBank originBankDtoToOriginBankRequest(
      com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.OriginBank originBankDto);

  Location locationDtoToLocationRequest(
      com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.Location locationDto);

  PurposeOfRelationshipAndSourceOfFunds
      purposeOfRelationshipAndSourceOfFundsDtoToPurposeOfRelationshipAndSourceOfFundsRequest(
          com.example
                  .demo
                  .infrastructure
                  .adapter
                  .in
                  .dto
                  .knowYourCustomer
                  .PurposeOfRelationshipAndSourceOfFunds
              purposeOfRelationshipAndSourceOfFundsDto);

  AntiMoneyLaundering antiMoneyLaunderingDtoToAntiMoneyLaunderingRequest(
      com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.AntiMoneyLaundering
          antiMoneyLaunderingDto);

  AnalysisResult analysisResultDtoToAnalysisResultRequest(
      com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.AnalysisResult
          AnalysisResultDto);

  WrapperPostKycResolutionRequest
      WrapperPostKycResolutionRequestDtoToWrapperPostKycResolutionRequest(
          WrapperPostKycResolutionRequestDTO contractRequestDTO);

  WrapperPostKycResolutionResponseDTO
      WrapperPostKycResolutionResponseToWrapperPostKycResolutionResponseDTO(
          WrapperPostKycResolutionResponse generateContractIdentifiersResponse);
}
