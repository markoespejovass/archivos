package com.example.demo.domain.model.documentManagement.postUpdateDocument;

import com.example.demo.domain.model.documentManagement.DocumentProperty;
import com.example.demo.domain.model.documentManagement.Owner;
import com.example.demo.domain.model.documentManagement.Version;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class WrapperPostUpdateDocumentVersionRequest {

  private Version version;

  private String documentId;

  private String mimeType;

  private String name;

  private String typeCode;

  private String folderReference;

  private String aclReference;

  private List<Owner> owners;

  private List<DocumentProperty> documentProperties;

  private Map<String, Object> customMetadata;
}
