package com.example.demo.application.port.in;

import com.example.demo.domain.model.operationControl.WrapperGetOperabilityStatusRequest;
import com.example.demo.domain.model.operationControl.WrapperGetOperabilityStatusResponse;
import reactor.core.publisher.Mono;

public interface OperationControlsUseCase {

  Mono<WrapperGetOperabilityStatusResponse> getOperationControl(
      WrapperGetOperabilityStatusRequest criteria);
}
