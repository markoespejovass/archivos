package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetTrackingForUserRequestDTO {

    @XmlElement(name = "Body")
    private BodyRequest body;

}
