package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class LinkReference {

  private String href;

  private String expirationDateTime;
}
