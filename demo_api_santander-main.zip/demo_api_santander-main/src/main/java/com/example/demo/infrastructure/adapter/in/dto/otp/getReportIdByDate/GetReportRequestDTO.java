package com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetReportRequestDTO {

    @XmlElement(name = "Body")
    private BodyRequest body;
}
