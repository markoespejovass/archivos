package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

import java.util.List;

@Data
public class TopDomains {

    @XmlElement(name = "TopDomain")
    private List<TopDomain> topDomain;
}
