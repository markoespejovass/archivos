package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class Status {
  private String statusCode;
}
