package com.example.demo.application.port.in;

import com.example.demo.domain.model.knowYourCustomer.WrapperPostKycResolutionRequest;
import com.example.demo.domain.model.knowYourCustomer.WrapperPostKycResolutionResponse;
import reactor.core.publisher.Mono;

public interface KnowYourCustomerUseCase {

  Mono<WrapperPostKycResolutionResponse> postInitKyc(WrapperPostKycResolutionRequest criteria);
}
