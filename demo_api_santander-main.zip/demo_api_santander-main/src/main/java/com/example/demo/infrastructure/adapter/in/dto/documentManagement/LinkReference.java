package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class LinkReference {

  private String href;

  private String expirationDateTime;
}
