package com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class GetReportIdByDate {

    @XmlElement(name = "MAILING_ID")
    private Integer mAILINGID;

    @XmlElement(name = "DATE_START")
    private String dATESTART;

    @XmlElement(name = "DATE_END")
    private String dATEEND;

}
