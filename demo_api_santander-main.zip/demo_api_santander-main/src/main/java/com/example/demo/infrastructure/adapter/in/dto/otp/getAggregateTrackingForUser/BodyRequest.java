package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class BodyRequest {

    @XmlElement(name = "GetSentMailingsForUser")
    private GetSentMailingsForUser getSentMailingsForUser;
}
