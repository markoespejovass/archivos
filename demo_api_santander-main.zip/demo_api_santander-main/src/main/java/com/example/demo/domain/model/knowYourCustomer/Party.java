package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Party {

  private String documentNumber;
  private String documentTypeCode;
  private String documentTypeDescription;
  private Country country;
}
