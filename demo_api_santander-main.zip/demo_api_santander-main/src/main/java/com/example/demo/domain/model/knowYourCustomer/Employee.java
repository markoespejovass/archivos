package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Employee {

  private String number;
  private Person person;
}
