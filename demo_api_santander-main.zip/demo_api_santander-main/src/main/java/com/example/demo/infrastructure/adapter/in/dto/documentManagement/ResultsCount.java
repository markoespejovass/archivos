package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class ResultsCount {

  private String resultCount;
  private String limitCount;
}
