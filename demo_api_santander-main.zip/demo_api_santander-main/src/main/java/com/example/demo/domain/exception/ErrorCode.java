package com.example.demo.domain.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ErrorCode {
  RESOURCE_NOT_FOUND(
      "GEN_404", "Resource not found", "The requested resource was not found", ErrorLevel.BUSINESS),

  REQUEST_TIMEOUT(
      "GEN_408", "Request timeout", "The request took too long to process", ErrorLevel.TECHNICAL),

  UNSUPPORTED_MEDIA_TYPE(
      "GEN_415",
      "Unsupported Media Type",
      "The request have a unsupported media type",
      ErrorLevel.TECHNICAL),

  NOT_IMPLEMENTED(
      "GEN_501",
      "Not implemented",
      "The requested functionality is not implemented",
      ErrorLevel.TECHNICAL),

  BAD_GATEWAY(
      "GEN_502", "Bad gateway", "Invalid response from downstream service", ErrorLevel.TECHNICAL),

  SERVICE_UNAVAILABLE(
      "GEN_503",
      "Service unavailable",
      "The service is temporarily unavailable",
      ErrorLevel.TECHNICAL),

  GATEWAY_TIMEOUT(
      "GEN_504",
      "Gateway timeout",
      "Downstream service did not respond in time",
      ErrorLevel.TECHNICAL),

  UNEXPECTED_ERROR("GEN_500", "Error in server", "Error in server", ErrorLevel.TECHNICAL);

  private final String code;
  private final String name;
  private final String description;
  private final ErrorLevel level;
}
