package com.example.demo.domain.model.operationControl;

import lombok.Data;

@Data
public class Product {

  private String productCode;
}
