package com.example.demo.infrastructure.adapter.in.rest;

import com.example.demo.application.port.in.KnowYourCustomerUseCase;
import com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.WrapperPostKycResolutionRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer.WrapperPostKycResolutionResponseDTO;
import com.example.demo.infrastructure.adapter.in.mapper.KnowYourCustomerMapper;
import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/knowYourCustomer")
@Tag(name = "Know Your Customer", description = "API para la gestión de KYC.")
public class KnowYourCustomerController {

  private final KnowYourCustomerUseCase knowYourCustomerUseCase;
  private final KnowYourCustomerMapper mapper;

  public KnowYourCustomerController(
      KnowYourCustomerUseCase knowYourCustomerUseCase, KnowYourCustomerMapper mapper) {
    this.knowYourCustomerUseCase = knowYourCustomerUseCase;
    this.mapper = mapper;
  }

  @PostMapping
  @Operation(
      summary = "Crea el proceso de KYC.",
      description = "Crea el proceso de KYC",
      method = "POST")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "OK",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = WrapperPostKycResolutionResponseDTO.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Solicitud inválida",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class))),
        @ApiResponse(
            responseCode = "401",
            description = "No autorizado",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class)))
      })
  public Mono<WrapperPostKycResolutionResponseDTO> postInitKyc(
      @RequestBody WrapperPostKycResolutionRequestDTO criteria) {
    return knowYourCustomerUseCase
        .postInitKyc(
            mapper.WrapperPostKycResolutionRequestDtoToWrapperPostKycResolutionRequest(criteria))
        .map(mapper::WrapperPostKycResolutionResponseToWrapperPostKycResolutionResponseDTO);
  }
}
