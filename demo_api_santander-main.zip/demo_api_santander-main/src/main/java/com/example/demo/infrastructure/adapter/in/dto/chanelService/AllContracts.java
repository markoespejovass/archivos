package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import java.util.List;
import lombok.Data;

@Data
public class AllContracts {

  private List<Account> accounts;
  private List<CardContract> cardContracts;
  private List<Loan> loans;
  private List<Deposit> deposits;
}
