package com.example.demo.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record ProductOfferCriteria(
        Integer ramoId,
        Integer tipoRiesgoId,
        Integer productoId,
        double sumaAsegurada,
        String fechaIngreso,
        InsuredHolder asegTitular,
        AuditData auditoria) {

}
