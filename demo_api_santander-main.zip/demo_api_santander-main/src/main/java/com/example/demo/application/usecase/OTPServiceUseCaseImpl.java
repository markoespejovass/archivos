package com.example.demo.application.usecase;

import com.example.demo.application.port.in.OTPServiceUseCase;
import com.example.demo.application.port.out.OTPServiceRepositoryPort;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailResponse;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserResponse;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportRequest;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportResponse;
import com.example.demo.domain.model.otp.saveMailing.SaveMailRequest;
import com.example.demo.domain.model.otp.saveMailing.SaveMailResponse;
import com.example.demo.domain.model.otp.sendMailing.RequestOTP;
import com.example.demo.domain.model.otp.sendMailing.ResponseOTP;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class OTPServiceUseCaseImpl implements OTPServiceUseCase {

    private final OTPServiceRepositoryPort otpServiceRepositoryPort;

    @Override
    public Mono<ResponseOTP> sendMailing(Mono<RequestOTP> criteria) {
        return otpServiceRepositoryPort.sendMailing(criteria);
    }

    @Override
    public Mono<GetReportResponse> getReportIdByDate(Mono<GetReportRequest> criteria) {
        return otpServiceRepositoryPort.getReportIdByDate(criteria);
    }

    @Override
    public Mono<GetTrackingForUserResponse> getAggregateTrackingForUser(Mono<GetTrackingForUserRequest> criteria) {
        return otpServiceRepositoryPort.getAggregateTrackingForUser(criteria);
    }

    @Override
    public Mono<GetTrackingForMailResponse> getAggregateTrackingForMailing(Mono<GetTrackingForMailRequest> criteria) {
        return otpServiceRepositoryPort.getAggregateTrackingForMailing(criteria);
    }

    @Override
    public Mono<SaveMailResponse> saveMailing(Mono<SaveMailRequest> criteria) {
        return otpServiceRepositoryPort.saveMailing(criteria);
    }
}
