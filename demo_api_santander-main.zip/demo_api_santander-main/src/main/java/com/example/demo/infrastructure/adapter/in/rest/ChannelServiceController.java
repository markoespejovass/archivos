package com.example.demo.infrastructure.adapter.in.rest;

import com.example.demo.application.port.in.ChannelServiceUseCase;
import com.example.demo.infrastructure.adapter.in.dto.chanelService.ServicesListRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.chanelService.ServicesListResponseDTO;
import com.example.demo.infrastructure.adapter.in.mapper.ChannelServiceMapper;
import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/channelService")
@Tag(name = "Channel Service", description = "API para la gestión de Channel Service.")
public class ChannelServiceController {

  private final ChannelServiceUseCase channelServiceUseCase;
  private final ChannelServiceMapper mapper;

  @GetMapping
  @Operation(
      summary = "Recupera un lista de servicios.",
      description =
          "Realiza la recuperación de un listado de servicios a partir de su id especifico",
      method = "GET",
      parameters = {
        @Parameter(
            name = "expand",
            description =
                "flag para incluir data de los contractos si no se pone ningun valor se considera empty",
            example = "contracts",
            in = ParameterIn.QUERY),
        @Parameter(
            name = "service_id",
            description = "ID único del service",
            example = "1123",
            required = true,
            in = ParameterIn.QUERY),
        @Parameter(
            name = "contract_id",
            description = "ID único del contract",
            required = true,
            example = "123e4567",
            in = ParameterIn.QUERY)
      })
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "OK",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ServicesListResponseDTO.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Solicitud inválida",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class))),
        @ApiResponse(
            responseCode = "401",
            description = "No autorizado",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class)))
      })
  public Mono<ServicesListResponseDTO> getServices(
      @RequestParam String expand,
      @RequestParam String service_id,
      @RequestParam String contract_id) {
    ServicesListRequestDTO criteria = new ServicesListRequestDTO(service_id, contract_id, expand);
    return channelServiceUseCase
        .getServices(mapper.ServicesListRequestDtoToServicesListRequest(criteria))
        .map(mapper::ServicesListResponseToServicesListResponseDTO);
  }
}
