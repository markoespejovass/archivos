package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class WrapperGetConsentsRequest {

  private String legitimate_code;
  private String treatment_code;
  private String purpose_code;
  private String status_code;
  private String bank_id;
  private String offset;
  private String limit;
}
