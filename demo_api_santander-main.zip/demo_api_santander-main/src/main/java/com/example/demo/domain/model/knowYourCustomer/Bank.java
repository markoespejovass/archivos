package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Bank {

  private String bankId;
  private String bankName;
}
