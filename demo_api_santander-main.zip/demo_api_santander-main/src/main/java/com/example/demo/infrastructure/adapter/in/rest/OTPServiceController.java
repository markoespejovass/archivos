package com.example.demo.infrastructure.adapter.in.rest;


import com.example.demo.application.port.in.OTPServiceUseCase;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForMailing.GetTrackingForMailResponse;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserRequest;
import com.example.demo.domain.model.otp.getAggregateTrackingForUser.GetTrackingForUserResponse;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportRequest;
import com.example.demo.domain.model.otp.getReportIdByDate.GetReportResponse;
import com.example.demo.domain.model.otp.saveMailing.SaveMailRequest;
import com.example.demo.domain.model.otp.saveMailing.SaveMailResponse;
import com.example.demo.domain.model.otp.sendMailing.RequestOTP;
import com.example.demo.domain.model.otp.sendMailing.ResponseOTP;
import com.example.demo.infrastructure.adapter.in.dto.operationControl.OperationControlRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.operationControl.WrapperGetOperabilityStatusResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing.GetTrackingForMailRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing.GetTrackingForMailResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser.GetTrackingForUserRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForUser.GetTrackingForUserResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate.GetReportRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate.GetReportResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing.SaveMailRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing.SaveMailResponseDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing.RequestOTPDTO;
import com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing.ResponseOTPDTO;
import com.example.demo.infrastructure.adapter.in.mapper.OTPServiceMapper;
import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/otpService")
@Tag(name = "OTP Service", description = "API para la gestión de OTP.")
@AllArgsConstructor
public class OTPServiceController {

    private final OTPServiceUseCase otpServiceUseCase;
    private final OTPServiceMapper mapper;

    @PostMapping("/send")
    @Operation(
            summary = "Envia Correo.",
            description = "Envia Correo",
            method = "POST")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema =
                                    @Schema(implementation = ResponseOTP.class))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Solicitud inválida",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(
                            responseCode = "401",
                            description = "No autorizado",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))
            })
    public Mono<ResponseOTPDTO> sendMailing(@RequestBody RequestOTPDTO criteria) {

        return otpServiceUseCase
                .sendMailing(Mono.just(mapper.RequestOTPDtoToRequestOTP(criteria)))
                .map(mapper::ResponseOTPToResponseOTPDTO);
    }

    @PostMapping("saveMailing")
    @Operation(
            summary = "Guardar Correo.",
            description = "Guardar Correo",
            method = "POST")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema =
                                    @Schema(implementation = SaveMailResponse.class))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Solicitud inválida",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(
                            responseCode = "401",
                            description = "No autorizado",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))
            })
    public Mono<SaveMailResponseDTO> saveMailing(@RequestBody SaveMailRequestDTO criteria) {

        return otpServiceUseCase
                .saveMailing(Mono.just(mapper.SaveMailRequestDtoToSaveMailRequest(criteria)))
                .map(mapper::SaveMailResponseToSaveMailResponseDTO);
    }

    @PostMapping("getReportIdByDate")
    @Operation(
            summary = "Obtener reporte de Correos.",
            description = "Obtener reporte por fechas y id de correo",
            method = "POST")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema =
                                    @Schema(implementation = GetReportResponse.class))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Solicitud inválida",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(
                            responseCode = "401",
                            description = "No autorizado",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))
            })
    public Mono<GetReportResponseDTO> getReportIdByDate(@RequestBody GetReportRequestDTO criteria) {

        return otpServiceUseCase
                .getReportIdByDate(Mono.just(mapper.GetReportRequestDtoToGetReportRequest(criteria)))
                .map(mapper::GetReportResponseToGetReportResponseDTO);
    }

    @PostMapping("getAggregateTrackingForUser")
    @Operation(
            summary = "Obtener metricas por usuario.",
            description = "Obtener metricas por usuario",
            method = "POST")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema =
                                    @Schema(implementation = GetTrackingForUserResponse.class))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Solicitud inválida",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(
                            responseCode = "401",
                            description = "No autorizado",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))
            })
    public Mono<GetTrackingForUserResponseDTO> getAggregateTrackingForUser(@RequestBody GetTrackingForUserRequestDTO criteria) {

        return otpServiceUseCase
                .getAggregateTrackingForUser(Mono.just(mapper.GetTrackingForUserRequestDtoToGetTrackingForUserRequest(criteria)))
                .map(mapper::GetTrackingForUserResponseToGetTrackingForUserResponseDTO);
    }

    @PostMapping("getAggregateTrackingForMailing")
    @Operation(
            summary = "Obtener metricas por correo.",
            description = "Obtener metricas por correo",
            method = "POST")
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema =
                                    @Schema(implementation = GetTrackingForMailResponse.class))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Solicitud inválida",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class))),
                    @ApiResponse(
                            responseCode = "401",
                            description = "No autorizado",
                            content =
                            @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = ApiError.class)))
            })
    public Mono<GetTrackingForMailResponseDTO> getAggregateTrackingForMailing(@RequestBody GetTrackingForMailRequestDTO criteria) {

        return otpServiceUseCase
                .getAggregateTrackingForMailing(Mono.just(mapper.GetTrackingForMailRequestDtoToGetTrackingForMailRequest(criteria)))
                .map(mapper::GetTrackingForMailResponseToGetTrackingForMailResponseDTO);
    }



}
