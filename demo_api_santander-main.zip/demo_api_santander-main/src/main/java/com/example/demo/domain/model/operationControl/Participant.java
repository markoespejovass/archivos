package com.example.demo.domain.model.operationControl;

import lombok.Data;

@Data
public class Participant {

  private String participationTypeCode;
  private String signatureTypeCode;
}
