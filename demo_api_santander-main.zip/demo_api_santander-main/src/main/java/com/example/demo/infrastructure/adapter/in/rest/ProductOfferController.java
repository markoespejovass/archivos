package com.example.demo.infrastructure.adapter.in.rest;

/*
@RestController
@RequestMapping("/products")
@Tag(name = "ProductOffer", description = "API de prueba para consultar la oferta de producto")
public class ProductOfferController {

    private final ProductOfferUseCase productOfferService;

    public ProductOfferController(ProductOfferService productOfferService) {
        this.productOfferService = productOfferService;
    }

    @PostMapping
    @Operation(
            summary = "Buscar oferta de producto",
            description = "Realiza la busqueda de oferta de producto",
            method = "POST",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Criterios de busqueda",
                    required = true,
                    content = @Content(schema = @Schema(implementation = ProductOfferCriteria.class))))
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Oferta exitosa",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ProductOffer.class))),
            @ApiResponse(responseCode = "400", description = "Solicitud inválida"),
            @ApiResponse(responseCode = "401", description = "No autorizado")
    })
//    @SecurityRequirement(name = "bearerAuth")
    public Mono<ProductOffer> findProductOffer(
            @RequestBody ProductOfferCriteria criteria) {
        return productOfferService.getProductOffers(criteria);
    }
}
*/
