package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.operationControl.WrapperGetOperabilityStatusRequest;
import com.example.demo.domain.model.operationControl.WrapperGetOperabilityStatusResponse;
import com.example.demo.infrastructure.adapter.in.dto.operationControl.OperationControlRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.operationControl.WrapperGetOperabilityStatusResponseDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OperationControlMapper {

  WrapperGetOperabilityStatusRequest toWrapperGetOperabilityStatusRequest(
      OperationControlRequestDTO contractRequestDTO);

  WrapperGetOperabilityStatusResponseDTO toWrapperGetOperabilityStatusResponseDTO(
      WrapperGetOperabilityStatusResponse generateContractIdentifiersResponse);
}
