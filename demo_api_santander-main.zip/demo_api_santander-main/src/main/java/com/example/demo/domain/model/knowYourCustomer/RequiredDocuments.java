package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class RequiredDocuments {

  private String documentLabel;
  private Document document;
}
