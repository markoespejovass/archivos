package com.example.demo.domain.model.otp.saveMailing;

import jakarta.xml.bind.annotation.*;
import lombok.Data;

@Data
@XmlRootElement(name = "Envelope")
public class SaveMailRequest {

    @XmlElement(name = "Body")
    private BodyOTP body;
}
