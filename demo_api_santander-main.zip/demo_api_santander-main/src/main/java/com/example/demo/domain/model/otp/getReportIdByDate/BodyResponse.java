package com.example.demo.domain.model.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class BodyResponse {

    @XmlElement(name = "RESULT")
    private RESULT rESULT;
}
