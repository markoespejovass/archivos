package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class AuditChannel {

  private PreferenceChannel creationChannel;
}
