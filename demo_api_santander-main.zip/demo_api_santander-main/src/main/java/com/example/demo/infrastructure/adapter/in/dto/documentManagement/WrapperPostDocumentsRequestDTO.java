package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class WrapperPostDocumentsRequestDTO {

  private WrapperMyDocumentRequestDTO document;
  private App caller_information;
}
