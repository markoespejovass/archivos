package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WrapperGetConsentsRequestDTO {

  private String legitimate_code;
  private String treatment_code;
  private String purpose_code;
  private String status_code;
  private String bank_id;
  private String offset;
  private String limit;

}
