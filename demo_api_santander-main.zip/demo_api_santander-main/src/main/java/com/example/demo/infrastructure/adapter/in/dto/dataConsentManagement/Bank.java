package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import lombok.Data;

@Data
public class Bank {

  private String bankId;
}
