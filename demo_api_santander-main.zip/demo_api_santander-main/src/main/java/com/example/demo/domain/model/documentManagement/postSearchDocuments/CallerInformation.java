package com.example.demo.domain.model.documentManagement.postSearchDocuments;

import lombok.Data;

@Data
public class CallerInformation {

  private String appId;

  private String name;
}
