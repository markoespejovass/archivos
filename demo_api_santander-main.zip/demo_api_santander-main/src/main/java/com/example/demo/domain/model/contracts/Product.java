package com.example.demo.domain.model.contracts;

import lombok.Data;

@Data
public class Product {

  private String productId;
  private Subproduct subproduct;
}
