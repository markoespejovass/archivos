package com.example.demo.infrastructure.config.error;

import com.example.demo.domain.exception.DomainException;
import com.example.demo.domain.exception.ErrorCode;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.util.concurrent.TimeoutException;
import org.springframework.stereotype.Component;

@Component
public class WebClientNetworkErrorMapper {

  public DomainException map(Throwable throwable) {

    if (throwable instanceof TimeoutException) {
      return new DomainException(ErrorCode.GATEWAY_TIMEOUT);
    }

    if (throwable instanceof ConnectException) {
      return new DomainException(ErrorCode.SERVICE_UNAVAILABLE);
    }

    if (throwable instanceof UnknownHostException) {
      return new DomainException(ErrorCode.SERVICE_UNAVAILABLE);
    }

    return new DomainException(ErrorCode.UNEXPECTED_ERROR);
  }
}
