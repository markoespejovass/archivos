package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import lombok.Data;

@Data
public class WrapperPostConsentRequestBodyDTO {

  private StatusInfo statusInfo;

  private ValidityPeriod validityPeriod;

  private Bank bank;

  private String legitimateCode;

  private String treatmentCode;

  private String purposeCode;
}
