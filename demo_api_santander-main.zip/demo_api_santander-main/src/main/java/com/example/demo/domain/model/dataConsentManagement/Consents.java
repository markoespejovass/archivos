package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class Consents {

  private String consentId;
  private StatusInfo statusInfo;
  private Bank bank;
  private String legitimateCode;
  private String legitimateDescription;
  private String treatmentCode;
  private String treatmentDescription;
  private String purposeCode;
  private String purposeDescription;
  private ValidityPeriod validityPeriod;
}
