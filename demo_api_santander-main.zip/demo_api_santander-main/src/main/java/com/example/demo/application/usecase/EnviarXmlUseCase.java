package com.example.demo.application.usecase;

import org.springframework.stereotype.Service;

@Service
public class EnviarXmlUseCase {
  /*
   @Autowired MailSenderPort mailSenderPort;

   public EnviarXmlUseCase(MailSenderPort mailSenderPort) {
     this.mailSenderPort = mailSenderPort;
   }

   public Mono<String> ejecutar(String xml) {
     return mailSenderPort.sendXml(xml);
   }

  */
}
