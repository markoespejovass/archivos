package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class AntiMoneyLaundering {
  private String amlId;
}
