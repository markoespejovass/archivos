package com.example.demo.infrastructure.adapter.in.dto.operationControl;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class OperationControlRequestDTO {
  private String offset;
  private String limit;
  private String product_family;
}
