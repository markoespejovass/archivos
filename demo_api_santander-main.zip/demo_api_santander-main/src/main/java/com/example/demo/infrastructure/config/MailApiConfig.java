package com.example.demo.infrastructure.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MailApiConfig {
  /*
   @Value("${mail.api.base-url}")
   private String baseUrl;

   @Value("${mail.api.user}")
   private String user;

   @Value("${mail.api.password}")
   private String password;

   @Value("${mail.api.timeout}")
   private int timeoutSeconds;

   @Bean
   WebClient xmlMailWebClient() {
     return WebClientFactory.create(baseUrl, user, password, timeoutSeconds);
   }

   @Bean
   MailSenderPort mailSenderPort(WebClient xmlMailWebClient) {
     return new EmailAdapter(xmlMailWebClient);
   }

  */
}
