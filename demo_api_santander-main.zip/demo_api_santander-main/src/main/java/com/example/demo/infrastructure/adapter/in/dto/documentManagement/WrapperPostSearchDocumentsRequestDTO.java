package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class WrapperPostSearchDocumentsRequestDTO {

  private CallerInformation caller_information;

  private SearchParameters search_parameters;

  private NavigationParameters navigation_parameters;
}
