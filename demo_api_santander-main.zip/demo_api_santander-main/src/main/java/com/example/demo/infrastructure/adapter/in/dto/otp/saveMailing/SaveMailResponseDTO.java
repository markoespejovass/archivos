package com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@Data
@XmlRootElement(name = "ENVELOPE")
public class SaveMailResponseDTO {

    @XmlElement(name = "BODY")
    private BODYResponse bODY;
}
