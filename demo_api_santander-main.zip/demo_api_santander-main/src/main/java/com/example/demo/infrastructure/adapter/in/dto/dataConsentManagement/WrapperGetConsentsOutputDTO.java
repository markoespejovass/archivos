package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import com.example.demo.infrastructure.adapter.in.dto.operationControl.Links;
import java.util.List;
import lombok.Data;

@Data
public class WrapperGetConsentsOutputDTO {

  private List<Consents> consents;

  private Links _links;
}
