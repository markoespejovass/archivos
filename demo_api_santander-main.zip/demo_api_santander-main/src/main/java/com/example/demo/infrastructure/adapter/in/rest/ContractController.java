package com.example.demo.infrastructure.adapter.in.rest;

import com.example.demo.application.port.in.ContractsUseCase;
import com.example.demo.infrastructure.adapter.in.dto.contracts.ContractRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.contracts.ContractResponseDTO;
import com.example.demo.infrastructure.adapter.in.mapper.ContractMapper;
import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/contracts")
@Tag(name = "Contract", description = "API para la gestión de Contract.")
public class ContractController {

  private final ContractsUseCase contractsUseCase;
  private final ContractMapper mapper;

  public ContractController(ContractsUseCase contractsUseCase, ContractMapper mapper) {
    this.contractsUseCase = contractsUseCase;
    this.mapper = mapper;
  }

  @PostMapping("/create_contract_identifiers")
  @Operation(
      summary = "Crea un id de contract.",
      description = "Crea un id de contrato",
      method = "POST")
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "OK",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ContractResponseDTO.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Solicitud inválida",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class))),
        @ApiResponse(
            responseCode = "401",
            description = "No autorizado",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class)))
      })
  public Mono<ContractResponseDTO> postContractId(@RequestBody ContractRequestDTO criteria) {
    return contractsUseCase
        .postContractId(mapper.ContractRequestDtoToGenerateContractIdentifiersData(criteria))
        .map(mapper::GenerateContractIdentifiersResponseToContractResponseDTO);
  }
}
