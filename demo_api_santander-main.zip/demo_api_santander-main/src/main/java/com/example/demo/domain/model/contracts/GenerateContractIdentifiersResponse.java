package com.example.demo.domain.model.contracts;

import lombok.Data;

@Data
public class GenerateContractIdentifiersResponse {

  private String nationalIdentification;
  private String internalIdentification;
}
