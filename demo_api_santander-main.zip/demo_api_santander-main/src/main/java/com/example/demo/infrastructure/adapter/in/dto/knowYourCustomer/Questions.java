package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Questions {

  private String typeDescription;
  private String translationCode;
}
