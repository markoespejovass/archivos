package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import java.util.List;
import lombok.Data;

@Data
public class KnowYourCustomerQuestionnaires {

  private String questionnaireId;
  private Audit audit;
  private List<Questions> questions;
}
