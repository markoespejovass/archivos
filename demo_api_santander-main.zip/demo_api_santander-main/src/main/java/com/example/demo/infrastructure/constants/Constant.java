package com.example.demo.infrastructure.constants;

public class Constant {
  public static final String URI_API_PRODUCT_OFFER = "/api/Producto/Ofertar";
  public static final String URI_API_CONTRACT = "/api/Producto/Ofertar";
  public static final String URI_API_KNOW_YOUR_CUSTOMER = "/api/Producto/Ofertar";
  public static final String URI_API_DATA_CONSEMENT =
      "/v7/data_consent_management/parties/{party_id}/consent_agreements";
  public static final String URI_API_DOCUMENT_MANAGEMENT = "/api/Token/Login";
  public static final String URI_API_TOKEN = "/api/Token/Login";
}
