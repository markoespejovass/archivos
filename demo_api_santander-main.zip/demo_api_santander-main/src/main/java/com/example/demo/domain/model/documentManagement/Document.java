package com.example.demo.domain.model.documentManagement;

import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class Document {

  private Status status;

  private String documentId;

  private String mimeType;

  private String name;

  private String typeCode;

  private String folderReference;

  private String aclReference;

  private List<Owner> owners;

  private List<DocumentProperty> documentProperties;

  private Map<String, Object> customMetadata;
}
