package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class DocumentProperty {

  private String key;

  private String value;
}
