package com.example.demo.domain.model.documentManagement.postSearchDocuments;

import com.example.demo.domain.model.documentManagement.SearchProperties;
import java.util.List;
import lombok.Data;

@Data
public class SearchParameters {

  private String discriminator;

  private List<SearchProperties> searchProperties;

  private String sortOrder;

  private String sortBy;
}
