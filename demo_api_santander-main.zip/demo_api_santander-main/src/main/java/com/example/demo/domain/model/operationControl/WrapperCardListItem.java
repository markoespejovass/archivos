package com.example.demo.domain.model.operationControl;

import lombok.Data;

@Data
public class WrapperCardListItem {

  private String cardId;
  private Cardholder cardholder;
  private Boolean isOperable;
}
