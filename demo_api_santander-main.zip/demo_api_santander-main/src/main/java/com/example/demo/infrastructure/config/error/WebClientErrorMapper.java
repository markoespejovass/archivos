package com.example.demo.infrastructure.config.error;

import com.example.demo.domain.exception.DomainException;
import com.example.demo.domain.exception.ErrorCode;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class WebClientErrorMapper {

  public DomainException map(HttpStatus status) {

    if (status == HttpStatus.BAD_GATEWAY) {
      return new DomainException(ErrorCode.BAD_GATEWAY);
    }

    if (status == HttpStatus.REQUEST_TIMEOUT) {
      return new DomainException(ErrorCode.REQUEST_TIMEOUT);
    }

    if (status == HttpStatus.NOT_FOUND) {
      return new DomainException(ErrorCode.RESOURCE_NOT_FOUND);
    }

    return new DomainException(ErrorCode.UNEXPECTED_ERROR);
  }
}
