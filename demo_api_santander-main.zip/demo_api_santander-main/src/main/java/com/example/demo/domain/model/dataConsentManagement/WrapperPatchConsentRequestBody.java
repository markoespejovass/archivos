package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class WrapperPatchConsentRequestBody {
  private StatusInfo statusInfo;

  private ValidityPeriod validityPeriod;

  private String changeReasonCode;
}
