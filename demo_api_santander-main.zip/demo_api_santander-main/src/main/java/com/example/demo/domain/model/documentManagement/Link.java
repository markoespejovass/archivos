package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class Link {

  private String href;
}
