package com.example.demo.domain.model.chanelService;

import java.util.List;
import lombok.Data;

@Data
public class ServicesListResponse {

  private List<GetServicesData> services;
  private Links links;
}
