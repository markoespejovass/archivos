package com.example.demo.infrastructure.adapter.in.dto.chanelService;

import lombok.Data;

@Data
public class Service {

  private String serviceId;
  private String name;
  private String type;
  private Boolean isRelatedToContract;
}
