package com.example.demo.domain.model.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class RESULT {

    @XmlElement(name = "SUCCESS")
    private Boolean sUCCESS;

    @XmlElement(name = "Mailing")
    private Mailing mailing;
}
