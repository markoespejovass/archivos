package com.example.demo.domain.model.chanelService;

import java.util.List;
import lombok.Data;

@Data
public class ServicesListRequest {

  private List<GetServicesData> services;
  private Links links;
}
