package com.example.demo.domain.model.documentManagement;

import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperMyDocumentResponse;
import lombok.Data;

@Data
public class WrapperPostDocumentsResponse {

  private WrapperMyDocumentResponse document;

  private LinkReference access_information;
}
