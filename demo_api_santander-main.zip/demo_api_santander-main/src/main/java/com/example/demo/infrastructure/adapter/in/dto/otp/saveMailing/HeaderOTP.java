package com.example.demo.infrastructure.adapter.in.dto.otp.saveMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class HeaderOTP {

    @XmlElement(name = "MailingName")
    private String mailingName;

    @XmlElement(name = "FromName")
    private String fromName;

    @XmlElement(name = "FromAddress")
    private String fromAddress;

    @XmlElement(name = "ReplyTo")
    private String replyTo;

    @XmlElement(name = "Visibility")
    private Integer visibility;

    @XmlElement(name = "FolderPath")
    private String folderPath;

    @XmlElement(name = "Subject")
    private String subject;

    @XmlElement(name = "TrackingLevel")
    private Integer trackingLevel;

    @XmlElement(name = "Encoding")
    private Integer encoding;

    @XmlElement(name = "ListID")
    private Integer listID;
}
