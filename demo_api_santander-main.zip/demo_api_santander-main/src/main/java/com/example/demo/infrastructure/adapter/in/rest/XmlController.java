package com.example.demo.infrastructure.adapter.in.rest;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/xml")
public class XmlController {


   @GetMapping(value ="/otp", produces = MediaType.APPLICATION_XML_VALUE)
   public Mono<String> enviar() throws IOException {
       return Mono.fromCallable(()->{
           ClassPathResource resource = new ClassPathResource("mock/SendMailResponse.xml");
           return new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
       }).subscribeOn(Schedulers.boundedElastic());

   }


}
