package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Bank {

  private String bankId;
  private String bankName;
}
