package com.example.demo.domain.model.otp.sendMailing;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class RECIPIENTDETAIL {

    @JacksonXmlProperty(localName = "EMAIL")
    private String eMAIL;

    @JacksonXmlProperty(localName = "SEND_STATUS")
    private Integer sENDSTATUS;

    @JacksonXmlProperty(localName = "ERROR_CODE")
    private Integer eRRORCODE;

    @JacksonXmlProperty(localName = "ERROR_STRING")
    private String eRRORSTRING;
}
