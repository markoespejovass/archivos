package com.example.demo.domain.model.chanelService;

import java.util.List;
import lombok.Data;

@Data
public class AllContracts {

  private List<Account> accounts;
  private List<CardContract> cardContracts;
  private List<Loan> loans;
  private List<Deposit> deposits;
}
