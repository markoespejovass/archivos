package com.example.demo.domain.model.documentManagement;

import lombok.Data;

@Data
public class App {
  private String appId;
  private String name;
}
