package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class WrapperGetDocumentsRequestDTO {

  private WrapperMyDocumentResponseDTO document;
}
