package com.example.demo.infrastructure.adapter.in.rest;

import com.example.demo.application.port.in.OperationControlsUseCase;
import com.example.demo.infrastructure.adapter.in.dto.operationControl.OperationControlRequestDTO;
import com.example.demo.infrastructure.adapter.in.dto.operationControl.WrapperGetOperabilityStatusResponseDTO;
import com.example.demo.infrastructure.adapter.in.mapper.OperationControlMapper;
import com.example.demo.infrastructure.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/operationControl")
@Tag(name = "Operation Control", description = "API para la gestión de operationControl.")
public class OperationControlController {
  private final OperationControlsUseCase operationControlUseCase;
  private final OperationControlMapper mapper;

  public OperationControlController(
      OperationControlsUseCase operationControlUseCase, OperationControlMapper mapper) {
    this.operationControlUseCase = operationControlUseCase;
    this.mapper = mapper;
  }

  @GetMapping
  @Operation(
      summary = "Obtiene un listado de productos.",
      description = "Obtiene un listado de productos",
      method = "GET",
      parameters = {
        @Parameter(
            name = "product_family",
            description = "famila del producto a buscar",
            example = "loans",
            in = ParameterIn.QUERY),
        @Parameter(name = "offset", description = "offset", example = "10", in = ParameterIn.QUERY),
        @Parameter(name = "limit", description = "limit", example = "1", in = ParameterIn.QUERY)
      })
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "OK",
            content =
                @Content(
                    mediaType = "application/json",
                    schema =
                        @Schema(implementation = WrapperGetOperabilityStatusResponseDTO.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Solicitud inválida",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class))),
        @ApiResponse(
            responseCode = "401",
            description = "No autorizado",
            content =
                @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ApiError.class)))
      })
  public Mono<WrapperGetOperabilityStatusResponseDTO> getIdOperationControl(
      @RequestParam String offset,
      @RequestParam String limit,
      @RequestParam String product_family) {
    OperationControlRequestDTO criteria =
        new OperationControlRequestDTO(offset, limit, product_family);
    return operationControlUseCase
        .getOperationControl(mapper.toWrapperGetOperabilityStatusRequest(criteria))
        .map(mapper::toWrapperGetOperabilityStatusResponseDTO);
  }
}
