package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class PurposeOfRelationshipAndSourceOfFunds {

  private String purposeOfRelationship;
  private String typeOfOperations;
  private String mainCustomer;
  private String mainSupplier;
}
