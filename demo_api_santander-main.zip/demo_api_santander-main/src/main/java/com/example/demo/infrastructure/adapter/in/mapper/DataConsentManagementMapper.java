package com.example.demo.infrastructure.adapter.in.mapper;

import com.example.demo.domain.model.dataConsentManagement.*;
import com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement.*;
import java.util.List;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DataConsentManagementMapper {

  WrapperGetConsentsRequest WrapperGetConsentsRequestDtoToWrapperGetConsentsRequest(
      WrapperGetConsentsRequestDTO contractRequestDTO);

  WrapperGetConsentsOutputDTO WrapperGetConsentsOutputToWrapperGetConsentsOutputDTO(
      WrapperGetConsentsOutput generateContractIdentifiersResponse);

  WrapperPostConsentRequestBody WrapperPostConsentRequestBodyDtoToWrapperPostConsentRequestBody(
      WrapperPostConsentRequestBodyDTO contractRequestDTO);

  WrapperPostConsentResponseBodyDTO
      WrapperPostConsentResponseBodyToWrapperPostConsentResponseBodyDTO(
          WrapperPostConsentResponseBody generateContractIdentifiersResponse);

  List<WrapperPostConsentResponseBodyDTO>
      WrapperPostConsentResponseBodyListToWrapperPostConsentResponseBodyDTOList(
          List<WrapperPostConsentResponseBody> generateContractIdentifiersResponse);

  WrapperPatchConsentRequestBody WrapperPatchConsentRequestBodyDtoToWrapperPatchConsentRequestBody(
      WrapperPatchConsentRequestBodyDTO contractRequestDTO);
}
