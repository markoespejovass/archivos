package com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class RECIPIENTDETAIL {

    @XmlElement(name = "EMAIL")
    private String eMAIL;

    @XmlElement(name = "SEND_STATUS")
    private Integer sENDSTATUS;

    @XmlElement(name = "ERROR_CODE")
    private Integer eRRORCODE;

    @XmlElement(name = "ERROR_STRING")
    private String eRRORSTRING;
}
