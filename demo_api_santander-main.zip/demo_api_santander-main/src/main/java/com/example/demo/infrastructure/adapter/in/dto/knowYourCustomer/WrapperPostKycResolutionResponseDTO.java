package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class WrapperPostKycResolutionResponseDTO {

  private String kycResolutionId;

  private String localReference;

  private Risk risk;

  private Requirements requirements;
}
