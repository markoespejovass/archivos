package com.example.demo.domain.model.operationControl;

public class WrapperGetOperabilityStatusRequest {}
