package com.example.demo.domain.model.chanelService;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GetServicesData {

  private Service service;
  private AllContracts allContracts;
}
