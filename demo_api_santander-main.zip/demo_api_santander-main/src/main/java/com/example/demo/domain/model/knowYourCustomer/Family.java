package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Family {

  private String productFamilyId;
  private String name;
}
