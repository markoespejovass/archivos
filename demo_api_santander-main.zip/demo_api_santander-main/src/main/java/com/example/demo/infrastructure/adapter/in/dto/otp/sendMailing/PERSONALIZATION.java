package com.example.demo.infrastructure.adapter.in.dto.otp.sendMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class PERSONALIZATION {

    @XmlElement(name = "TAG_NAME")
    private String tAGNAME;

    @XmlElement(name = "VALUE")
    private String vALUE;
}
