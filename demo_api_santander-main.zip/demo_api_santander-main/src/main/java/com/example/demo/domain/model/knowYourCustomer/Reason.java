package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Reason {

  private String code;
  private String value;
  private String typeDescription;
}
