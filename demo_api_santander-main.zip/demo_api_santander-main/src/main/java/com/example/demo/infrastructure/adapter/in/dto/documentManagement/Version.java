package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class Version {

  private String label;
}
