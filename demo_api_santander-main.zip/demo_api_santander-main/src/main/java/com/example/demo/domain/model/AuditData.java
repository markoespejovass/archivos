package com.example.demo.domain.model;

import java.time.OffsetDateTime;

public record AuditData(String appId,
                        String usuario,
                        String ipServidor,
                        String transaccionId,
                        String origen,
                        String timeStamp) {
}
