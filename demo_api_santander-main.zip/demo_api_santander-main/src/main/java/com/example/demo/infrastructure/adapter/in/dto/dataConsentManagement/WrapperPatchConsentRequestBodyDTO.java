package com.example.demo.infrastructure.adapter.in.dto.dataConsentManagement;

import lombok.Data;

@Data
public class WrapperPatchConsentRequestBodyDTO {

  private StatusInfo statusInfo;

  private ValidityPeriod validityPeriod;

  private String changeReasonCode;
}
