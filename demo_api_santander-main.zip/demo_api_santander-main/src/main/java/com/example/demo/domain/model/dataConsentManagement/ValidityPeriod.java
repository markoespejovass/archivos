package com.example.demo.domain.model.dataConsentManagement;

import lombok.Data;

@Data
public class ValidityPeriod {
  private String startDate;
  private String endDate;
}
