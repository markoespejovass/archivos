package com.example.demo.domain.model.otp.sendMailing;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

import java.util.List;

@Data
public class Recipient {
    @XmlElement(name = "EMAIL")
    private String eMAIL;

    @XmlElement(name = "BODY_TYPE")
    private String bODYTYPE;

    @XmlElement(name = "PERSONALIZATION")
    private List<PERSONALIZATION> pERSONALIZATION;
}
