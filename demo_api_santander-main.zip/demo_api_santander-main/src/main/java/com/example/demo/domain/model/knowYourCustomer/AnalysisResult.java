package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class AnalysisResult {
  private Boolean isVerified;
}
