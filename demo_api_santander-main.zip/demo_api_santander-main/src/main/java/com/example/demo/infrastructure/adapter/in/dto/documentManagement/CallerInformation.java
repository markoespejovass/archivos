package com.example.demo.infrastructure.adapter.in.dto.documentManagement;

import lombok.Data;

@Data
public class CallerInformation {

  private String appId;

  private String name;
}
