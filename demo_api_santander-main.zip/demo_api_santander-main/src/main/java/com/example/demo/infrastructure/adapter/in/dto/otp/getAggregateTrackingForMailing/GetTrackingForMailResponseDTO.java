package com.example.demo.infrastructure.adapter.in.dto.otp.getAggregateTrackingForMailing;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@XmlRootElement(name = "Envelope")
@Data
public class GetTrackingForMailResponseDTO {

    @XmlElement(name = "Body")
    private BodyResponse body;
}
