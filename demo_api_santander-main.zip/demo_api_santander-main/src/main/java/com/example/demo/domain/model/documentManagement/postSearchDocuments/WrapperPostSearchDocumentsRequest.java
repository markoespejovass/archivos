package com.example.demo.domain.model.documentManagement.postSearchDocuments;

import lombok.Data;

@Data
public class WrapperPostSearchDocumentsRequest {

  private CallerInformation caller_information;

  private SearchParameters search_parameters;

  private NavigationParameters navigation_parameters;
}
