package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Country {

  private String code;
  private String name;
}
