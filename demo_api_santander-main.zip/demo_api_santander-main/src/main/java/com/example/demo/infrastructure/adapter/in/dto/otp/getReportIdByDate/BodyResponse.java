package com.example.demo.infrastructure.adapter.in.dto.otp.getReportIdByDate;

import jakarta.xml.bind.annotation.XmlElement;
import lombok.Data;

@Data
public class BodyResponse {

    @XmlElement(name = "RESULT")
    private RESULT rESULT;
}
