package com.example.demo.infrastructure.exception;

import com.example.demo.domain.exception.DomainException;
import com.example.demo.domain.exception.ErrorCode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import reactor.core.publisher.Mono;

@RestControllerAdvice
public class GlobalExceptionHandler {

  private final HttpStatusResolver statusResolver;

  public GlobalExceptionHandler(HttpStatusResolver statusResolver) {
    this.statusResolver = statusResolver;
  }

  /** Errores de dominio (reglas de negocio, validaciones, etc.) */
  @ExceptionHandler(DomainException.class)
  public Mono<ResponseEntity<ApiError>> handleDomainException(DomainException ex) {

    ErrorCode errorCode = ex.getErrorCode();
    HttpStatus status = statusResolver.resolve(errorCode);

    ApiError apiError = ApiError.from(errorCode);

    return Mono.just(ResponseEntity.status(status).body(apiError));
  }

  /** Fallback final (errores no controlados) */
  @ExceptionHandler(Throwable.class)
  public Mono<ResponseEntity<ApiError>> handleUnexpected(Throwable ex) {

    ApiError apiError = ApiError.from(ErrorCode.UNEXPECTED_ERROR);

    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(apiError));
  }
}
