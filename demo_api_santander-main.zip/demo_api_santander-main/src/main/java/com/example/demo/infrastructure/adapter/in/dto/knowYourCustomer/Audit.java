package com.example.demo.infrastructure.adapter.in.dto.knowYourCustomer;

import lombok.Data;

@Data
public class Audit {

  private String lastUpdateDate;
  private String lastUpdateProcess;
  private String expirationDate;
  private String completionDate;
  private String submissionDate;
}
