package com.example.demo.application.port.in;

import com.example.demo.domain.model.dataConsentManagement.*;
import reactor.core.publisher.Mono;

public interface DataConsentManagementUseCase {

  Mono<WrapperGetConsentsOutput> getConsent(WrapperGetConsentsRequest criteria, String partyId);

  Mono<WrapperPostConsentResponseBody> postConsent(
      WrapperPostConsentRequestBody criteria, String partyId);

  Mono<Void> patchConsent(
      WrapperPatchConsentRequestBody criteria, String partyId, String consentId);
}
