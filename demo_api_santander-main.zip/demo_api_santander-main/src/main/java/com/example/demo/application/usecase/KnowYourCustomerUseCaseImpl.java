package com.example.demo.application.usecase;

import com.example.demo.application.port.in.KnowYourCustomerUseCase;
import com.example.demo.application.port.out.KnowYourCustomerRepositoryPort;
import com.example.demo.domain.model.knowYourCustomer.WrapperPostKycResolutionRequest;
import com.example.demo.domain.model.knowYourCustomer.WrapperPostKycResolutionResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@AllArgsConstructor
@Service
public class KnowYourCustomerUseCaseImpl implements KnowYourCustomerUseCase {

  private final KnowYourCustomerRepositoryPort knowYourCustomerRepositoryPort;

  @Override
  public Mono<WrapperPostKycResolutionResponse> postInitKyc(
      WrapperPostKycResolutionRequest criteria) {
    return knowYourCustomerRepositoryPort.createProcesstKyc(criteria);
  }
}
