package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Questions {

  private String typeDescription;
  private String translationCode;
}
