package com.example.demo.infrastructure.config;

import com.example.demo.infrastructure.adapter.out.external.client.TokenService;
import com.example.demo.infrastructure.config.error.WebClientExceptionFilter;
import com.example.demo.infrastructure.config.error.WebClientNetworkErrorFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

  private final ApiProperties apiProperties;

  public WebClientConfig(ApiProperties apiProperties) {
    this.apiProperties = apiProperties;
  }

  @Bean
  public WebClient webClient(
      TokenService tokenService,
      WebClientExceptionFilter exceptionFilter,
      WebClientNetworkErrorFilter networkErrorFilter) {
    return WebClient.builder()
        .baseUrl(apiProperties.getBaseUrl())
        //.filter(addTokenFilter(tokenService))
        //.filter(exceptionFilter.errorHandlingFilter())
        //.filter(networkErrorFilter.networkErrorFilter())
        .build();
  }

  private ExchangeFilterFunction addTokenFilter(TokenService tokenService) {
    return (request, next) ->
        tokenService
            .getToken()
            .flatMap(
                token -> {
                  ClientRequest authorizedRequest =
                      ClientRequest.from(request)
                          .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                          .build();
                  return next.exchange(authorizedRequest);
                });
  }
}
