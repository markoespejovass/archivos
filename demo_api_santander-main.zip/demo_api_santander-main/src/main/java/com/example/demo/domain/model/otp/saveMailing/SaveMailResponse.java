package com.example.demo.domain.model.otp.saveMailing;

import jakarta.xml.bind.annotation.*;
import lombok.Data;

@Data
@XmlRootElement(name = "ENVELOPE")
public class SaveMailResponse {

    @XmlElement(name = "BODY")
    private BODYResponse bODY;
}
