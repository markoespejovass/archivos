package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class OriginBank {
  private String bankId;
  private String bankName;
}
