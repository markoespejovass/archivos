package com.example.demo.application.port.in;

import com.example.demo.domain.model.documentManagement.*;
import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperGetDocumentsRequest;
import com.example.demo.domain.model.documentManagement.postDownloadDocument.WrapperGetDocumentsResponse;
import com.example.demo.domain.model.documentManagement.postSearchDocuments.WrapperPostSearchDocumentsRequest;
import com.example.demo.domain.model.documentManagement.postSearchDocuments.WrapperPostSearchDocumentsResponse;
import com.example.demo.domain.model.documentManagement.postUpdateDocument.WrapperPostUpdateDocumentVersionRequest;
import reactor.core.publisher.Mono;

public interface DocumentManagementUseCase {

  Mono<WrapperGetDocumentsResponse> postDownloadDocument(WrapperGetDocumentsRequest criteria);

  Mono<WrapperPostSearchDocumentsResponse> postSearchDocuments(
      WrapperPostSearchDocumentsRequest criteria);

  Mono<WrapperPostDocumentsResponse> postUpdateDocument(
      WrapperPostUpdateDocumentVersionRequest criteria);

  Mono<WrapperPostDocumentsResponse> postUploadDocument(WrapperPostDocumentsRequest criteria);
}
