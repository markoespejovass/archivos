package com.example.demo.domain.model.knowYourCustomer;

import lombok.Data;

@Data
public class Document {

  private String documentTypeCode;
  private String documentTypeDescription;
}
