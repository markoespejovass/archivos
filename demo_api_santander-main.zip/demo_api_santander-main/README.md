# demo_api_santander
6fe68aff4e5d215755fd78b8d10c2ecd81c83ddc7848dd815956be8dcd61f35f0b2a6bf7b5f939fb62c39e0282838b0a346783882a7d1557b713808eacb6a701d44fe089d5008309041d911588ad56f9ec6eb24d89a11874767be17e4b7f20ca5dfe5b53e8f0a2c35780245d11527840fe114cc5521b1151ea89f8b9acabf8989e963e05a383d27820f51582edaa6ca8be835eaa299432476cb831f655c94f4c1f2ad825834f158750c9517c966118098f7015e0c9f61902cd3f848268be12dfce077e32461f2be770fff58788145f2426fa7d88b53cb4c73b802895fbdd25ba1cffd959d59e57b55fdb2e8235707dd657700336466b4404606f2710091c821ea34017bbd7540802bf0bf9ae1a6f29c904361a15680d310919af852b58aeb67a

9b7c2d4e1a6f8c3d5e7a9b0c1d2e3f4a5c6b7d8e9f0a1b2c3d4e5f6a7b8c9d01


82dfc502b083c45715a619a97de8e1792db6636cb34bc3268637b8fe8a41e022c5e07db2cd53a430bdaeb65fd50b90cba99cb3bcfbd8dec82cecaabd8f12136f3e3cd36f321f4fda575ba47004ab5b6c89f5a3279344e06e74511b8cd262de9649998f3a9dacf32aed36a9d4e721b54b6b23f5ddaa70c01a90a21e4312dc87bbef5e73fa84f9ee88cbf711395c5485bc61f702a45528c5fcb99a35fc9a50ef0d47eaad1df4c4eb06e9a72dc926df663e307820c2bf50683792bb52c1f284060ab04886637c38bdabd543a59345e015b4b94702c8edb4d896443afdc1abfda326aeeb06c06d2ec99da56a7b01f625b07b922a930bade8fe26420b0bf58e97fc73833f5f6dac2798632f7bca0ef731a951b7a8820caba8fe2d37c71640d47bbbd7


const crypto = require('crypto');

function decryptAES256CBC(hexInput, hexKey) {
    // Convertir de HEX a Buffer
    const fullBuffer = Buffer.from(hexInput, 'hex');
    const keyBuffer = Buffer.from(hexKey, 'hex');

    // Extraer IV (primeros 16 bytes)
    const iv = fullBuffer.subarray(0, 16);

    // Extraer ciphertext
    const ciphertext = fullBuffer.subarray(16);

    // Crear decipher
    const decipher = crypto.createDecipheriv('aes-256-cbc', keyBuffer, iv);

    // Desencriptar
    let decrypted = decipher.update(ciphertext);
    decrypted = Buffer.concat([decrypted, decipher.final()]);

    return decrypted.toString('utf8');
}

// 🔑 Clave
const key = "9b7c2d4e1a6f8c3d5e7a9b0c1d2e3f4a5c6b7d8e9f0a1b2c3d4e5f6a7b8c9d01";

// 📦 Texto encriptado (IV + Ciphertext en HEX)
const encryptedText = "82dfc502b083c45715a619a97de8e1792db6636cb34bc3268637b8fe8a41e022c5e07db2cd53a430bdaeb65fd50b90cba99cb3bcfbd8dec82cecaabd8f12136f3e3cd36f321f4fda575ba47004ab5b6c89f5a3279344e06e74511b8cd262de9649998f3a9dacf32aed36a9d4e721b54b6b23f5ddaa70c01a90a21e4312dc87bbef5e73fa84f9ee88cbf711395c5485bc61f702a45528c5fcb99a35fc9a50ef0d47eaad1df4c4eb06e9a72dc926df663e307820c2bf50683792bb52c1f284060ab04886637c38bdabd543a59345e015b4b94702c8edb4d896443afdc1abfda326aeeb06c06d2ec99da56a7b01f625b07b922a930bade8fe26420b0bf58e97fc73833f5f6dac2798632f7bca0ef731a951b7a8820caba8fe2d37c71640d47bbbd7";

const result = decryptAES256CBC(encryptedText, key);
console.log(result);




±++++++++++++++++++++++++++

const crypto = require('crypto');

function encryptAES256CBC(plainText, hexKey) {
    // Convertir clave HEX a Buffer
    const keyBuffer = Buffer.from(hexKey, 'hex');

    // Generar IV aleatorio (16 bytes)
    const iv = crypto.randomBytes(16);

    // Crear cipher
    const cipher = crypto.createCipheriv('aes-256-cbc', keyBuffer, iv);

    // Encriptar
    let encrypted = cipher.update(plainText, 'utf8');
    encrypted = Buffer.concat([encrypted, cipher.final()]);

    // Concatenar IV + Ciphertext
    const result = Buffer.concat([iv, encrypted]);

    // Retornar en HEX
    return result.toString('hex');
}

// 🔑 Clave (64 caracteres HEX = 32 bytes)
const key = "9b7c2d4e1a6f8c3d5e7a9b0c1d2e3f4a5c6b7d8e9f0a1b2c3d4e5f6a7b8c9d01";

// 📦 Texto a encriptar
const jsonData = {
  profile: {
    userId: "manuel.valdivia@skyairline.com",
    homeMarket: "CL"
  },
  document: {
    type: "RUT",
    number: "44515196",
    country: "CL"
  },
  userInfo: {
    firstName: "Manuel",
    lastName: "Valdivia",
    emails: ["manuel.valdivia@skyairline.com"],
    birthdate: "1991-11-18"
  }
};

const plainText = JSON.stringify(jsonData);

const encryptedHex = encryptAES256CBC(plainText, key);
console.log(encryptedHex);


