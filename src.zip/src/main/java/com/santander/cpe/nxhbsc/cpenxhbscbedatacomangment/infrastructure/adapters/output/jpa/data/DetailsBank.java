package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailsBank {
    private String bankId;
}
