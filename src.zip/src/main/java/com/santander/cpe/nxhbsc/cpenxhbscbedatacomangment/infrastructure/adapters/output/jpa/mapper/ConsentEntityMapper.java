package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.mapper;

import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.*;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data.ConsentEntity;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data.StatusInfos;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data.ValidPeriod;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Mapper(componentModel = "spring")
public interface ConsentEntityMapper {


    @Mapping(target = "consentId", source = "id")
    @Mapping(target = "statusInfo", expression = "java(ConsentEntityMapper.setStatusInfos(consentEntity))" )
    @Mapping(target = "validityPeriod", expression = "java(ConsentEntityMapper.setValidityValidPeriod(consentEntity))" )
    @Mapping(target = "bank", ignore = true)
    @Mapping(target = "legitimateCode", source = "legitimateCode" )
    @Mapping(target = "treatmentCode", source = "treatmentCode" )
    @Mapping(target = "purposeCode", source = "purposeCode" )
    WrapperConsentDetails toDTOGet(ConsentEntity consentEntity);

    List<WrapperConsentDetails> toDTOGets(List<ConsentEntity> consentEntity);


    @Mapping(target = "id", source = "uuid")
    @Mapping(target = "partyId", source = "partyId")
    @Mapping(target = "statusCode", source = "request.statusInfo.statusCode" )
    @Mapping(target = "startDate", source = "request.validityPeriod.startDate",  qualifiedByName = "dateToString" )
    @Mapping(target = "endDate", source = "request.validityPeriod.endDate",  qualifiedByName = "dateToString" )
    @Mapping(target = "bankId", ignore = true )
    @Mapping(target = "legitimateCode", source = "request.legitimateCode" )
    @Mapping(target = "treatmentCode", source = "request.treatmentCode" )
    @Mapping(target = "purposeCode", source = "request.purposeCode" )
    ConsentEntity toEntityPost(WrapperPostConsentRequestBody request, String partyId, String uuid);

    @Mapping(source = "consentEntity.id",  target= "consentId")
    WrapperConsentId  toDTOPost(ConsentEntity consentEntity);

    @Mapping(target = "id", source = "consentId")
    @Mapping(target = "partyId", source = "partyId")
    @Mapping(target = "statusCode", source = "request.statusInfo.statusCode" )
    @Mapping(target = "startDate", source = "request.validityPeriod.startDate",  qualifiedByName = "dateToString" )
    @Mapping(target = "endDate", source = "request.validityPeriod.endDate",  qualifiedByName = "dateToString" )
    ConsentEntity toEntityUpdate(WrapperPatchConsentRequestBody request, String partyId, String consentId);

    @Named("dateToString")
    public static String dateToString(LocalDate date){
        try {
            return date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } catch (Exception ex){
            return "";
        }
    }

    @Named("stringToDate")
    public static LocalDate stringToDate(String date) {
        try {
            return LocalDate.parse(
                    date,
                    java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")
            );
        } catch (Exception ex) {
            return null;
        }
    }

    @Named("setStatusInfos")
    public static WrapperConsentDetailsStatusInfo setStatusInfos(ConsentEntity entity){
        WrapperConsentDetailsStatusInfo response = new WrapperConsentDetailsStatusInfo();
        response.setStatusCode(entity.getStatusCode());
        response.setStatusDescription(entity.getStatusDescription());
        return response;
    }

    @Named("setValidityValidPeriod")
    public static Period setValidityValidPeriod(ConsentEntity entity){
        Period response = new Period();
        response.setEndDate(stringToDate(entity.getEndDate()));
        response.setStartDate(stringToDate(entity.getStartDate()));
        return response;
    }

}
