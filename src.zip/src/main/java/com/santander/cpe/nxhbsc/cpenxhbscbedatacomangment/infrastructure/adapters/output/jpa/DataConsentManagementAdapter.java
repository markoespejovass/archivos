package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa;

import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.ports.output.DataConsentManagementRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperConsentId;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperGetConsentsOutput;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPatchConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPostConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data.ConsentEntity;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.mapper.ConsentEntityMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.repository.ConsentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class DataConsentManagementAdapter implements DataConsentManagementRepositoryPort {


  private final ConsentRepository consentRepository;

  private final ConsentEntityMapper mapper;

  @Override
  public WrapperGetConsentsOutput getConsent(String partyId) {
    WrapperGetConsentsOutput response = new WrapperGetConsentsOutput();
    var optionalConsent = consentRepository.findByPartyId(partyId);
    if (optionalConsent.isEmpty()){return response;}

    response.setConsents(mapper.toDTOGets(optionalConsent));
    return response;
  }

  @Override
  public List<WrapperConsentId> postConsent(
          WrapperPostConsentRequestBody criteria, String partyId) {
    String uuid = UUID.randomUUID().toString();
    ConsentEntity response = consentRepository.save(mapper.toEntityPost(criteria,partyId,uuid));

    return List.of(mapper.toDTOPost(response));
  }

  @Override
  public Void patchConsent(WrapperPatchConsentRequestBody criteria, String partyId, String consentId){
    consentRepository.save(mapper.toEntityUpdate(criteria,partyId,consentId));
    return null;
  }

}
