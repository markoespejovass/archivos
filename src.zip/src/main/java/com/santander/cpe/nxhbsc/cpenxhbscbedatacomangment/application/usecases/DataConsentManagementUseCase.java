package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.usecases;



import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperConsentId;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperGetConsentsOutput;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPatchConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPostConsentRequestBody;
import reactor.core.publisher.Mono;

import java.util.List;

public interface DataConsentManagementUseCase {

  WrapperGetConsentsOutput getConsent(String partyId);

  List<WrapperConsentId> postConsent(
          WrapperPostConsentRequestBody criteria, String partyId);

  Void patchConsent(
          WrapperPatchConsentRequestBody criteria, String partyId, String consentId);
}
