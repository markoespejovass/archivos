package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.ports.input;


import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.ports.output.DataConsentManagementRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.usecases.DataConsentManagementUseCase;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperConsentId;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperGetConsentsOutput;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPatchConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPostConsentRequestBody;

import java.util.List;

@AllArgsConstructor
@Service
public class DataConsentManagementInputPort implements DataConsentManagementUseCase {

  private final DataConsentManagementRepositoryPort dataConsentManagementRepositoryPort;

  @Override
  public WrapperGetConsentsOutput getConsent(String partyId) {
    return dataConsentManagementRepositoryPort.getConsent(partyId);
  }

  @Override
  public List<WrapperConsentId> postConsent(
      WrapperPostConsentRequestBody criteria, String partyId) {
    return dataConsentManagementRepositoryPort.postConsent(criteria, partyId);
  }

  @Override
  public Void patchConsent(
      WrapperPatchConsentRequestBody criteria, String partyId, String consentId) {
    return dataConsentManagementRepositoryPort.patchConsent(criteria, partyId, consentId);
  }
}
