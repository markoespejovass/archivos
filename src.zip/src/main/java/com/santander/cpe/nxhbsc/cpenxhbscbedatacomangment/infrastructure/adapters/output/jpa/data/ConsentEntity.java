package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class ConsentEntity {

    @Id
    private String id;

    private String partyId;

    private String statusCode;
    private String statusDescription;

    private  String bankId;

    private  String legitimateCode;

    private  String legitimateDescription;

    private  String treatmentCode;

    private  String treatmentDescription;

    private  String purposeCode;

    private  String purposeDescription;

    private String startDate;
    private String endDate;
}
