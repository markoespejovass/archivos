package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest;

import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.usecases.DataConsentManagementUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperConsentId;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperGetConsentsOutput;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPatchConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPostConsentRequestBody;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import lombok.RequiredArgsConstructor;

import java.util.List;

/**
 * Example delegate implementation when using the OpenAPI generator.
 * This tool generates the controller and the delegate interface, in this class we add our application logic.
 * 
 * @author Created by Team DCOE Mx
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class HelloApiDelegateImpl implements PartiesApiDelegate {


    private final DataConsentManagementUseCase dataConsentManagementUseCase;


    @Override
    public ResponseEntity<List<WrapperConsentId>> consentsCreation(String partyId,
                                                                   WrapperPostConsentRequestBody criteria) {
        log.info("Log from Servlet controller");
        return ResponseEntity.ok(
                dataConsentManagementUseCase
                        .postConsent(criteria,
                                partyId)
        );
    }

    @Override
    public ResponseEntity<WrapperGetConsentsOutput> consentsGet(String partyId,
                                                                String legitimateCode,
                                                                String treatmentCode,
                                                                String purposeCode,
                                                                String statusCode,
                                                                String bankId,
                                                                String offset,
                                                                String limit) {
        log.info("Log from Servlet controller");
        return ResponseEntity.ok(
                dataConsentManagementUseCase
                        .getConsent(partyId)
        );
    }

    @Override
    public ResponseEntity<Void> consentsUpdate(String partyId,
                                               String consentId,
                                               WrapperPatchConsentRequestBody wrapperPatchConsentRequestBody) {
        log.info("Log from Servlet controller");
        return ResponseEntity.ok(
                dataConsentManagementUseCase.patchConsent(
                        wrapperPatchConsentRequestBody,
                        partyId,
                        consentId)
        );
    }
}
