package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * Enable caching in the application.
 */
@Configuration
@EnableCaching
class ApplicationConfiguration {
}
