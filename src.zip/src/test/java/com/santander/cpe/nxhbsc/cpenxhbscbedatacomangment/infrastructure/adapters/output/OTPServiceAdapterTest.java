package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.*;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.DataConsentManagementAdapter;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.data.ConsentEntity;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.mapper.ConsentEntityMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.output.jpa.repository.ConsentRepository;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OTPServiceAdapterTest {

    @Mock
    private ConsentRepository repository;

    @Mock
    private ConsentEntityMapper mapper;

    @InjectMocks
    private DataConsentManagementAdapter adapter;

    @Test
    void shouldReturnEmptyWhenNoConsent() {
        when(repository.findByPartyId("123")).thenReturn(Lists.list());

        WrapperGetConsentsOutput result = adapter.getConsent("123");

        Assertions.assertNotNull(result);
        verify(repository).findByPartyId("123");
        verifyNoInteractions(mapper);
    }
/*
    @Test
    void shouldReturnConsentWhenExists() {
        ConsentEntity entity = new ConsentEntity();
        WrapperConsentDetails response = new WrapperConsentDetails();

        when(repository.findByPartyId("123")).thenReturn(List.of(entity));
        when(mapper.toDTOGet(entity)).thenReturn(response);

        WrapperGetConsentsOutput result = adapter.getConsent("123");

        Assertions.assertNotNull(result);
        assertEquals(response, result);
    }
*/
    @Test
    void shouldSaveConsent() {
        WrapperPostConsentRequestBody request = new WrapperPostConsentRequestBody();
        ConsentEntity entity = new ConsentEntity();
        WrapperConsentId dto = new WrapperConsentId();

        when(mapper.toEntityPost(eq(request), eq("123"),anyString())).thenReturn(entity);
        when(repository.save(entity)).thenReturn(entity);
        when(mapper.toDTOPost(entity)).thenReturn(dto);

        List<WrapperConsentId> result = adapter.postConsent(request, "123");

        assertEquals(1, result.size());
        assertEquals(dto, result.get(0));
    }

    @Test
    void shouldPatchConsent() {
        WrapperPatchConsentRequestBody request = new WrapperPatchConsentRequestBody();
        ConsentEntity entity = new ConsentEntity();

        when(mapper.toEntityUpdate(request, "123", "abc")).thenReturn(entity);

        adapter.patchConsent(request, "123", "abc");

        verify(repository).save(entity);
    }
}