package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.ports.input;


import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.ports.output.DataConsentManagementRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperConsentId;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperGetConsentsOutput;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPatchConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPostConsentRequestBody;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class InputPortTest {

    @Mock
    private DataConsentManagementRepositoryPort repositoryPort;

    @InjectMocks
    private DataConsentManagementInputPort useCase;

    private WrapperGetConsentsOutput responseGet;

    private WrapperPatchConsentRequestBody requestPut;
    private WrapperPostConsentRequestBody requestValid;
    private List<WrapperConsentId> responseValid;

    @BeforeEach
    void setUp() {
        responseGet = new WrapperGetConsentsOutput();
        requestPut = new WrapperPatchConsentRequestBody();
        requestValid = new WrapperPostConsentRequestBody();
        responseValid = new ArrayList<>();
    }

    @Test
    void shouldGet() {
        when(repositoryPort.getConsent("")).thenReturn(responseGet);

        WrapperGetConsentsOutput result = useCase.getConsent("");

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseGet, result);
        verify(repositoryPort).getConsent("");
    }

    @Test
    void shouldPost() {
        when(repositoryPort.postConsent(requestValid,"")).thenReturn(responseValid);

        List<WrapperConsentId> result = useCase.postConsent(requestValid,"");

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseValid, result);
        verify(repositoryPort).postConsent(requestValid,"");
    }

    @Test
    void shouldPut() {
        doNothing().when(repositoryPort).patchConsent(isA(WrapperPatchConsentRequestBody.class),isA(String.class),isA(String.class));
        Void result = useCase.patchConsent(requestPut,"","");

        Assertions.assertNull(result);
        verify(repositoryPort).patchConsent(requestPut,"","");
    }
}
