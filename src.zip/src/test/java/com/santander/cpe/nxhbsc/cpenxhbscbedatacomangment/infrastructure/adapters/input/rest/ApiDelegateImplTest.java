package com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest;

import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.application.usecases.DataConsentManagementUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperConsentId;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperGetConsentsOutput;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPatchConsentRequestBody;
import com.santander.cpe.nxhbsc.cpenxhbscbedatacomangment.infrastructure.adapters.input.rest.data.WrapperPostConsentRequestBody;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class ApiDelegateImplTest {

    @Mock
    private DataConsentManagementUseCase useCase;

    @InjectMocks
    private HelloApiDelegateImpl controller;

    private WrapperGetConsentsOutput responseGet;

    private WrapperPatchConsentRequestBody requestPut;
    private WrapperPostConsentRequestBody requestValid;
    private List<WrapperConsentId> responseValid;

    @BeforeEach
    void setUp() {
        responseGet = new WrapperGetConsentsOutput();
        requestPut = new WrapperPatchConsentRequestBody();
        requestValid = new WrapperPostConsentRequestBody();
        responseValid = new ArrayList<>();
    }

    @Test
    void shouldPostUploadDocument() {
        when(useCase.postConsent(requestValid,"")).thenReturn(responseValid);

        List<WrapperConsentId> result = controller.consentsCreation("",requestValid).getBody();

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseValid, result);
        verify(useCase).postConsent(requestValid,"");
    }

    @Test
    void shouldGetDocument() {
        when(useCase.getConsent("")).thenReturn(responseGet);

        WrapperGetConsentsOutput result = controller.consentsGet("","","","","","","","").getBody();

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseGet, result);
        verify(useCase).getConsent("");
    }

    @Test
    void shouldPut() {
        doNothing().when(useCase).patchConsent(isA(WrapperPatchConsentRequestBody.class),isA(String.class),isA(String.class));
        Void result = controller.consentsUpdate("","",requestPut).getBody();

        Assertions.assertNull(result);
        verify(useCase).patchConsent(new WrapperPatchConsentRequestBody(),"","");
    }
}
