package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model;

import lombok.Data;

import java.util.List;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
public class Response {

    private String uid;

    private String email;

    private Boolean emailVerified;

    private String displayName;

    private Boolean disabled;

    private Metadata metadata;

    private String tokensValidAfterTime;

    private List<Object> providerData;
}
