package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@Builder
@AllArgsConstructor
public class UserInfo {

    private String firstName;
    private String lastName;
    private List<String> emails;
    private String birthdate;
}
