package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model;

import lombok.Data;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
public class CreateUserResponse {

    private Boolean success;

    private Integer httpStatus;

    private String message;

    private Content content;
}
