package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.usecases;


import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserResponse;

/**
 * The class representative Sky service use case<
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
public interface SKYServiceUseCase {

  CreateUserResponse createUser(CreateUserRequest criteria);
}
