package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuditDataRequest {
  String appId;
  String usuario;
  String ipServidor;
  String transaccionId;
  String origen;
  String timeStamp;
}
