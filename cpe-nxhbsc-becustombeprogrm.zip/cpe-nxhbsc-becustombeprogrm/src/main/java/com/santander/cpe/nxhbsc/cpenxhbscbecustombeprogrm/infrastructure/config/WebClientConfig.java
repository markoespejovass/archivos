package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.external.TokenService;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

/**
 * The class representative Web client
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Configuration
public class WebClientConfig {


  public WebClientConfig() {
  }

  @Bean
  public WebClient webClient(
      TokenService tokenService) throws Exception{

      SslContext sslContext = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build();
      HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(sslContext));
    return WebClient.builder()
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .baseUrl("https://dev-api.skyairline.com/partners")
        .filter(addTokenFilter(tokenService))
        .build();
  }

  private ExchangeFilterFunction addTokenFilter(TokenService tokenService) {
    return (request, next) ->
        tokenService
            .getToken()
            .flatMap(
                token -> {
                  ClientRequest authorizedRequest =
                      ClientRequest.from(request)
                          .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                          .build();
                  return next.exchange(authorizedRequest);
                });
  }
}
