package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.constants;

/**
 * The class representative Constant
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
public class Constant {
  public static final String URI_API_PRODUCT_OFFER = "/api/Producto/Ofertar";
  public static final String URI_API_CONTRACT = "/api/Producto/Ofertar";
  public static final String URI_API_SKY = "/partners/v1/user";
  public static final String URI_API_KNOW_YOUR_CUSTOMER = "/api/Producto/Ofertar";
  public static final String URI_API_DATA_CONSEMENT =
      "/v7/data_consent_management/parties/{party_id}/consent_agreements";
  public static final String URI_API_DOCUMENT_MANAGEMENT = "/api/Token/Login";
  public static final String URI_API_TOKEN = "/api/Token/Login";

  public static final String URI_API_SKY_TIER = "";

  public static final String REQUEST_BSPE = "BSPE";
  public static final String REQUEST_EMAIL = "email";
  public static final String REQUEST_COUNTRY = "country";
  public static final String REQUEST_TYPE = "type";
  public static final String REQUEST_NUMBER = "number";
  public static final String REQUEST_NAME = "name";
  public static final String REQUEST_LASTNAME = "lastname";
  public static final String REQUEST_BIRTHDATE = "birthdate";

  public static final String PERU_ID = "01";
  public static final String EXPIRES_TIME_TIER = "2050-01-01";
}
