package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.mapper;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted.Profile;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted.CreateUserRequestDTO;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted.DocumentSKY;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted.UserInfo;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.BenefitProgramActivationRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.BenefitProgramActivationRequestActivationPropertiesInner;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.WrapperRegisterCustomer;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config.AesProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.constants.Constant;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.util.AesEncryptionService;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The class representative Sky service mapper<
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Mapper(componentModel = "spring")
public interface SkyServiceMapper {

  CreateUserRequestDTO CreateUserRequestDtoToCreateUserRequest(
          BenefitProgramActivationRequest dto);

  @Mapping(target = "requestId", expression = "java(getUserId(createUserResponse))")
  @Mapping(target = "status.statusCode", source = "success")
  @Mapping(target = "status.statusDescription", source = "message")
  WrapperRegisterCustomer CreateUserResponseToCreateUserResponseDTO(
          CreateUserResponse createUserResponse);

  @AfterMapping
  default void mapPropertiesRequest(BenefitProgramActivationRequest dto, @MappingTarget CreateUserRequestDTO request){

    Map<String,String> mapProperties = dto.getActivationProperties()
                                          .stream()
                                          .collect(Collectors.toMap(
                                                  BenefitProgramActivationRequestActivationPropertiesInner::getKey,
                                                  BenefitProgramActivationRequestActivationPropertiesInner::getValue));


    request.setProfile(new Profile(mapProperties.get(Constant.REQUEST_EMAIL), mapProperties.get(Constant.REQUEST_COUNTRY)));
    request.setDocument(new DocumentSKY(mapProperties.get(Constant.REQUEST_TYPE), mapProperties.get(Constant.REQUEST_NUMBER), mapProperties.get(Constant.REQUEST_COUNTRY) ));
    request.setUserInfo(new UserInfo(mapProperties.get(Constant.REQUEST_NAME), mapProperties.get(Constant.REQUEST_LASTNAME), List.of(mapProperties.get(Constant.REQUEST_EMAIL)), mapProperties.get(Constant.REQUEST_BIRTHDATE)));



  }


  default String getUserId(CreateUserResponse createUserResponse){
    return createUserResponse.getContent().getLoginBffResponse().getContent().getResponse().getUid();
  }
}
