package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.ports.input.SkyServicelnputPort;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted.CreateUserRequestDTO;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.mapper.SkyServiceMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.BenefitProgramActivationRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.WrapperRegisterCustomer;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.constants.Constant;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.util.AesEncryptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import lombok.RequiredArgsConstructor;

/**
 * The class representative Api delegate<
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class HelloApiDelegateImpl implements RegisterCustomerApiDelegate {

    private final SkyServicelnputPort servicelnputPort;
    private final SkyServiceMapper mapper;
    private final AesEncryptionService encriptionService;
    private final ObjectMapper objectMapper;



    @Override
    public ResponseEntity<WrapperRegisterCustomer> registerCustomer(BenefitProgramActivationRequest request) {
        log.info("Log from Servlet controller");
        var requestDTO = mapper.CreateUserRequestDtoToCreateUserRequest(request);
        CreateUserRequest createUserRequest = new CreateUserRequest();
        createUserRequest.setPartnerId(Constant.REQUEST_BSPE);
        createUserRequest.setData(encryptRequest(requestDTO));
        return ResponseEntity.ok(mapper.CreateUserResponseToCreateUserResponseDTO(servicelnputPort.createUser(
                createUserRequest)));
    }

    private String encryptRequest(CreateUserRequestDTO dto){

        try {
            String json = objectMapper.writeValueAsString(dto);
            return encriptionService.encrypt(json);
        } catch (Exception ex){
            throw new RuntimeException("Error mapping or encrypting request");
        }
    }
}
