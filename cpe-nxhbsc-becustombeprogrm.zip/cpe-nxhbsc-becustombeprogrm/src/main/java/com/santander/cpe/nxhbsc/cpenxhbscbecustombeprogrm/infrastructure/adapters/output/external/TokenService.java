package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.external;


import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * The class representative Token Service
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TokenService {

  private final JwtUtil jwtUtil;

  public Mono<String> getToken() {
    return Mono.just(jwtUtil.generateToken());
  }

}
