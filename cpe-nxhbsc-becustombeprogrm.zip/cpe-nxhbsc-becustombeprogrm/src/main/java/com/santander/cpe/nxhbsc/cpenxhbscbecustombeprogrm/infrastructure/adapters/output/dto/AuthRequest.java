package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AuthRequest {
  private String username;
  private String password;
}
