package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.util;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config.AesProperties;
import jakarta.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;

/**
 * The class representative Aes ultis class
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@AllArgsConstructor
public class AesEncryptionService {

    private  final AesProperties aesProperties;
    private static final String ALGORITHM = "AES";


    @SuppressWarnings("java:S5542")
    public String encrypt(String value){
        byte[] keyBytes = hexStringToByteArray(aesProperties.getSecret());
        try {
            // generar IV aleatorio
            byte[] iv = new byte[16];
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.nextBytes(iv);

            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, ALGORITHM);

            Cipher cipher = Cipher.getInstance(ALGORITHM+aesProperties.getMethod());

            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

            byte[] encrypted = cipher.doFinal(value.getBytes("UTF-8"));

            // IV + ciphertext
            byte[] result = new byte[iv.length + encrypted.length];

            System.arraycopy(iv, 0, result, 0, iv.length);
            System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);

            return bytesToHex(result);
        } catch (Exception ex){
            throw new RuntimeException("Error encrypting");
        }
    }


    private static byte[] hexStringToByteArray(String s) {
        int len = s.length();

        byte[] data = new byte[len / 2];

        for (int i = 0; i < len; i += 2) {
            data[i / 2] =
                    (byte) ((Character.digit(s.charAt(i), 16) << 4)
                            + Character.digit(s.charAt(i + 1), 16));
        }

        return data;
    }

    private static String bytesToHex(byte[] bytes) {

        StringBuilder hex = new StringBuilder(bytes.length * 2);

        for (byte b : bytes) {
            hex.append(String.format("%02x", b));
        }

        return hex.toString();
    }

}
