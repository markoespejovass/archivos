package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted;

import lombok.Data;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
public class CreateUserRequestDTO {

    private Profile profile;
    private DocumentSKY document;
    private UserInfo userInfo;
}
