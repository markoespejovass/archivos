package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * The class representative Api properties
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "jwt")
public class JwtProperties {
  private String secret;
}
