package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.util;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config.JwtProperties;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * The class representative Jwt ultis class
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@RequiredArgsConstructor
public class JwtUtil {

    private final JwtProperties jwtProperties;

    public String generateToken() {

        Map<String, Object> claims = new HashMap<>();
        claims.put("partnerId", "BSPE"); // opcional

        SecretKey secretKey = Keys.hmacShaKeyFor(
                jwtProperties.getSecret().getBytes(StandardCharsets.UTF_8));

        long now = System.currentTimeMillis();
        long expiration = now + 1000 * 60 * 60; // 1 hora

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(new Date(now))
                .setExpiration(new Date(expiration))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();
    }


}