package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import java.math.BigDecimal;

public record OfferResponse(
        Integer ciaSegId,
        String ciaSeg,
        Integer productoId,
        String producto,
        Integer planId,
        String plan,
        Integer monedaId,
        String moneda,
        BigDecimal primaNeta,
        BigDecimal derechos,
        BigDecimal impuestos,
        BigDecimal primaTotal,
        Integer frecuenciaPagoId,
        String frecuenciaPago,
        Integer tipoVigenciaId,
        String tipoVigencia,
        String tasa) {
}
