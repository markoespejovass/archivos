package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model;

import lombok.Data;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
public class ContentItem {

    private Boolean success;
    private Response response;

}
