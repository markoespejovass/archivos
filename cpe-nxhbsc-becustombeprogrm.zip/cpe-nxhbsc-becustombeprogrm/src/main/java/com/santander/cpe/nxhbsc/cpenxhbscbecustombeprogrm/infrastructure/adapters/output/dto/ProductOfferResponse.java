package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import java.util.List;

public record ProductOfferResponse(
        String codResponse,
        String txtResponse,
        List<Object> details,
        String codOferta,
        List<OfferResponse> ofertas) {
}
