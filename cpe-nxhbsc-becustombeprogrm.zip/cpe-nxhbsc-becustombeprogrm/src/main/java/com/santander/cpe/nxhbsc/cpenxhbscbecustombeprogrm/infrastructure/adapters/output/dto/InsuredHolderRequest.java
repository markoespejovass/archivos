package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InsuredHolderRequest {
  Integer tipoDocId;
  String nroDoc;
  String nombres;
  String fecNac;
}
