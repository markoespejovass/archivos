package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@AllArgsConstructor
public class DocumentSKY {

    private String type;
    private String number;
    private String country;
}
