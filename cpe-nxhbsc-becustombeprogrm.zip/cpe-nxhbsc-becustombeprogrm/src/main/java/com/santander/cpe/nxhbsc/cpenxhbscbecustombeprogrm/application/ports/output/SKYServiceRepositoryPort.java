package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.ports.output;


import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.WrapperUpdateBenefitProgramDetails;

/**
 * The class representative Sky service repository port<
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
public interface SKYServiceRepositoryPort {

    CreateUserResponse createUser(CreateUserRequest criteria);

    Void updateTier(WrapperUpdateBenefitProgramDetails criteria, String action);
}
