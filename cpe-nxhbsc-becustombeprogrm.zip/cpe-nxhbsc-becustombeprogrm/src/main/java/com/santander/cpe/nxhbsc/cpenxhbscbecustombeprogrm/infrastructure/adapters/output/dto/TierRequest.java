package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import lombok.Data;

@Data
public class TierRequest {
    public String country_id;
    public String email;
    public String key;
    public String tier_expires_at;
    public int tier_id;
    public String tx_id;
    public boolean user_enabled;
}
