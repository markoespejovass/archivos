package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.ports.input;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.ports.output.SKYServiceRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.usecases.SKYServiceUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * The class representative Sky service input port<
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@AllArgsConstructor
@Service
public class SkyServicelnputPort implements SKYServiceUseCase {

  private final SKYServiceRepositoryPort skyServiceRepositoryPort;


  @Override
  public CreateUserResponse createUser(CreateUserRequest criteria) {
    return skyServiceRepositoryPort.createUser(criteria);
  }
}
