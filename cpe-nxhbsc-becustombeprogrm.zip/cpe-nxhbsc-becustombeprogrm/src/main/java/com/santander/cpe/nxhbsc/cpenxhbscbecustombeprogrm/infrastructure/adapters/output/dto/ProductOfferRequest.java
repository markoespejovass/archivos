package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductOfferRequest {
  Integer ramoId;
  Integer tipoRiesgoId;
  Integer productoId;
  double sumaAsegurada;
  String fechaIngreso;
  InsuredHolderRequest asegTitular;
  AuditDataRequest auditoria;
}
