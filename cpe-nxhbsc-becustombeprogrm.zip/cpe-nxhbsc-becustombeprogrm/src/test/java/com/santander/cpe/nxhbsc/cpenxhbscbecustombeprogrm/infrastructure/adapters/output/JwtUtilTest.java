package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config.JwtProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.util.JwtUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JwtUtilTest {

    @Mock
    JwtProperties jwtProperties;

    @InjectMocks
    JwtUtil jwtUtil;

    @Test
    void shouldGenerateValidToken() {

        when(jwtProperties.getSecret()).thenReturn("my-super-secret-key-that-is-at-least-32-bytes");

        String token = jwtUtil.generateToken();

        assertNotNull(token);
        assertFalse(token.isEmpty());
        assertTrue(token.split("\\.").length == 3); // estructura JWT
    }
}