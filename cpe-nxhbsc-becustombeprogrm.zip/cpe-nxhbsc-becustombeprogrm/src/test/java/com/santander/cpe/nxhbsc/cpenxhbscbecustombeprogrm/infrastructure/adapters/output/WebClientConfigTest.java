package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output.external.TokenService;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config.WebClientConfig;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.web.reactive.function.client.WebClient;

import javax.net.ssl.SSLException;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class WebClientConfigTest {

    @Test
    void shouldCreateWebClientBean() throws Exception {

        TokenService tokenService = Mockito.mock(TokenService.class);

        WebClientConfig config = new WebClientConfig();

        WebClient client = config.webClient(tokenService);

        assertNotNull(client);
    }

}