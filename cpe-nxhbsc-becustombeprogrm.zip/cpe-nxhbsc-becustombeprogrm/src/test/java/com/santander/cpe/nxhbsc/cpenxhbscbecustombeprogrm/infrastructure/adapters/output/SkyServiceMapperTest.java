package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.beforeEncripted.CreateUserRequestDTO;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.mapper.SkyServiceMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.BenefitProgramActivationRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.BenefitProgramActivationRequestActivationPropertiesInner;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.input.rest.data.WrapperRegisterCustomer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class SkyServiceMapperTest {

    @Autowired
    private SkyServiceMapper mapper;

    @Test
    void shouldMapRequestAndEncrypt() {
        BenefitProgramActivationRequest request = new BenefitProgramActivationRequest();

        BenefitProgramActivationRequestActivationPropertiesInner prop1 =
                new BenefitProgramActivationRequestActivationPropertiesInner();
        BenefitProgramActivationRequestActivationPropertiesInner prop2 =
                new BenefitProgramActivationRequestActivationPropertiesInner();

        prop1.setKey("email");
        prop1.setValue("test@mail.com");

        prop2.setKey("country");
        prop2.setValue("PE");

        BenefitProgramActivationRequestActivationPropertiesInner prop3 = new BenefitProgramActivationRequestActivationPropertiesInner();
        prop3.setKey("name");
        prop3.setValue("John");

        BenefitProgramActivationRequestActivationPropertiesInner prop4 = new BenefitProgramActivationRequestActivationPropertiesInner();
        prop4.setKey("lastname");
        prop4.setValue("Doe");

        request.setActivationProperties(List.of(prop1, prop2, prop3, prop4));

        request.setActivationProperties(List.of(prop1, prop2));

        CreateUserRequestDTO result = mapper.CreateUserRequestDtoToCreateUserRequest(request);

        assertNotNull(result);
        assertNotNull(result.getProfile()); // encrypted
    }


}