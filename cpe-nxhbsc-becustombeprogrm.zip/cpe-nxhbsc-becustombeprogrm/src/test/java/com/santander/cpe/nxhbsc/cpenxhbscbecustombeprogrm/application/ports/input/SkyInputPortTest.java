package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.ports.input;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.application.ports.output.SKYServiceRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.domain.model.CreateUserResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SkyInputPortTest {

    @Mock
    private SKYServiceRepositoryPort repositoryPort;

    @InjectMocks
    private SkyServicelnputPort useCase;

    private CreateUserRequest requestOTP;
    private CreateUserResponse responseOTP;


    @BeforeEach
    void setUp() {
        requestOTP = new CreateUserRequest();
        responseOTP = new CreateUserResponse();

    }

    @Test
    void shouldRegisterCustomer() {
        when(repositoryPort.createUser(requestOTP)).thenReturn(responseOTP);

        CreateUserResponse result = useCase.createUser(requestOTP);

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseOTP, result);
        verify(repositoryPort).createUser(requestOTP);
    }

}
