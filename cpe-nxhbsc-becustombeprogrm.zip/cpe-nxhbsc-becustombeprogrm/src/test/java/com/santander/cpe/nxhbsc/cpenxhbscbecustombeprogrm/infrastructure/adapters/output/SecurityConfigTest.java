package com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbecustombeprogrm.infrastructure.config.SecurityConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.SecurityFilterChain;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.when;



@ExtendWith(MockitoExtension.class)
class SecurityConfigTest {

    @InjectMocks
    private SecurityConfig securityConfig;

    @Test
    void shouldBuildSecurityFilterChain() throws Exception {
        // mock con deep stubs
        HttpSecurity http = Mockito.mock(HttpSecurity.class, Mockito.RETURNS_DEEP_STUBS);

        // mock del resultado REAL esperado
        DefaultSecurityFilterChain filterChainMock =
                Mockito.mock(DefaultSecurityFilterChain.class);

        // stubbing correcto
        when(http.securityMatcher(anyString())).thenReturn(http);
        when(http.authorizeHttpRequests(any())).thenReturn(http);
        when(http.csrf(any())).thenReturn(http);
        when(http.headers(any())).thenReturn(http);
        when(http.build()).thenReturn(filterChainMock); // 👈 SIN CAST

        SecurityFilterChain result = securityConfig.filterChain(http);

        assertNotNull(result);
    }
}
