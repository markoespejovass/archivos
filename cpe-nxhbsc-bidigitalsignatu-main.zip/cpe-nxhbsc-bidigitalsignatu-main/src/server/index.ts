/* eslint-disable @typescript-eslint/no-var-requires */
// import darwin config must be the first import
import darwinConfig from '../config/darwin.config';
import fastifyConfig from '../config/fastify.config';
import fastify from 'fastify';
import { generateFastifyApp } from '@darwin-node/composer';

const routes = require('../routers');
const { techLog } = require('@darwin-node/logger');
const server = fastify();
const app = generateFastifyApp(server, routes, darwinConfig);

// this is a workaround to avoid fortify security issue.
// currently we are not supporting SSL in the application.
const App = Object.assign(app);
App.run = App.listen.bind(App);
App.run(fastifyConfig, () => {
  /* istanbul ignore next */
  techLog.info('Server listening');
});
