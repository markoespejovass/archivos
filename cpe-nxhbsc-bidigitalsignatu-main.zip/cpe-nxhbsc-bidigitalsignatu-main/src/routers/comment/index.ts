
/**
 * Quote router,
 * It is used to route all quote request.
 */

const router = (app, options, done) => {
  app.route({
    method: 'POST',
    url: '/comment',
    handler: (req, res) => res.send({ data: 'Hello typescript world!!' })
  });
  done();
};
/**
 * @returns module functions.
 */
export default router;
