/* eslint-disable @typescript-eslint/no-unused-vars */
import { AppError } from '@darwin-node/error';
import commentRouter from './comment';

interface PrefixedRouter {
  route: (app, opts, callback) => void ;
  prefix: string;
}

/**
* Array of routes
* Routes are stored in an array with its prefix
* It is later used on the app composer
*/
const router: Array<PrefixedRouter> = [
  {
    route: commentRouter,
    prefix: '/api'
  }
];

/**
 * @returns routes.
 */
export = router;
