import router from '../../../../src/routers/comment';

describe('****** UNIT TEST FOR COMMENT ROUTE *****', () => {
  it('should test comment route', () => {
    expect(router).toBeDefined();
  });

  it('should test method in route', () => {
    const responseMock = jest.fn().mockImplementation(() => {
      return { send: jest.fn() };
    });
    const routeMock = jest.fn().mockImplementation((method) => method.handler(jest.fn(), responseMock()));
    const generateFastifyApp = jest.fn().mockImplementation(() => {
      return {
        route: routeMock
      };
    });
    const app = generateFastifyApp();
    router(app, jest.fn(), jest.fn());
    expect(app.route).toBeCalledWith(
      expect.objectContaining({
        method: expect.stringContaining('POST'),
        url: expect.stringContaining('/comment')
      })
    );
  });
});
