package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.OtpRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.OtpResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.ValidateOtpRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.ValidateOtpResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.OTPTokenResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.OtpProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.constants.Constant;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token.TokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;
import java.util.UUID;

import static com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.constants.Constant.*;

@Component
@RequiredArgsConstructor
public class JsonApiClient {

    private final RestTemplate restTemplate;
    private final TokenProvider jsonTokenProvider;
    private final OtpProperties otpProperties;

    public String generarOTP(String uuid){

        String token = jsonTokenProvider.getToken();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(token);

        OtpRequest requestBody = new OtpRequest(uuid);

        HttpEntity<OtpRequest> request = new HttpEntity<>(requestBody,headers);
        ResponseEntity<OtpResponse> response = restTemplate.postForEntity(
                otpProperties.getGenerateUrl(),request, OtpResponse.class);

        return Objects.requireNonNull(response.getBody()).getData().getOtpCode();
    }

    public String validOTP(ValidateOtpRequest request){

        String token = jsonTokenProvider.getToken();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(token);


        HttpEntity<ValidateOtpRequest> entity = new HttpEntity<>(request,headers);
        ResponseEntity<ValidateOtpResponse> response = restTemplate.postForEntity(
                otpProperties.getValidateUrl(),entity, ValidateOtpResponse.class);
        return Objects.requireNonNull(response.getBody()).getMessage();
    }
}