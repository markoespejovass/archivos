package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.OtpRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.OtpResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.EmailProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token.TokenProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;


@Slf4j
@Component
@RequiredArgsConstructor
public class XmlApiClient {

    private final RestTemplate restTemplate;
    private final TokenProvider xmlTokenProvider;
    private final EmailProperties emailProperties;
    private final XmlMapper xmlMapper =  new XmlMapper();

    public ResponseOTP sendXml(RequestOTP request){

        String token = xmlTokenProvider.getToken();
        try {
            String xmlBody = xmlMapper.writeValueAsString(request);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_XML);
            headers.setBearerAuth(token);

            HttpEntity<String> entity = new HttpEntity<>(xmlBody, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(
                    emailProperties.getUrlSendMail(), entity, String.class);
            return xmlMapper.readValue(response.getBody(),ResponseOTP.class);
        } catch (Exception ex){
            log.error("ocurrio un error en OTPServiceAdapter : " + ex);
            return new ResponseOTP();
        }

    }
}