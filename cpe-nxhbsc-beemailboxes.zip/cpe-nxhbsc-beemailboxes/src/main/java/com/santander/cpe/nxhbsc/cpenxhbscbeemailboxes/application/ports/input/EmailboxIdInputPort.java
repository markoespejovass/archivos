package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.input;


import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.output.OTPServiceRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.usecases.EmailboxIdUseCase;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Input port for hello world application
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@AllArgsConstructor
@Slf4j
public class EmailboxIdInputPort implements EmailboxIdUseCase {

    private final OTPServiceRepositoryPort otpServiceRepositoryPort;

    /**
     * Metodo de entrada para envuar el correo
     *
     * @param otp cadena del otp
     * @param criteria valor del onjecto request
     * @return WrapperSendEmail objecto de response
     */
    @Override
    public WrapperClassifyEmail validCode(String otp, WrapperRequestClassifyEmails criteria) {
        return otpServiceRepositoryPort.validCode(otp, criteria);
    }

    /**
     * Metodo para enviar el correo
     *
     * @param criteria valor del objecto request
     * @return WrapperSendEmail objecto de response
     */
    @Override
    public ResponseOTP sendMailing(RequestOTP criteria) {
        return otpServiceRepositoryPort.sendMailing(criteria);
    }

}
