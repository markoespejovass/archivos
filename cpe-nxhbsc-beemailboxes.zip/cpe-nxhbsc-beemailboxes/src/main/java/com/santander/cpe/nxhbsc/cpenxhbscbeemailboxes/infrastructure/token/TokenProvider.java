package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token;

public interface TokenProvider {
    String getToken();
}