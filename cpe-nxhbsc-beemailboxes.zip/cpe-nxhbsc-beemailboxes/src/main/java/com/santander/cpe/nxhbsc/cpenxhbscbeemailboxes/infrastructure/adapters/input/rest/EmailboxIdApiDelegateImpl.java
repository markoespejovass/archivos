package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.input.EmailboxIdInputPort;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.mapper.OTPServiceMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestSendEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperSendEmail;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

/**
 * The class representative Controller
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Service
@Slf4j
@AllArgsConstructor
public class EmailboxIdApiDelegateImpl implements EmailboxIdApiDelegate {


    private final EmailboxIdInputPort emailboxIdInputPort;

    private final OTPServiceMapper mapper;

    /**
     * Metodo de entrada para envuar el correo
     *
     * @param emailboxId cadena del otp
     * @param criteria valor del onjecto request
     * @return WrapperSendEmail objecto de response
     */
    @Override
    public ResponseEntity<WrapperSendEmail> sendEmailReport(String emailboxId,
                                                     WrapperRequestSendEmail criteria) {

        return ResponseEntity.ok(mapper.responseOTPToWrapperSendEmail(emailboxIdInputPort
                .sendMailing(mapper.wrapperRequestSendEmailToRequest(criteria))));
    }

    /**
     * Metodo de entrada para validar otp
     *
     * @param emailboxId cadena del otp
     * @param emailId cadena del email
     * @param criteria valor del onjecto request
     * @return WrapperClassifyEmail objecto de response valid
     */
    @Override
    public ResponseEntity<WrapperClassifyEmail> createEmailboxEmailClassify(String emailboxId,
                                                                     String emailId,
                                                                     WrapperRequestClassifyEmails criteria) {
        return ResponseEntity.ok(emailboxIdInputPort
                .validCode(emailId, criteria));
    }


}
