package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.OTPTokenResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.OtpProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.constants.Constant;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Base64;

import static com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.constants.Constant.URI_API_OTP_TOKEN;

@Service("jsonTokenProvider")
@RequiredArgsConstructor
public class JsonTokenProvider implements TokenProvider{

    private final RestTemplate restTemplate;
    private String cachedToken;
    private LocalDateTime expiry;
    private final OtpProperties properties;

    @Override
    public String getToken() {

        if(cachedToken == null || LocalDateTime.now().isAfter(expiry)){
            refreshToken();
        }
        return cachedToken;
    }

    private void refreshToken(){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);



        headers.add(HttpHeaders.AUTHORIZATION,  buildAuthorization());
        MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
        body.add(Constant.GRANT_TYPE,Constant.GRANT_TYPE_OTP_VALUE);
        body.add(Constant.SCOPE,Constant.SCOPE_VALUE);

        HttpEntity<MultiValueMap<String,String>> request = new HttpEntity<>(body,headers);
        ResponseEntity<OTPTokenResponse> response = restTemplate.postForEntity(
                URI_API_OTP_TOKEN,request, OTPTokenResponse.class);
        OTPTokenResponse data = response.getBody();

        assert data != null;
        cachedToken = data.getData().getAccessToken();
        expiry = LocalDateTime.now().plusSeconds(data.getData().getExpiresIn());
    }

    private String buildAuthorization(){
        byte[] credentials = (properties.getClientId() + ":" + properties.getClientSecret()).getBytes(StandardCharsets.UTF_8);
        return "Basic " + Base64.getEncoder()
                .encodeToString(credentials);
    }
}