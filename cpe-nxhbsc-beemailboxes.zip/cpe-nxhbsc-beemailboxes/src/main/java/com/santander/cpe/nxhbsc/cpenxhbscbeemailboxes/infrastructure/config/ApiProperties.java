package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * The class representative Api properties
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Component
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "external.api")
public class ApiProperties {
  private String baseUrl;
  private String username;
  private String password;
}
