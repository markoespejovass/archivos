package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.output.OTPServiceRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.Email;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.StatusInfo;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.ValidateOtpRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.jpa.OtpEntity;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.jpa.OtpRepository;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client.JsonApiClient;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client.XmlApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * The class representative Otp adaptarer
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OTPServiceAdapter implements OTPServiceRepositoryPort {


    private final XmlApiClient xmlApiClient;

    private final JsonApiClient jsonApiClient;
    private final OtpRepository repository;

    /**
     * Metodo de salida para validar otp
     *
     * @param otp valor del otp
     * @param criteria valor del onjecto request
     * @return WrapperClassifyEmail objecto de response valid
     */
    @Override
    public WrapperClassifyEmail validCode(String otp, WrapperRequestClassifyEmails criteria) {

        String status = jsonApiClient.validOTP(generateValidateOtp(otp));

        if (status != null) {
            return generateResponsseValidCode(StatusInfo.StatusCodeEnum.PROCESSED);
        } else {
            return generateResponsseValidCode(StatusInfo.StatusCodeEnum.ERROR);
        }
    }

    private ValidateOtpRequest generateValidateOtp(String otp){
        String uuid = "";
        var optionalEntity = repository.getByKey(otp,null);
        if(optionalEntity.isEmpty()){
            return new ValidateOtpRequest();
        }
        uuid = optionalEntity.get().getId();
        return new ValidateOtpRequest(uuid, otp);
    }

    /**
     * Metodo de salida para enviar correo
     *
     * @param criteria request
     * @return objeto de response
     */
    @Override
    public ResponseOTP sendMailing(RequestOTP criteria)  {
        String uuid = UUID.randomUUID().toString();
        String otp = jsonApiClient.generarOTP(uuid);
        repository.putIfAbsent(new OtpEntity(uuid,otp));
        criteria = setearOtp(criteria, otp);

        return xmlApiClient.sendXml(criteria);
    }


    private RequestOTP setearOtp(RequestOTP criteria, String otp){
        String cadenaOtp = criteria.getRecipient().getPersonalization().get(0).getVALUE();
        cadenaOtp = cadenaOtp + otp;

        criteria.getRecipient().getPersonalization().get(0).setVALUE(cadenaOtp);

        return criteria;
    }


    private static WrapperClassifyEmail generateResponsseValidCode(StatusInfo.StatusCodeEnum status){
        var response = new WrapperClassifyEmail();
        response.setEmail(new Email(null,null,null,null,null,null,null,null,null,new StatusInfo(status)));
        return response;
    }

}