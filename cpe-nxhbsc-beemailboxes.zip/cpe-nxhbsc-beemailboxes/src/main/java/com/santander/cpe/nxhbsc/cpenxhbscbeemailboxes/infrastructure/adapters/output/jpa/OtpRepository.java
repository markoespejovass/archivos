package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.jpa;


import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.BaseDynamoRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;


@Repository
public class OtpRepository extends BaseDynamoRepository<OtpEntity> {

    public OtpRepository(DynamoDbEnhancedClient enhancedClient, @Value("${aws.table}") String table){
        super(enhancedClient, table, TableSchema.fromBean(OtpEntity.class),OtpEntity.class,"id","otp");
    }
}
