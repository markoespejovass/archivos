package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.output;


import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;

/**
 * Metodo para enviar el correo
 * @author Create by team Proyecto [NUBE] Pe
 */
public interface OTPServiceRepositoryPort {


    /**
     * Metodo para enviar el correo
     *
     * @param criteria valor del objecto request
     * @return WrapperSendEmail objecto de response
     */
    ResponseOTP sendMailing(RequestOTP criteria);

    /**
     * Metodo de entrada para envuar el correo
     *
     * @param otp cadena del otp
     * @param criteria valor del onjecto request
     * @return WrapperSendEmail objecto de response
     */
    WrapperClassifyEmail validCode(String otp, WrapperRequestClassifyEmails criteria);

}
