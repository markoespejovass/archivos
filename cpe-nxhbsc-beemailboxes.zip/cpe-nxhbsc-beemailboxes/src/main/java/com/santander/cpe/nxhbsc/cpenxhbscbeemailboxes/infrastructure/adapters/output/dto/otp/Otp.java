package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Otp {

    @JsonProperty("uuid")
    private String uuid;

    @JsonProperty("expires_at")
    private String expiresAt;

    @JsonProperty("otp_code")
    private String otpCode;

    @JsonProperty("ttl_seconds")
    private Integer ttlSeconds;

    @JsonProperty("max_attempts")
    private Integer maxAttempts;
}