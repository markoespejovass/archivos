package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config;

import org.jetbrains.annotations.Nullable;
import software.amazon.awssdk.enhanced.dynamodb.*;
import software.amazon.awssdk.enhanced.dynamodb.model.PageIterable;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.ScanEnhancedRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public abstract class BaseDynamoRepository<T> {

    protected final DynamoDbEnhancedClient enhancedClient;
    protected final DynamoDbTable<T> table;
    private final String partitionKeyAttr;
    @Nullable
    private final String sortKeyAttr;
    private final Class<T> itemClass;

    protected BaseDynamoRepository(DynamoDbEnhancedClient enhancedClient,
                                   String tableName,
                                   TableSchema<T> schema,
                                   Class<T> itemClass,
                                   String partitionKeyAttr,
                                   @Nullable String sortKeyAttr) {
        this.enhancedClient = enhancedClient;
        this.table = enhancedClient.table(tableName, schema);
        this.itemClass = itemClass;
        this.partitionKeyAttr = partitionKeyAttr;
        this.sortKeyAttr = sortKeyAttr;
    }

    public T putIfAbsent(T item) {
        String expr = "attribute_not_exists(" + partitionKeyAttr + ")";
        if (sortKeyAttr != null && !sortKeyAttr.isBlank()) {
            expr += " AND attribute_not_exists(" + sortKeyAttr + ")";
        }
        Expression condition = Expression.builder()
                .expression(expr)
                .build();
        PutItemEnhancedRequest<T> request = PutItemEnhancedRequest.builder(itemClass)
                .item(item)
                .conditionExpression(condition)
                .build();
        table.putItem(request);
        return request.item();
    }

    public Optional<T> getByKey(String partitionKeyValue, @Nullable String sortKeyValue) {
        Key key = (sortKeyAttr == null || sortKeyValue == null || sortKeyValue.isBlank())
                ? Key.builder().partitionValue(partitionKeyValue).build()
                : Key.builder().partitionValue(partitionKeyValue).sortValue(sortKeyValue).build();

        T result = table.getItem(r->r.key(key));
        return Optional.of(result);
    }


    public List<T> findAll() {
        List<T> results = new ArrayList<>();
        table.scan(ScanEnhancedRequest.builder().build())
                .items()
                .forEach(results::add);
        return results;
    }

}
