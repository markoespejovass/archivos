package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.OTPTokenResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.TokenResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.EmailProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.constants.Constant;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;


@Service("xmlTokenProvider")
@RequiredArgsConstructor
public class XmlTokenProvider implements TokenProvider{

    private final RestTemplate restTemplate;
    private String cachedToken;
    private LocalDateTime expiry;
    private final EmailProperties properties;

    @Override
    public String getToken() {

        if(cachedToken == null || LocalDateTime.now().isAfter(expiry)){
            refreshToken();
        }
        return cachedToken;
    }

    private void refreshToken(){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
        body.add(Constant.GRANT_TYPE,Constant.GRANT_TYPE_VALUE);
        body.add(Constant.CLIENT_ID,properties.getClientId());
        body.add(Constant.CLIENTE_SECRET,properties.getClientSecret());
        body.add(Constant.REFRESH_TOKEN,Constant.REFRESH_VALUE);

        HttpEntity<MultiValueMap<String,String>> request = new HttpEntity<>(body,headers);
        ResponseEntity<TokenResponse> response = restTemplate.postForEntity(properties.getUriApiToken(),request, TokenResponse.class);
        TokenResponse data = response.getBody();
        assert data != null;
        cachedToken = data.getAccessToken();
        expiry = LocalDateTime.now().plusSeconds(data.getExpiresIn());
    }
}