package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.jpa;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


import lombok.Setter;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

@Setter
@AllArgsConstructor
@NoArgsConstructor
@DynamoDbBean
public class OtpEntity {


    private String id;
    private String otp;

    @DynamoDbSortKey
    @DynamoDbAttribute("otp")
    public String getId() {
        return id;
    }

    @DynamoDbPartitionKey
    @DynamoDbAttribute("id")
    public String getOtp() {
        return otp;
    }
}
