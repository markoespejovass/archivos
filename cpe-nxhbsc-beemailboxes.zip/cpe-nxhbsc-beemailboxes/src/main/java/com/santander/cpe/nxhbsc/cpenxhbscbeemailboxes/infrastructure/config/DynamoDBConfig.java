package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

/**
 * Configuration class for setting up DynamoDB clients.
 * <p>
 * This class provides beans for the DynamoDbClient and DynamoDbEnhancedClient, using AWS region and
 * credentials from environment variables. It is used to enable integration with AWS DynamoDB in the
 * application context.
 */
@Configuration
public class DynamoDBConfig {


    /**
     * Creates and configures a DynamoDbClient bean.
     *
     * @return a configured DynamoDbClient instance
     */
    @Bean(name = "dynamoDbClient")
    public DynamoDbClient dynamoDbClient() {
        return DynamoDbClient.builder()
                .region(Region.of("us-east-1"))
                .build();
    }

    /**
     * Creates a DynamoDbEnhancedClient bean using the provided DynamoDbClient.
     *
     * @param dynamoDbClient the DynamoDbClient to use
     * @return a configured DynamoDbEnhancedClient instance
     */
    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(
            @Qualifier("dynamoDbClient") DynamoDbClient dynamoDbClient) {
        return DynamoDbEnhancedClient.builder()
                .dynamoDbClient(dynamoDbClient)
                .build();
    }
}
