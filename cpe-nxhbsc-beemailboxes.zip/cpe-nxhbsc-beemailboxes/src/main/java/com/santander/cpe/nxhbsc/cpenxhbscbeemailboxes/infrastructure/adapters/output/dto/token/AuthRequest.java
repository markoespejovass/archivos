package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token;

import lombok.Builder;
import lombok.Data;

/**
 * The class representative Auth request
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@Builder
public class AuthRequest {
  private String username;
  private String password;
}
