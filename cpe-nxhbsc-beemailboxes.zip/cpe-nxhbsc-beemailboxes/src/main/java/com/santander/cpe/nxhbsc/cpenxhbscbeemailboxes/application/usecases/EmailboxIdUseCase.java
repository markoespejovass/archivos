package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.usecases;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;

/**
 * Hello World Use Case
 * 
 * @author Created by Team DCOE Mx
 */
public interface EmailboxIdUseCase {

    /**
     * Metodo para enviar el correo
     *
     * @param criteria valor del objecto request
     * @return WrapperSendEmail objecto de response
     */
    ResponseOTP sendMailing(RequestOTP criteria);

    /**
     * Metodo de entrada para envuar el correo
     *
     * @param otp cadena del otp
     * @param criteria valor del onjecto request
     * @return WrapperSendEmail objecto de response
     */
    WrapperClassifyEmail validCode(String otp, WrapperRequestClassifyEmails criteria);


}
