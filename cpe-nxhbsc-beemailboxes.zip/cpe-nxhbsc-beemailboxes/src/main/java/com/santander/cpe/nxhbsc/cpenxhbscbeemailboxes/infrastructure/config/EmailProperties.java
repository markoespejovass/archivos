package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config;


import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "email")
public class EmailProperties {

    private String clientId;
    private String clientSecret;
    private String refreshToken;
    private String urlSendMail;
    private String uriApiToken;
}