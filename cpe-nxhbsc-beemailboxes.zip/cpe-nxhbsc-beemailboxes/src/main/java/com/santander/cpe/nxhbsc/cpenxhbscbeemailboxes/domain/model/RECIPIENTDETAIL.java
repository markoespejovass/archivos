package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RECIPIENTDETAIL {

    @JacksonXmlProperty(localName = "EMAIL")
    private String eMAIL;

    @JacksonXmlProperty(localName = "SEND_STATUS")
    private Integer sENDSTATUS;

    @JacksonXmlProperty(localName = "ERROR_CODE")
    private Integer eRRORCODE;

    @JacksonXmlProperty(localName = "ERROR_STRING")
    private String eRRORSTRING;
}
