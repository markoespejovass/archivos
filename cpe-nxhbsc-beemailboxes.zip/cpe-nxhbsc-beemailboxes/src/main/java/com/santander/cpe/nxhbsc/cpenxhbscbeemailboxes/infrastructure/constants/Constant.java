package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.constants;

/**
 * The class representative Constant
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
public final class Constant {

  public static final String URI_API_OTP_TOKEN = "https://otpsantander.celmediamobile.pe/api/v1/otp/generate";
  public static final int TEMP_2 = 2;
  public static final int ZERO = 0;
  public static final int MAX_NUMBER = 99_999_999;
  public static final int LIMIT1 = 10_000_000;
  public static final int LIMIT2 = 100_000_000;
  public static final int TIMEOUT = 500;
  public static final String NUMERO_PAR = "^[1-9]\\d{7}$";

  public static final String GRANT_TYPE = "grant_type";
  public static final String CLIENT_ID = "client_id";
  public static final String CLIENTE_SECRET = "client_secret";
  public static final String REFRESH_TOKEN = "refresh_token";
  public static final String SCOPE = "scope";
  public static final String SCOPE_VALUE = "otp:generate otp:validate";
  public static final String GRANT_TYPE_OTP_VALUE = "client_credentials";
  public static final String GRANT_TYPE_VALUE = "refresh_token";

  public static final String REFRESH_VALUE = "rMu4uG24_82eu-qGi-kGWSWx4V_4mQIETk67nckzvOXsS1";


  public static final int MINUTES = 30;


  private Constant(){}

}