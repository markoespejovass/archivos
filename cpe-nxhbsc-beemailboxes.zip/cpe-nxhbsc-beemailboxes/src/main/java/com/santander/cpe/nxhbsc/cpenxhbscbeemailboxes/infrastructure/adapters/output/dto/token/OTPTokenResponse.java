package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The class representative Token Response
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OTPTokenResponse {
    @JsonProperty("success")
    private String success;

    @JsonProperty("message")
    private String message;

    @JsonProperty("data")
    private OTPToken data;

}