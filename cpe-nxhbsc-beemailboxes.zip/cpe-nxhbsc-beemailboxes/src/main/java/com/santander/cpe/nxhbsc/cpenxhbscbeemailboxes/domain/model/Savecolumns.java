package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Savecolumns implements Serializable {

    private static final long serialVersionUID = 1;

    @JacksonXmlProperty(localName = "COLUMN_NAME")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<String> cOLUMNNAME;
}
