package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "otp")
public class OtpProperties {

    private String clientId;
    private String clientSecret;
    private String scope;
    private String generateUrl;
    private String validateUrl;
}
