package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@JacksonXmlRootElement(localName = "XTMAILING")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestOTP implements Serializable {

    private static final long serialVersionUID = 1;

    @JacksonXmlProperty(localName = "CAMPAIGN_ID")
    private Integer campaignid;

    @JacksonXmlProperty(localName = "TRANSACTION_ID")
    private String transactionid;

    @JacksonXmlProperty(localName = "SHOW_ALL_SEND_DETAIL")
    private Boolean showallsenddetail;

    @JacksonXmlProperty(localName = "SEND_AS_BATCH")
    private Boolean sendasbatch;

    @JacksonXmlProperty(localName = "NO_RETRY_ON_FAILURE")
    private Boolean noretryonfailure;

    @JacksonXmlProperty(localName = "SAVE_COLUMNS")
    private Savecolumns savecolumns;

    @JacksonXmlProperty(localName = "RECIPIENT")
    private Recipient recipient;
}
