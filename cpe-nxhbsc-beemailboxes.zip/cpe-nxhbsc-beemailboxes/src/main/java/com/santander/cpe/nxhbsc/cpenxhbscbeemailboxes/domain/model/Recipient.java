package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Recipient implements Serializable {

    private static final long serialVersionUID = 1;

    @JacksonXmlProperty(localName = "EMAIL")
    private String email;

    @JacksonXmlProperty(localName = "BODY_TYPE")
    private String bodyType;

    @JacksonXmlProperty(localName = "PERSONALIZATION")
    @JacksonXmlElementWrapper(useWrapping = false)
    private List<Personalization> personalization;
}
