package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * The class representative Data
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Personalization implements Serializable {

    private static final long serialVersionUID = 1;

    @XmlElement(name = "TAG_NAME")
    @JacksonXmlProperty(localName = "TAG_NAME")
    private String tAGNAME;

    @XmlElement(name = "VALUE")
    @JacksonXmlProperty(localName = "VALUE")
    private String vALUE;
}
