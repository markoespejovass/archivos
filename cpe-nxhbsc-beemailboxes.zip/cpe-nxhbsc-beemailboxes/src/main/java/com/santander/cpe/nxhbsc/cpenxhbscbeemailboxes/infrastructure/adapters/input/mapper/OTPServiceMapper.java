package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.mapper;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.Savecolumns;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.Personalization;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.Recipient;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperEmailRecipients;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestSendEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperSendEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.ElectronicAddress;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;


import java.util.List;

/**
 * The class representative Mapper
 *
 * @author Create by team Proyecto [NUBE] Pe
 */
@Mapper(componentModel = "spring")
public interface OTPServiceMapper {

    /**
     * Metodo para mapear de un objeto request de entrada a un obejto de dominio
     *
     * @param requestDto objeto de entrada
     * @return objecto de dominio
     */
    @Mapping(target = "recipient", expression = "java(toRecipient(requestDto))" )
    @Mapping(target = "campaignid", constant = "25514100")
    @Mapping(target = "transactionid", constant = "opcional")
    @Mapping(target = "showallsenddetail", constant = "true")
    @Mapping(target = "sendasbatch", constant = "false")
    @Mapping(target = "noretryonfailure", constant = "false")
    @Mapping(target = "savecolumns", expression = "java(toSaveCollumns())")
    RequestOTP wrapperRequestSendEmailToRequest(
            WrapperRequestSendEmail requestDto);

    /**
     * Metodo para mapear de un objeto request de entrada a un objeto de dominio interno Recepient
     *
     * @param requestDto objeto de entrada
     * @return objecto de dominio
     */
    @Mapping(target = "bodyType", constant = "HTML")
    @Mapping(target = "personalization", expression = "java(toPersonalitation())")
    @Mapping(target = "email", expression = "java(mapForEmail(requestDto))")
    Recipient toRecipient(
            WrapperRequestSendEmail requestDto);


    /**
     * Metodo para mapear de un objeto de dominio a un obejto de entrada response
     *
     * @param responseOTP objeto de dominio
     * @return objecto de entrada de tipo response
     */
    @Mapping(target = "emailId", expression = "java(mappingForStatus(responseOTP))")
    WrapperSendEmail responseOTPToWrapperSendEmail(
            ResponseOTP responseOTP);

    /**
     * Metodo para mapear para email
     *
     * @param requestDto valor del objecto response
     * @return objecto de string de email
     */
    default String mapForEmail(WrapperRequestSendEmail requestDto) {
        WrapperEmail wrapperEmail = requestDto.getEmail();
        if (wrapperEmail == null) {
            return "";
        }
        WrapperEmailRecipients wrapperEmailRecipients = wrapperEmail.getRecipients();
        if (wrapperEmailRecipients == null) {
            return "";
        }
        List<ElectronicAddress> list = wrapperEmailRecipients.getTo();
        if (list == null){
            return "";
        }

        return list.get(0).getEmailAddress();
    }

    /**
     * Metodo para emapear a status
     *
     * @param responseOTP valor del objecto response
     * @return objecto de string de estatus
     */
    default String mappingForStatus(ResponseOTP responseOTP){
        return responseOTP.getSTATUS()==0?"Se envio el correo":"Ocurrio un problema";
    }

    /**
     * Metodo para setar el valor de variable 1
     *
     * @return  objecto de response
     */
    default Savecolumns toSaveCollumns(){
        return new Savecolumns(List.of("VARIABLE_1"));
    }

    /**
     * Metodo para setear el valor de variable 1
     *
     * @return  objecto de response
     */
    default List<Personalization> toPersonalitation(){
        return List.of(new Personalization("VARIABLE_1", "OTP: "));
    }

 
}
