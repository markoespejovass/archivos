package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.Personalization;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.Recipient;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.StatusInfo;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.jpa.OtpEntity;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.jpa.OtpRepository;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client.JsonApiClient;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client.XmlApiClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class OTPServiceAdapterTest {

    @Mock
    private XmlApiClient xmlApiClient;

    @Mock
    private JsonApiClient jsonApiClient;

    @Mock
    private OtpRepository repository;

    @InjectMocks
    private OTPServiceAdapter adapter;

    @Test
    void validCode_shouldReturnProcessed_whenOtpIsValid() {
        String otp = "1234";

        OtpEntity entity = new OtpEntity("uuid-1", otp);
        when(repository.getByKey(otp,null)).thenReturn(Optional.of(entity));
        when(jsonApiClient.validOTP(any())).thenReturn("OK");

        WrapperClassifyEmail response = adapter.validCode(otp, new WrapperRequestClassifyEmails());

        assertEquals(StatusInfo.StatusCodeEnum.PROCESSED,
                response.getEmail().getStatusInfo().getStatusCode());
    }

    @Test
    void validCode_shouldReturnError_whenOtpIsInvalid() {
        String otp = "1234";

        OtpEntity entity = new OtpEntity("uuid-1", otp);
        when(repository.getByKey(otp,null)).thenReturn(Optional.of(entity));
        when(jsonApiClient.validOTP(any())).thenReturn(null);

        WrapperClassifyEmail response = adapter.validCode(otp, new WrapperRequestClassifyEmails());

        assertEquals(StatusInfo.StatusCodeEnum.ERROR,
                response.getEmail().getStatusInfo().getStatusCode());
    }

    @Test
    void sendMailing_shouldGenerateOtpAndSendEmail() {
        RequestOTP request = buildRequest();

        when(jsonApiClient.generarOTP(any())).thenReturn("9999");
        when(xmlApiClient.sendXml(any())).thenReturn(new ResponseOTP());

        ResponseOTP response = adapter.sendMailing(request);

        assertNotNull(response);
        verify(repository).putIfAbsent(any(OtpEntity.class));
        verify(xmlApiClient).sendXml(any());
    }

    private RequestOTP buildRequest() {
        // arma un objeto mínimo válido según tu modelo
        RequestOTP request = new RequestOTP();
        Recipient recipient = new Recipient();
        Personalization personalization = new Personalization();
        personalization.setVALUE("OTP : ");
        recipient.setPersonalization(List.of(personalization));
        request.setRecipient(recipient);
        // mockea estructura interna si es necesario
        return request;
    }

}