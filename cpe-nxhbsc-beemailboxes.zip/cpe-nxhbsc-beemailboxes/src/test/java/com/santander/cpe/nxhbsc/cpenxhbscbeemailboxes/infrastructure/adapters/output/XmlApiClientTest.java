package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client.XmlApiClient;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.EmailProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token.TokenProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.AssertionsKt.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class XmlApiClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private EmailProperties properties;

    @Mock
    private TokenProvider xmlTokenProvider;

    @InjectMocks
    private XmlApiClient client;

    @Test
    void sendXml_shouldReturnResponse() throws Exception {
        when(xmlTokenProvider.getToken()).thenReturn("token");

        String xmlResponse = "<ResponseOTP></ResponseOTP>";

        when(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(xmlResponse));
        when(properties.getUrlSendMail()).thenReturn("http://test");
        ResponseOTP response = client.sendXml(new RequestOTP());

        assertNotNull(response);
    }

    @Test
    void sendXml_shouldHandleException() {
        when(xmlTokenProvider.getToken()).thenReturn("token");

        when(restTemplate.postForEntity(anyString(), any(), eq(String.class)))
                .thenThrow(new RuntimeException());

        ResponseOTP response = client.sendXml(new RequestOTP());

        assertNotNull(response); // retorna vacío
    }
}
