package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.*;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.mapper.OTPServiceMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OTPServiceMapperTest {

    private OTPServiceMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = Mappers.getMapper(OTPServiceMapper.class);
    }

    @Test
    void shouldMapWrapperRequestToRequestOTP() {
        // Arrange
        WrapperRequestSendEmail request = buildRequest();

        // Act
        RequestOTP result = mapper.wrapperRequestSendEmailToRequest(request);

        // Assert
        assertNotNull(result);
        assertEquals("25514100", result.getCampaignid().toString());
        assertEquals("opcional", result.getTransactionid());
        assertTrue(result.getShowallsenddetail());
        assertFalse(result.getSendasbatch());
        assertFalse(result.getNoretryonfailure());

        assertNotNull(result.getRecipient());
        assertNotNull(result.getSavecolumns());
        assertEquals(1, result.getSavecolumns().getCOLUMNNAME().size());
    }

    @Test
    void shouldMapRecipientCorrectly() {
        WrapperRequestSendEmail request = buildRequest();

        Recipient recipient = mapper.toRecipient(request);

        assertNotNull(recipient);
        assertEquals("HTML", recipient.getBodyType());
        assertNotNull(recipient.getPersonalization());
        assertEquals("test@mail.com", recipient.getEmail());
    }

    @Test
    void shouldReturnEmptyEmailWhenNull() {
        WrapperRequestSendEmail request = new WrapperRequestSendEmail();

        String email = mapper.mapForEmail(request);

        assertEquals("", email);
    }

    @Test
    void shouldMapStatusSuccess() {
        ResponseOTP response = new ResponseOTP();
        response.setSTATUS(0);

        String result = mapper.mappingForStatus(response);

        assertEquals("Se envio el correo", result);
    }

    @Test
    void shouldMapStatusError() {
        ResponseOTP response = new ResponseOTP();
        response.setSTATUS(1);

        String result = mapper.mappingForStatus(response);

        assertEquals("Ocurrio un problema", result);
    }

    @Test
    void shouldCreateSaveColumns() {
        Savecolumns savecolumns = mapper.toSaveCollumns();

        assertNotNull(savecolumns);
        assertEquals(1, savecolumns.getCOLUMNNAME().size());
        assertEquals("VARIABLE_1", savecolumns.getCOLUMNNAME().get(0));
    }

    @Test
    void shouldCreatePersonalization() {
        var list = mapper.toPersonalitation();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertTrue(list.get(0).getVALUE().contains("OTP: "));
    }

    @Test
    void shouldMapResponseToWrapper() {
        ResponseOTP response = new ResponseOTP();
        response.setSTATUS(0);

        WrapperSendEmail result = mapper.responseOTPToWrapperSendEmail(response);

        assertNotNull(result);
        assertEquals("Se envio el correo", result.getEmailId());
    }

    // 🔧 Helper
    private WrapperRequestSendEmail buildRequest() {
        WrapperRequestSendEmail request = new WrapperRequestSendEmail();

        WrapperEmail email = new WrapperEmail();
        WrapperEmailRecipients recipients = new WrapperEmailRecipients();
        ElectronicAddress to = new ElectronicAddress();
        to.setEmailAddress("test@mail.com");

        recipients.setTo(List.of(to));
        email.setRecipients(recipients);
        request.setEmail(email);

        return request;
    }
}