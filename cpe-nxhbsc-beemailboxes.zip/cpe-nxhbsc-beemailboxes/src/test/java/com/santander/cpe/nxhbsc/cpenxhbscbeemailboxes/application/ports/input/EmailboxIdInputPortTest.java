package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.input;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.output.OTPServiceRepositoryPort;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;

@ExtendWith(MockitoExtension.class)
public class EmailboxIdInputPortTest {

    @Mock
    private OTPServiceRepositoryPort repositoryPort;

    @InjectMocks
    private EmailboxIdInputPort useCase;

    private RequestOTP requestOTP;
    private ResponseOTP responseOTP;

    private WrapperRequestClassifyEmails requestValid;
    private WrapperClassifyEmail responseValid;

    @BeforeEach
    void setUp() {
        requestOTP = new RequestOTP();
        responseOTP = new ResponseOTP();
        requestValid = new WrapperRequestClassifyEmails();
        responseValid = new WrapperClassifyEmail();
    }

    @Test
    void shouldSendMailing() {
        when(repositoryPort.sendMailing(requestOTP)).thenReturn(responseOTP);

        ResponseOTP result = useCase.sendMailing(requestOTP);

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseOTP, result);
        verify(repositoryPort).sendMailing(requestOTP);
    }

    @Test
    void shouldValidCode() {
        when(repositoryPort.validCode("",requestValid)).thenReturn(responseValid);

        WrapperClassifyEmail result = useCase.validCode("",requestValid);

        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseValid, result);
        verify(repositoryPort).validCode("",requestValid);
    }
}
