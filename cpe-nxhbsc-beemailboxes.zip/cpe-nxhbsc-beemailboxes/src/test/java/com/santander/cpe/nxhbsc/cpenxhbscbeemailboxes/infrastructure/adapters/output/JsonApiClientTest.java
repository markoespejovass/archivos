package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.Otp;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.OtpResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.ValidateOtpRequest;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.otp.ValidateOtpResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.client.JsonApiClient;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.OtpProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token.TokenProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class JsonApiClientTest {
    @Mock
    private RestTemplate restTemplate;

    @Mock
    private TokenProvider jsonTokenProvider;

    @Mock
    private OtpProperties otpProperties;

    @InjectMocks
    private JsonApiClient client;

    @Test
    void generarOTP_shouldReturnOtpCode() {
        when(jsonTokenProvider.getToken()).thenReturn("token");

        OtpResponse response = new OtpResponse();
        response.setData(new Otp("1234","","1234",1,1));

        when(restTemplate.postForEntity(anyString(), any(), eq(OtpResponse.class)))
                .thenReturn(ResponseEntity.ok(response));
        when(otpProperties.getGenerateUrl()).thenReturn("http://test");

        String otp = client.generarOTP("uuid");

        assertEquals("1234", otp);
    }

    @Test
    void validOTP_shouldReturnMessage() {
        when(jsonTokenProvider.getToken()).thenReturn("token");

        ValidateOtpResponse response = new ValidateOtpResponse();
        response.setMessage("VALID");

        when(restTemplate.postForEntity(anyString(), any(), eq(ValidateOtpResponse.class)))
                .thenReturn(ResponseEntity.ok(response));
        when(otpProperties.getValidateUrl()).thenReturn("http://test");
        String result = client.validOTP(new ValidateOtpRequest("id", "1234"));

        assertEquals("VALID", result);
    }
}
