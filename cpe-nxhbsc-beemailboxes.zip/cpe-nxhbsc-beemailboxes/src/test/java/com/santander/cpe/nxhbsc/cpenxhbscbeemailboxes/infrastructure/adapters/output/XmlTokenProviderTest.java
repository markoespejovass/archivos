package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.TokenResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.EmailProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token.XmlTokenProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class XmlTokenProviderTest {

    @Mock
    private EmailProperties properties;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private XmlTokenProvider provider;

    @Test
    void getToken_shouldReturnToken() {
        TokenResponse response = new TokenResponse();
        response.setAccessToken("xml-token");
        response.setExpiresIn(3600);

        when(restTemplate.postForEntity(anyString(), any(), eq(TokenResponse.class)))
                .thenReturn(ResponseEntity.ok(response));
        when(properties.getClientId()).thenReturn("client");
        when(properties.getClientSecret()).thenReturn("client");
        when(properties.getUriApiToken()).thenReturn("client");
        String token = provider.getToken();

        assertEquals("xml-token", token);
    }
}
