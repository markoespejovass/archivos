package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.DynamoDBConfig;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class DynamoDBConfigTest {

    private final DynamoDBConfig config = new DynamoDBConfig();

    @Test
    void dynamoDbClient_shouldCreateClient() {

        DynamoDbClient client = config.dynamoDbClient();

        assertNotNull(client);
    }

    @Test
    void dynamoDbEnhancedClient_shouldCreateEnhancedClient() {

        DynamoDbClient client = config.dynamoDbClient();

        DynamoDbEnhancedClient enhancedClient =
                config.dynamoDbEnhancedClient(client);

        assertNotNull(enhancedClient);
    }
}

