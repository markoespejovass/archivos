package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.inOrder;


import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.application.ports.input.EmailboxIdInputPort;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.RequestOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.domain.model.ResponseOTP;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.mapper.OTPServiceMapper;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperClassifyEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestClassifyEmails;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperRequestSendEmail;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.input.rest.data.WrapperSendEmail;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class EmailboxIdApiDelegateImplTest {

    @Mock
    private EmailboxIdInputPort useCase;

    @Mock
    private OTPServiceMapper mapper;

    @InjectMocks
    private EmailboxIdApiDelegateImpl controller;

    @Test
    void shouldSendMailingSuccessfully() {
        // Arrange
        WrapperRequestSendEmail requestDTO = new WrapperRequestSendEmail();
        RequestOTP request = new RequestOTP();

        ResponseOTP response = new ResponseOTP();
        WrapperSendEmail responseDTO = new WrapperSendEmail();

        when(mapper.wrapperRequestSendEmailToRequest(requestDTO)).thenReturn(request);
        when(useCase.sendMailing(request)).thenReturn(response);
        when(mapper.responseOTPToWrapperSendEmail(response)).thenReturn(responseDTO);

        // Act
        WrapperSendEmail result = controller.sendEmailReport(null,requestDTO).getBody();

        // Assert
        Assertions.assertNotNull(result);
        Assertions.assertEquals(responseDTO, result);

        verify(mapper).wrapperRequestSendEmailToRequest(requestDTO);
        verify(useCase).sendMailing(request);
        verify(mapper).responseOTPToWrapperSendEmail(response);
    }

    @Test
    void shouldCallDependenciesInCorrectOrder() {
        WrapperRequestSendEmail requestDTO = new WrapperRequestSendEmail();
        RequestOTP request = new RequestOTP();
        ResponseOTP response = new ResponseOTP();
        WrapperSendEmail responseDTO = new WrapperSendEmail();

        when(mapper.wrapperRequestSendEmailToRequest(requestDTO)).thenReturn(request);
        when(useCase.sendMailing(request)).thenReturn(response);
        when(mapper.responseOTPToWrapperSendEmail(response)).thenReturn(responseDTO);

        controller.sendEmailReport(null,requestDTO);

        InOrder inOrder = inOrder(mapper, useCase);

        inOrder.verify(mapper).wrapperRequestSendEmailToRequest(requestDTO);
        inOrder.verify(useCase).sendMailing(request);
        inOrder.verify(mapper).responseOTPToWrapperSendEmail(response);
    }



    @Test
    void shouldThrowExceptionWhenMapperFails() {
        WrapperRequestSendEmail requestDTO = new WrapperRequestSendEmail();

        when(mapper.wrapperRequestSendEmailToRequest(requestDTO))
                .thenThrow(new RuntimeException("Mapping error"));

        assertThrows(RuntimeException.class, () -> controller.sendEmailReport(null,requestDTO));

        verify(useCase, never()).sendMailing(any());
    }

    @Test
    void shouldCreateEmailboxEmailClassifySuccessfully() {
        // Arrange
        String otp = "123456";
        WrapperRequestClassifyEmails request = new WrapperRequestClassifyEmails();

        WrapperClassifyEmail response = new WrapperClassifyEmail();

        when(useCase.validCode(otp,request)).thenReturn(response);


        // Act
        WrapperClassifyEmail result = controller.createEmailboxEmailClassify(null,otp,request).getBody();

        // Assert
        Assertions.assertNotNull(result);
        Assertions.assertEquals(response, result);

        verify(useCase).validCode(otp,request);
    }
}
