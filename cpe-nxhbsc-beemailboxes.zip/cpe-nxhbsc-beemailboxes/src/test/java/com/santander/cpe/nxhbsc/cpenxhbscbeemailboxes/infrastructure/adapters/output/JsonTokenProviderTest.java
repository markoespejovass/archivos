package com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output;

import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.OTPToken;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.adapters.output.dto.token.OTPTokenResponse;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.config.OtpProperties;
import com.santander.cpe.nxhbsc.cpenxhbscbeemailboxes.infrastructure.token.JsonTokenProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.AssertionsKt.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class JsonTokenProviderTest {

    @Mock
    private OtpProperties properties;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private JsonTokenProvider provider;

    @Test
    void getToken_shouldFetchNewToken_whenExpired() {
        OTPTokenResponse response = new OTPTokenResponse();
        response.setData(new OTPToken("token123", 3600,"",""));

        when(restTemplate.postForEntity(anyString(), any(), eq(OTPTokenResponse.class)))
                .thenReturn(ResponseEntity.ok(response));
        when(properties.getClientId()).thenReturn("client");
        when(properties.getClientSecret()).thenReturn("client");

        String token = provider.getToken();

        assertEquals("token123", token);
    }

    @Test
    void getToken_shouldUseCache_whenValid() {
        // primera llamada
        getToken_shouldFetchNewToken_whenExpired();

        // segunda llamada no debe pegarle al restTemplate
        String token = provider.getToken();

        verify(restTemplate, times(1))
                .postForEntity(anyString(), any(), eq(OTPTokenResponse.class));

        assertNotNull(token);
    }
}
